(() => {
  // src/core/util.js
  var resolveUrl = (rel, base) => {
    try {
      return new URL(rel, base).href;
    } catch {
      return rel;
    }
  };
  var AbortError = class extends Error {
    constructor() {
      super("Cancelled");
      this.name = "AbortError";
    }
  };
  async function fetchBytes(url, opts = {}) {
    const f = opts.fetch || globalThis.fetch.bind(globalThis);
    const retries = opts.retries ?? 3;
    let lastErr;
    for (let i = 0; i <= retries; i++) {
      if (opts.signal?.aborted) throw new AbortError();
      try {
        const headers = {};
        if (opts.range) headers.Range = `bytes=${opts.range[0]}-${opts.range[1]}`;
        const res = await f(url, { headers, signal: opts.signal, credentials: "include", cache: "no-store" });
        if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status} for ${url}`);
        let buf = new Uint8Array(await res.arrayBuffer());
        if (opts.range && res.status === 200) buf = buf.subarray(opts.range[0], opts.range[1] + 1);
        return buf;
      } catch (e) {
        if (opts.signal?.aborted || e.name === "AbortError") throw new AbortError();
        lastErr = e;
        await new Promise((r) => setTimeout(r, 300 * 2 ** i));
      }
    }
    throw lastErr;
  }
  var fetchText = async (url, opts) => new TextDecoder().decode(await fetchBytes(url, opts));
  var sanitizeFilename = (s, fallback = "video") => String(s || "").replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 120) || fallback;

  // src/core/hls.js
  function attrs(line) {
    const out = {};
    const re = /([A-Z0-9-]+)=("([^"]*)"|[^,]*)/g;
    let m;
    while (m = re.exec(line)) out[m[1]] = m[3] !== void 0 ? m[3] : m[2];
    return out;
  }
  var hexToBytes = (hex) => {
    hex = hex.replace(/^0x/i, "").padStart(32, "0");
    return Uint8Array.from(hex.match(/../g).map((h) => parseInt(h, 16)));
  };
  function parseHls(text, baseUrl) {
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (!lines[0]?.startsWith("#EXTM3U")) throw new Error("Not an HLS playlist");
    const isMaster = lines.some((l) => l.startsWith("#EXT-X-STREAM-INF"));
    return isMaster ? parseMaster(lines, baseUrl) : parseMedia(lines, baseUrl);
  }
  function parseMaster(lines, baseUrl) {
    const variants = [], audio = [], subtitles = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (l.startsWith("#EXT-X-STREAM-INF:")) {
        const a = attrs(l.slice(18));
        let j = i + 1;
        while (j < lines.length && lines[j].startsWith("#")) j++;
        if (!lines[j]) continue;
        const [w, h] = (a.RESOLUTION || "").split("x").map(Number);
        variants.push({
          url: resolveUrl(lines[j], baseUrl),
          bandwidth: +(a["AVERAGE-BANDWIDTH"] || a.BANDWIDTH || 0),
          width: w || 0,
          height: h || 0,
          codecs: a.CODECS || "",
          audioGroup: a.AUDIO || null,
          frameRate: a["FRAME-RATE"] ? +a["FRAME-RATE"] : 0
        });
      } else if (l.startsWith("#EXT-X-MEDIA:")) {
        const a = attrs(l.slice(13));
        if (a.TYPE === "AUDIO" && a.URI) audio.push({ url: resolveUrl(a.URI, baseUrl), group: a["GROUP-ID"], name: a.NAME, lang: a.LANGUAGE, default: a.DEFAULT === "YES" });
        else if (a.TYPE === "SUBTITLES" && a.URI) subtitles.push({ url: resolveUrl(a.URI, baseUrl), name: a.NAME, lang: a.LANGUAGE });
      }
    }
    variants.sort((a, b) => b.height - a.height || b.bandwidth - a.bandwidth);
    return { type: "master", variants, audio, subtitles };
  }
  function parseMedia(lines, baseUrl) {
    const segments = [];
    let key = null, map = null, seq = 0, targetDuration = 0, endlist = false;
    let pendingDur = 0, pendingRange = null, lastRangeEnd = 0, discontinuity = false;
    for (const l of lines) {
      if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) seq = +l.split(":")[1];
      else if (l.startsWith("#EXT-X-TARGETDURATION:")) targetDuration = +l.split(":")[1];
      else if (l.startsWith("#EXT-X-ENDLIST")) endlist = true;
      else if (l.startsWith("#EXT-X-DISCONTINUITY") && !l.startsWith("#EXT-X-DISCONTINUITY-")) discontinuity = true;
      else if (l.startsWith("#EXT-X-KEY:")) {
        const a = attrs(l.slice(11));
        key = a.METHOD === "NONE" ? null : { method: a.METHOD, url: a.URI ? resolveUrl(a.URI, baseUrl) : null, iv: a.IV ? hexToBytes(a.IV) : null, format: a.KEYFORMAT || "identity" };
      } else if (l.startsWith("#EXT-X-MAP:")) {
        const a = attrs(l.slice(11));
        map = { url: resolveUrl(a.URI, baseUrl), range: a.BYTERANGE ? parseRange(a.BYTERANGE, 0) : null };
      } else if (l.startsWith("#EXTINF:")) pendingDur = parseFloat(l.slice(8));
      else if (l.startsWith("#EXT-X-BYTERANGE:")) pendingRange = l.slice(17);
      else if (!l.startsWith("#")) {
        let range = null;
        if (pendingRange) {
          range = parseRange(pendingRange, lastRangeEnd);
          lastRangeEnd = range[1] + 1;
        }
        segments.push({ url: resolveUrl(l, baseUrl), duration: pendingDur, range, key, map, seq: seq + segments.length, discontinuity });
        pendingDur = 0;
        pendingRange = null;
        discontinuity = false;
      }
    }
    return { type: "media", segments, endlist, targetDuration, duration: segments.reduce((s, x) => s + x.duration, 0) };
  }
  function parseRange(s, defaultStart) {
    const [len, off] = s.split("@").map(Number);
    const start = off !== void 0 && !Number.isNaN(off) ? off : defaultStart;
    return [start, start + len - 1];
  }

  // src/core/xml.js
  var ENT = { "&lt;": "<", "&gt;": ">", "&amp;": "&", "&quot;": '"', "&apos;": "'" };
  var unescapeXml = (s) => s.replace(/&(lt|gt|amp|quot|apos);|&#(\d+);|&#x([0-9a-f]+);/gi, (m, _n, d, h) => ENT[m] || String.fromCodePoint(d ? parseInt(d, 10) : parseInt(h, 16)));
  function parseXml(src) {
    const root = { name: "#root", attrs: {}, children: [], text: "" };
    const stack = [root];
    const re = /<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<\/([^\s>]+)\s*>|<([^\s/>!?]+)((?:\s+[^\s=/>]+(?:\s*=\s*(?:"[^"]*"|'[^']*'))?)*)\s*(\/?)>|([^<]+)/g;
    let m;
    while (m = re.exec(src)) {
      const top = stack[stack.length - 1];
      if (m[1] !== void 0) top.text += m[1];
      else if (m[2]) {
        if (stack.length > 1) stack.pop();
      } else if (m[3]) {
        const el = { name: m[3].replace(/^.*:/, ""), attrs: {}, children: [], text: "" };
        const ar = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'))?/g;
        let a;
        while (a = ar.exec(m[4] || "")) el.attrs[a[1].replace(/^.*:/, "")] = unescapeXml(a[2] ?? a[3] ?? "");
        top.children.push(el);
        if (!m[5]) stack.push(el);
      } else if (m[6] !== void 0) top.text += unescapeXml(m[6]);
    }
    return root.children[0];
  }
  var kids = (el, name) => el ? el.children.filter((c) => c.name === name) : [];
  var kid = (el, name) => kids(el, name)[0];

  // src/core/dash.js
  function parseIsoDuration(s) {
    if (!s) return 0;
    const m = /^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec(s);
    if (!m) return 0;
    return (+m[1] || 0) * 86400 + (+m[2] || 0) * 3600 + (+m[3] || 0) * 60 + (+m[4] || 0);
  }
  function expand(tpl, { id, bandwidth, number, time }) {
    return tpl.replace(/\$(RepresentationID|Number|Bandwidth|Time)(?:%0(\d+)d)?\$/g, (_m, k, pad) => {
      const v = { RepresentationID: id, Number: number, Bandwidth: bandwidth, Time: time }[k];
      return pad ? String(v).padStart(+pad, "0") : String(v);
    }).replace(/\$\$/g, "$");
  }
  var mergeAttrs = (...els) => Object.assign({}, ...els.filter(Boolean).map((e) => e.attrs));
  var baseOf = (el, parent) => {
    const b = kid(el, "BaseURL");
    return b ? resolveUrl(b.text.trim(), parent) : parent;
  };
  function parseDash(text, mpdUrl) {
    const mpd = parseXml(text);
    if (!mpd || mpd.name !== "MPD") throw new Error("Not a DASH manifest");
    const dynamic = mpd.attrs.type === "dynamic";
    const mpdBase = baseOf(mpd, mpdUrl);
    const periods = kids(mpd, "Period");
    const total = parseIsoDuration(mpd.attrs.mediaPresentationDuration);
    const pDur = (p) => parseIsoDuration(p.attrs.duration) || total / Math.max(1, periods.length);
    const period = periods.slice().sort((a, b) => pDur(b) - pDur(a))[0];
    if (!period) throw new Error("MPD has no Period");
    const periodDuration = pDur(period) || total;
    const periodBase = baseOf(period, mpdBase);
    const out = { video: [], audio: [], encrypted: false, dynamic, duration: periodDuration };
    for (const as of kids(period, "AdaptationSet")) {
      const asBase = baseOf(as, periodBase);
      if (kids(as, "ContentProtection").length) out.encrypted = true;
      for (const rep of kids(as, "Representation")) {
        if (kids(rep, "ContentProtection").length) out.encrypted = true;
        const a = mergeAttrs(as, rep);
        const mime = a.mimeType || "";
        const ctype = a.contentType || mime.split("/")[0] || (a.codecs && /^(avc|hev|hvc|vp|av01)/.test(a.codecs) ? "video" : a.codecs && /^(mp4a|ac-3|ec-3|opus)/.test(a.codecs) ? "audio" : "");
        if (ctype !== "video" && ctype !== "audio") continue;
        const base = baseOf(rep, asBase);
        const st = kid(rep, "SegmentTemplate") || kid(as, "SegmentTemplate");
        const sl = kid(rep, "SegmentList") || kid(as, "SegmentList");
        const sb = kid(rep, "SegmentBase") || kid(as, "SegmentBase");
        const r = {
          id: rep.attrs.id,
          type: ctype,
          bandwidth: +a.bandwidth || 0,
          width: +a.width || 0,
          height: +a.height || 0,
          codecs: a.codecs || "",
          mimeType: mime,
          lang: a.lang || "",
          frameRate: a.frameRate || "",
          init: null,
          segments: [],
          single: false
        };
        if (st) {
          const t = st.attrs, timescale = +t.timescale || 1;
          const ctx = { id: r.id, bandwidth: r.bandwidth };
          if (t.initialization) r.init = { url: resolveUrl(expand(t.initialization, ctx), base) };
          const media = t.media;
          const tl = kid(st, "SegmentTimeline");
          if (tl) {
            let time = 0, num = +(t.startNumber ?? 1);
            for (const s of kids(tl, "S")) {
              if (s.attrs.t !== void 0) time = +s.attrs.t;
              const d = +s.attrs.d;
              let rep_ = +(s.attrs.r || 0);
              if (rep_ < 0) rep_ = Math.max(0, Math.ceil((periodDuration * timescale - time) / d) - 1);
              for (let i = 0; i <= rep_; i++) {
                r.segments.push({ url: resolveUrl(expand(media, { ...ctx, number: num++, time }), base) });
                time += d;
              }
            }
          } else {
            const d = +t.duration;
            const start = +(t.startNumber ?? 1);
            if (!d) throw new Error("SegmentTemplate without duration/timeline");
            const count = Math.ceil(periodDuration * timescale / d);
            for (let i = 0; i < count; i++) r.segments.push({ url: resolveUrl(expand(media, { ...ctx, number: start + i, time: i * d }), base) });
          }
        } else if (sl) {
          const ini = kid(sl, "Initialization");
          if (ini) r.init = { url: resolveUrl(ini.attrs.sourceURL || "", base) || base, range: ini.attrs.range ? ini.attrs.range.split("-").map(Number) : null };
          for (const u of kids(sl, "SegmentURL")) {
            r.segments.push({ url: u.attrs.media ? resolveUrl(u.attrs.media, base) : base, range: u.attrs.mediaRange ? u.attrs.mediaRange.split("-").map(Number) : null });
          }
        } else if (sb || kid(rep, "BaseURL")) {
          r.single = true;
          r.segments.push({ url: base });
        } else continue;
        out[ctype].push(r);
      }
    }
    const byQ = (a, b) => b.height - a.height || b.bandwidth - a.bandwidth;
    out.video.sort(byQ);
    out.audio.sort((a, b) => b.bandwidth - a.bandwidth);
    return out;
  }

  // src/core/analyze.js
  var fmtRate = (bps) => bps ? bps >= 1e6 ? `${(bps / 1e6).toFixed(1)} Mbps` : `${Math.round(bps / 1e3)} kbps` : "";
  var optionLabel = (o) => [o.height ? `${o.height}p` : o.audioOnly ? "Audio" : "", o.frameRate && +o.frameRate > 30 ? `${Math.round(o.frameRate)}fps` : "", fmtRate(o.bandwidth)].filter(Boolean).join(" \xB7 ") || "Default";
  async function analyzeManifest(url, opts = {}) {
    const text = await fetchText(url, opts);
    const head = text.slice(0, 2e3);
    if (head.includes("#EXTM3U")) {
      const pl = parseHls(text, url);
      if (pl.type === "master") {
        return { kind: "hls", url, isMaster: true, options: pl.variants.map((v, i) => ({ id: String(i), width: v.width, height: v.height, bandwidth: v.bandwidth, codecs: v.codecs, frameRate: v.frameRate, label: optionLabel(v), url: v.url })), childUrls: pl.variants.map((v) => v.url).concat(pl.audio.map((a) => a.url)), problem: pl.variants.length ? null : "empty" };
      }
      const enc = pl.segments.find((s) => s.key)?.key;
      let problem = null;
      if (enc && enc.method !== "AES-128") problem = "drm";
      else if (enc && enc.format !== "identity") problem = "drm";
      else if (!pl.segments.length) problem = "empty";
      return { kind: "hls", url, isMaster: false, duration: pl.duration, live: !pl.endlist, options: [{ id: "0", label: "Default", bandwidth: 0 }], problem };
    }
    if (head.includes("<MPD")) {
      const d = parseDash(text, url);
      const list = d.video.length ? d.video : d.audio;
      const problem = d.encrypted ? "drm" : !list.length ? "empty" : list.every((r) => /webm|vp9|vp8|opus/i.test(r.mimeType + r.codecs)) ? "webm" : null;
      return {
        kind: "dash",
        url,
        isMaster: true,
        duration: d.duration,
        live: d.dynamic,
        problem,
        options: list.map((r, i) => ({ id: String(i), width: r.width, height: r.height, bandwidth: r.bandwidth, codecs: r.codecs, frameRate: r.frameRate, audioOnly: !d.video.length, label: optionLabel({ ...r, audioOnly: !d.video.length }) }))
      };
    }
    throw new Error("Not a recognised manifest");
  }

  // src/background.js
  var api = globalThis.browser ?? globalThis.chrome;
  var S = { media: {}, jobs: {}, seq: 0, dl: {} };
  var settings = { auto: false, concurrency: 6, saveAs: false, maxGB: 0 };
  var history = [];
  var persistTimer;
  var histPersistTimer;
  var ready = (async () => {
    try {
      const s = await api.storage.session.get("state");
      if (s.state) S = { ...S, ...s.state };
    } catch {
    }
    try {
      const l = await api.storage.local.get(["settings", "history"]);
      Object.assign(settings, l.settings || {});
      if (Array.isArray(l.history)) history = l.history;
    } catch {
    }
  })();
  var persist = () => {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => api.storage.session.set({ state: S }).catch(() => {
    }), 150);
  };
  var HIST_MAX = 200;
  var persistHistory = () => {
    clearTimeout(histPersistTimer);
    histPersistTimer = setTimeout(() => api.storage.local.set({ history }).catch(() => {
    }), 300);
  };
  var histUnshift = (e) => {
    history.unshift(e);
    if (history.length > HIST_MAX) history = history.slice(0, HIST_MAX);
    persistHistory();
  };
  var histFind = (id) => history.find((h) => h.id === id);
  var SEGMENT_EXT = /\.(ts|m4s|m4f|cmfv|cmfa|aac|vtt|webvtt|key|jpg|jpeg|png|gif|webp|svg|ico|js|css|json|html?)$/i;
  var FILE_EXT = /\.(mp4|webm|m4v|mov|mkv|ogv|mp3|m4a|ogg|opus|flac|wav)$/i;
  var hdr = (headers, name) => headers?.find((h) => h.name.toLowerCase() === name)?.value || "";
  function classify(d) {
    const ct = hdr(d.responseHeaders, "content-type").split(";")[0].trim().toLowerCase();
    let path = "";
    try {
      path = new URL(d.url).pathname;
    } catch {
      return null;
    }
    if (/\.m3u8$/i.test(path) || /mpegurl/.test(ct)) return { kind: "hls", ct };
    if (/\.mpd$/i.test(path) || ct === "application/dash+xml") return { kind: "dash", ct };
    if (SEGMENT_EXT.test(path) || ct === "video/mp2t" || ct === "video/iso.segment" || ct === "video/vnd.dlna.mpeg-tts") return null;
    const cr = /\/(\d+)$/.exec(hdr(d.responseHeaders, "content-range"));
    const size = cr ? +cr[1] : +hdr(d.responseHeaders, "content-length") || 0;
    if ((ct.startsWith("video/") || ct.startsWith("audio/") || FILE_EXT.test(path) && !/html|json|text/.test(ct) || ct === "application/mp4") && size >= 300 * 1024 && d.statusCode < 400) return { kind: "file", ct, size };
    return null;
  }
  var origin = (u) => {
    try {
      return new URL(u).origin;
    } catch {
      return "";
    }
  };
  var tabEntry = (tabId) => S.media[tabId] ||= { items: [], blob: false };
  var ruleSeq = 1e3 + Math.floor(Math.random() * 1e6);
  async function addHeaderRule(pageUrl) {
    if (!pageUrl || !/^https?:/.test(pageUrl) || !api.declarativeNetRequest) return 0;
    const id = ++ruleSeq;
    const rule = { id, priority: id, action: { type: "modifyHeaders", requestHeaders: [{ header: "referer", operation: "set", value: pageUrl }, { header: "origin", operation: "set", value: origin(pageUrl) }] }, condition: { tabIds: [-1], resourceTypes: ["xmlhttprequest", "other", "media"] } };
    try {
      await api.declarativeNetRequest.updateSessionRules({ addRules: [rule] });
      return id;
    } catch {
      return 0;
    }
  }
  var removeHeaderRule = (id) => id && api.declarativeNetRequest?.updateSessionRules({ removeRuleIds: [id] }).catch(() => {
  });
  async function addCandidate({ tabId, url, kind, size, ct, pageUrl }) {
    await ready;
    if (!/^https?:/i.test(url) || tabId < 0) return;
    const te = tabEntry(tabId);
    if (te.items.some((i) => i.url === url)) return;
    let title = "", tabUrl = "";
    try {
      const tab = await api.tabs.get(tabId);
      title = tab.title || "";
      tabUrl = tab.url || "";
    } catch {
    }
    if (!pageUrl || /^https?:\/\/[^/]+$/.test(pageUrl)) pageUrl = tabUrl && origin(tabUrl) === origin(pageUrl || tabUrl) ? tabUrl : pageUrl ? `${pageUrl}/` : tabUrl;
    const item = { id: `m${++S.seq}`, url, kind, size: size || 0, ct: ct || "", pageUrl: pageUrl || "", title, t: Date.now(), state: kind === "file" ? "ready" : "analyzing", options: [], hidden: false };
    te.items.push(item);
    persist();
    updateBadge(tabId);
    if (item.kind === "file") {
      maybeAuto(tabId, item);
      return;
    }
    const rid = await addHeaderRule(item.pageUrl);
    try {
      const a = await analyzeManifest(url);
      item.kind = a.kind;
      item.options = a.options;
      item.problem = a.problem;
      item.duration = a.duration;
      item.live = a.live;
      item.isMaster = a.isMaster;
      item.state = "ready";
      if (a.childUrls) {
        for (const other of te.items) if (a.childUrls.includes(other.url)) other.hidden = true;
      }
      if (te.items.some((o) => o !== item && o.childUrls?.includes(url))) item.hidden = true;
      item.childUrls = a.childUrls;
    } catch (e) {
      te.items = te.items.filter((i) => i !== item);
      if (kind !== "sniffed") console.debug("[streamgrab] analysis failed", url, e.message);
    } finally {
      await removeHeaderRule(rid);
      persist();
      updateBadge(tabId);
    }
    if (item.state === "ready") maybeAuto(tabId, item);
  }
  function maybeAuto(tabId, item) {
    if (!settings.auto || item.kind === "file") return;
    setTimeout(async () => {
      await ready;
      if (item.hidden || item.problem || item.live || item.jobId) return;
      startDownload({ tabId, itemId: item.id, optionId: "0" });
    }, 2500);
  }
  function updateBadge(tabId) {
    const n = (S.media[tabId]?.items || []).filter((i) => !i.hidden && !i.problem).length;
    try {
      api.action.setBadgeText({ tabId, text: n ? String(n) : "" });
      api.action.setBadgeBackgroundColor({ tabId, color: "#2563eb" });
    } catch {
    }
  }
  api.webRequest.onHeadersReceived.addListener((d) => {
    if (d.tabId < 0) return;
    const c = classify(d);
    if (!c) return;
    addCandidate({ tabId: d.tabId, url: d.url, pageUrl: d.documentUrl || d.originUrl || d.initiator || "", ...c });
  }, { urls: ["<all_urls>"], types: ["xmlhttprequest", "media", "other", "object", "main_frame", "sub_frame"] }, ["responseHeaders"]);
  api.tabs.onUpdated.addListener(async (tabId, info) => {
    if (info.status === "loading" && info.url) {
      await ready;
      delete S.media[tabId];
      persist();
      updateBadge(tabId);
    }
  });
  api.tabs.onRemoved.addListener(async (tabId) => {
    await ready;
    delete S.media[tabId];
    persist();
  });
  var asciiName = (n) => n.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7e]+/g, "_");
  async function saveFile(opts) {
    try {
      return await api.downloads.download(opts);
    } catch (e) {
      if (!/filename/i.test(e.message)) throw e;
      return api.downloads.download({ ...opts, filename: asciiName(opts.filename) });
    }
  }
  var findItem = (itemId) => {
    for (const [tabId, te] of Object.entries(S.media)) {
      const it = te.items.find((i) => i.id === itemId);
      if (it) return { tabId: +tabId, item: it };
    }
    return null;
  };
  var setJob = (job, patch) => {
    Object.assign(job, patch);
    persist();
  };
  function makeJob(base, extra = {}) {
    const job = { id: `j${++S.seq}`, status: "running", phase: "download", pct: 0, bytes: 0, error: "", t: Date.now(), ...base, ...extra };
    S.jobs[job.id] = job;
    persist();
    return job;
  }
  async function ensureOffscreen() {
    const ctx = await api.runtime.getContexts?.({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    if (ctx?.length) return;
    await api.offscreen.createDocument({ url: "engine.html", reasons: ["BLOBS"], justification: "Assemble downloaded video segments into one MP4 file" });
  }
  async function engineSend(msg) {
    if (false) {
      const h = await null;
      if (msg.type === "start") h.startJob(msg.job, onEngineMsg);
      else if (msg.type === "cancel") h.cancelJob(msg.jobId);
      else if (msg.type === "revoke") h.revoke(msg.url);
      return;
    }
    await ensureOffscreen();
    await api.runtime.sendMessage({ target: "engine", ...msg });
  }
  async function startDownload({ tabId, itemId, optionId = "0" }) {
    await ready;
    const f = findItem(itemId);
    if (!f) return { error: "not-found" };
    const { item } = f;
    let title = item.title;
    try {
      title = (await api.tabs.get(tabId ?? f.tabId)).title || title;
    } catch {
    }
    const opt = item.options.find((o) => o.id === String(optionId));
    const base = sanitizeFilename(title || new URL(item.url).hostname);
    const meta = { itemKind: item.kind, srcUrl: item.url, pageUrl: item.pageUrl, options: item.options, page: item.title };
    if (item.kind === "file") {
      const ext = /\.([a-z0-9]{2,4})(?:$|\?)/i.exec(new URL(item.url).pathname)?.[1] || "mp4";
      const job2 = makeJob({ tabId: f.tabId, itemId, title: base, quality: "", filename: `${base}.${ext}` }, meta);
      item.jobId = job2.id;
      persist();
      job2.rule = await addHeaderRule(item.pageUrl);
      try {
        const id = await saveFile({ url: item.url, filename: `${base}.${ext}`, saveAs: settings.saveAs, conflictAction: "uniquify" });
        S.dl[id] = job2.id;
        setJob(job2, { status: "saving", phase: "save" });
      } catch (e) {
        setJob(job2, { status: "error", error: e.message });
        removeHeaderRule(job2.rule);
      }
      return { jobId: job2.id };
    }
    const job = makeJob({ tabId: f.tabId, itemId, title: base, quality: opt?.label || "", filename: `${base}${opt?.height ? ` [${opt.height}p]` : ""}.mp4` }, { ...meta, optionId: String(optionId) });
    item.jobId = job.id;
    persist();
    job.rule = await addHeaderRule(item.pageUrl);
    engineSend({ type: "start", job: { jobId: job.id, url: item.url, kind: item.kind, optionId: String(optionId), concurrency: settings.concurrency, maxBytes: settings.maxGB ? Math.round(settings.maxGB * 1024 ** 3) : 0 } }).catch((e) => onEngineMsg({ type: "error", jobId: job.id, message: e.message }));
    return { jobId: job.id };
  }
  async function startHistDownload({ histId, optionId = "0" }) {
    await ready;
    const e = histFind(histId);
    if (!e) return { error: "not-found" };
    if (e.kind === "file") {
      const base2 = sanitizeFilename(e.title || new URL(e.srcUrl || "x://v").hostname);
      const job2 = makeJob({ histId, title: base2, quality: e.quality || "", filename: e.filename, itemKind: "file", srcUrl: e.srcUrl, pageUrl: e.pageUrl });
      job2.rule = await addHeaderRule(e.pageUrl);
      try {
        const id = await saveFile({ url: e.srcUrl, filename: e.filename, saveAs: settings.saveAs, conflictAction: "uniquify" });
        S.dl[id] = job2.id;
        setJob(job2, { status: "saving", phase: "save" });
      } catch (err) {
        setJob(job2, { status: "error", error: String(err?.message || err) });
        removeHeaderRule(job2.rule);
      }
      return { jobId: job2.id };
    }
    let options = [];
    try {
      const a = await analyzeManifest(e.srcUrl);
      if (a.problem) return { error: a.problem };
      options = a.options;
    } catch {
      return { error: "manifest-unavailable" };
    }
    const want = String(optionId ?? e.optionId ?? "0");
    const optId = options.some((o) => o.id === want) ? want : "0";
    const opt = options.find((o) => o.id === optId);
    const base = sanitizeFilename(e.title || "video");
    const job = makeJob({ histId, title: base, quality: opt?.label || "", filename: `${base}${opt?.height ? ` [${opt.height}p]` : ""}.mp4`, itemKind: e.kind, srcUrl: e.srcUrl, pageUrl: e.pageUrl, options, optionId: optId });
    job.rule = await addHeaderRule(e.pageUrl);
    engineSend({ type: "start", job: { jobId: job.id, url: e.srcUrl, kind: e.kind, optionId: optId, concurrency: settings.concurrency, maxBytes: settings.maxGB ? Math.round(settings.maxGB * 1024 ** 3) : 0 } }).catch((err) => onEngineMsg({ type: "error", jobId: job.id, message: String(err?.message || err) }));
    return { jobId: job.id };
  }
  async function onEngineMsg(m) {
    await ready;
    const job = S.jobs[m.jobId];
    if (!job) return;
    if (m.type === "progress") setJob(job, { phase: m.phase, pct: m.total ? Math.round(m.done / m.total * 100) : 0, bytes: m.bytes, status: m.phase === "mux" ? "muxing" : "running" });
    else if (m.type === "done") {
      setJob(job, { status: "saving", phase: "save", pct: 100, size: m.size });
      try {
        const id = await saveFile({ url: m.blobUrl, filename: job.filename, saveAs: settings.saveAs, conflictAction: "uniquify" });
        S.dl[id] = job.id;
        job.blobUrl = m.blobUrl;
        persist();
      } catch (e) {
        setJob(job, { status: "error", error: e.message });
        engineSend({ type: "revoke", url: m.blobUrl });
        removeHeaderRule(job.rule);
      }
    } else if (m.type === "error") {
      setJob(job, { status: "error", error: m.message });
      removeHeaderRule(job.rule);
    } else if (m.type === "cancelled") {
      setJob(job, { status: "cancelled" });
      removeHeaderRule(job.rule);
    }
  }
  async function recordHistory(job, dlId) {
    if (!job.filename) return;
    try {
      const d = await api.downloads.search({ id: dlId }).catch(() => []);
      if (!d[0]) return;
      histUnshift({
        id: `h${++S.seq}`,
        fin: Date.now(),
        title: job.title,
        filename: String(job.filename).split("/").pop(),
        quality: job.quality || "",
        kind: job.itemKind || "",
        size: d[0].fileSize || job.size || 0,
        srcUrl: job.srcUrl || "",
        pageUrl: job.pageUrl || "",
        page: job.page || "",
        options: job.options || [],
        optionId: job.optionId || "",
        dlId
      });
    } catch {
    }
  }
  api.downloads.onChanged.addListener(async (delta) => {
    await ready;
    const jobId = S.dl[delta.id];
    const job = jobId && S.jobs[jobId];
    if (!job) return;
    const st = delta.state?.current;
    if (!st || st === "in_progress") return;
    if (st === "complete") {
      setJob(job, { status: "done" });
      recordHistory(job, delta.id);
    } else {
      setJob(job, { status: "error", error: delta.error?.current || "download interrupted" });
    }
    if (job.blobUrl) engineSend({ type: "revoke", url: job.blobUrl });
    removeHeaderRule(job.rule);
    delete S.dl[delta.id];
    persist();
  });
  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.target === "engine") return false;
    (async () => {
      await ready;
      switch (msg?.type) {
        case "sniffed": {
          const tabId = sender.tab?.id;
          if (tabId >= 0) addCandidate({ tabId, url: msg.url, kind: "sniffed", pageUrl: msg.frameUrl || sender.url || "" });
          return sendResponse({});
        }
        case "blob": {
          if (sender.tab) {
            tabEntry(sender.tab.id).blob = true;
            persist();
          }
          return sendResponse({});
        }
        case "getState": {
          const te = S.media[msg.tabId] || { items: [], blob: false };
          const items = te.items.filter((i) => !i.hidden).map(({ childUrls, ...i }) => ({ ...i, job: i.jobId ? S.jobs[i.jobId] : null }));
          return sendResponse({ items, blob: te.blob, settings });
        }
        case "download":
          return sendResponse(await startDownload(msg));
        case "cancel": {
          const job = S.jobs[msg.jobId];
          if (job) {
            engineSend({ type: "cancel", jobId: job.id });
          }
          return sendResponse({});
        }
        case "clear": {
          delete S.media[msg.tabId];
          persist();
          updateBadge(msg.tabId);
          return sendResponse({});
        }
        case "setSettings": {
          Object.assign(settings, msg.settings);
          await api.storage.local.set({ settings });
          return sendResponse(settings);
        }
        case "getHistory": {
          const stats = history.reduce((a, e) => {
            a.count++;
            a.bytes += e.size || 0;
            return a;
          }, { count: 0, bytes: 0 });
          const jobs = Object.values(S.jobs).filter((j) => j.histId);
          return sendResponse({ items: history, stats, jobs });
        }
        case "histDownload":
          return sendResponse(await startHistDownload(msg));
        case "histRemove": {
          const h = histFind(msg.histId);
          if (h) {
            history = history.filter((x) => x !== h);
            persistHistory();
          }
          return sendResponse({});
        }
        case "histClear": {
          history = [];
          persistHistory();
          return sendResponse({});
        }
        case "openFile": {
          try {
            await api.downloads.open(+msg.dlId);
          } catch {
            try {
              await api.downloads.show(+msg.dlId);
            } catch {
              try {
                await api.downloads.showDefaultFolder();
              } catch {
              }
            }
          }
          return sendResponse({});
        }
        case "showFile": {
          try {
            await api.downloads.show(+msg.dlId);
          } catch {
            try {
              await api.downloads.showDefaultFolder();
            } catch {
            }
          }
          return sendResponse({});
        }
        case "rescan":
          return sendResponse({});
        default:
          if (msg?.target === "bg") {
            await onEngineMsg(msg);
          }
          return sendResponse({});
      }
    })();
    return true;
  });
})();
