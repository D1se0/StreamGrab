(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // src/core/util.js
  async function fetchBytes(url, opts = {}) {
    const f = opts.fetch || globalThis.fetch.bind(globalThis);
    const retries = opts.retries ?? 3;
    let lastErr;
    for (let i = 0; i <= retries; i++) {
      if (opts.signal?.aborted) throw new AbortError();
      try {
        const headers = {};
        if (opts.range) headers.Range = `bytes=${opts.range[0]}-${opts.range[1]}`;
        const res = await f(url, { headers, signal: opts.signal, credentials: "include", cache: "no-store" });
        if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status} for ${url}`);
        let buf = new Uint8Array(await res.arrayBuffer());
        if (opts.range && res.status === 200) buf = buf.subarray(opts.range[0], opts.range[1] + 1);
        return buf;
      } catch (e) {
        if (opts.signal?.aborted || e.name === "AbortError") throw new AbortError();
        lastErr = e;
        await new Promise((r) => setTimeout(r, 300 * 2 ** i));
      }
    }
    throw lastErr;
  }
  async function* orderedPool(tasks, concurrency = 6, signal) {
    const results = /* @__PURE__ */ new Map();
    let next = 0, inflight = 0, consumed = 0, failure;
    const waiters = [];
    const wake = () => {
      while (waiters.length) waiters.shift()();
    };
    const pump = () => {
      while (!failure && inflight < concurrency && next < tasks.length && next - consumed < concurrency * 2) {
        const i = next++;
        inflight++;
        tasks[i]().then((v) => results.set(i, v), (e) => {
          failure = failure || e;
        }).finally(() => {
          inflight--;
          pump();
          wake();
        });
      }
    };
    pump();
    for (let i = 0; i < tasks.length; i++) {
      while (!results.has(i)) {
        if (failure) throw failure;
        if (signal?.aborted) throw new AbortError();
        await new Promise((r) => waiters.push(r));
      }
      const v = results.get(i);
      results.delete(i);
      consumed = i + 1;
      pump();
      yield v;
    }
  }
  var resolveUrl, AbortError, fetchText, sanitizeFilename;
  var init_util = __esm({
    "src/core/util.js"() {
      resolveUrl = (rel, base) => {
        try {
          return new URL(rel, base).href;
        } catch {
          return rel;
        }
      };
      AbortError = class extends Error {
        constructor() {
          super("Cancelled");
          this.name = "AbortError";
        }
      };
      fetchText = async (url, opts) => new TextDecoder().decode(await fetchBytes(url, opts));
      sanitizeFilename = (s, fallback = "video") => String(s || "").replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 120) || fallback;
    }
  });

  // src/core/hls.js
  function attrs(line) {
    const out = {};
    const re = /([A-Z0-9-]+)=("([^"]*)"|[^,]*)/g;
    let m;
    while (m = re.exec(line)) out[m[1]] = m[3] !== void 0 ? m[3] : m[2];
    return out;
  }
  function parseHls(text, baseUrl) {
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (!lines[0]?.startsWith("#EXTM3U")) throw new Error("Not an HLS playlist");
    const isMaster = lines.some((l) => l.startsWith("#EXT-X-STREAM-INF"));
    return isMaster ? parseMaster(lines, baseUrl) : parseMedia(lines, baseUrl);
  }
  function parseMaster(lines, baseUrl) {
    const variants = [], audio = [], subtitles = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (l.startsWith("#EXT-X-STREAM-INF:")) {
        const a = attrs(l.slice(18));
        let j = i + 1;
        while (j < lines.length && lines[j].startsWith("#")) j++;
        if (!lines[j]) continue;
        const [w, h] = (a.RESOLUTION || "").split("x").map(Number);
        variants.push({
          url: resolveUrl(lines[j], baseUrl),
          bandwidth: +(a["AVERAGE-BANDWIDTH"] || a.BANDWIDTH || 0),
          width: w || 0,
          height: h || 0,
          codecs: a.CODECS || "",
          audioGroup: a.AUDIO || null,
          frameRate: a["FRAME-RATE"] ? +a["FRAME-RATE"] : 0
        });
      } else if (l.startsWith("#EXT-X-MEDIA:")) {
        const a = attrs(l.slice(13));
        if (a.TYPE === "AUDIO" && a.URI) audio.push({ url: resolveUrl(a.URI, baseUrl), group: a["GROUP-ID"], name: a.NAME, lang: a.LANGUAGE, default: a.DEFAULT === "YES" });
        else if (a.TYPE === "SUBTITLES" && a.URI) subtitles.push({ url: resolveUrl(a.URI, baseUrl), name: a.NAME, lang: a.LANGUAGE });
      }
    }
    variants.sort((a, b) => b.height - a.height || b.bandwidth - a.bandwidth);
    return { type: "master", variants, audio, subtitles };
  }
  function parseMedia(lines, baseUrl) {
    const segments = [];
    let key = null, map = null, seq = 0, targetDuration = 0, endlist = false;
    let pendingDur = 0, pendingRange = null, lastRangeEnd = 0, discontinuity = false;
    for (const l of lines) {
      if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) seq = +l.split(":")[1];
      else if (l.startsWith("#EXT-X-TARGETDURATION:")) targetDuration = +l.split(":")[1];
      else if (l.startsWith("#EXT-X-ENDLIST")) endlist = true;
      else if (l.startsWith("#EXT-X-DISCONTINUITY") && !l.startsWith("#EXT-X-DISCONTINUITY-")) discontinuity = true;
      else if (l.startsWith("#EXT-X-KEY:")) {
        const a = attrs(l.slice(11));
        key = a.METHOD === "NONE" ? null : { method: a.METHOD, url: a.URI ? resolveUrl(a.URI, baseUrl) : null, iv: a.IV ? hexToBytes(a.IV) : null, format: a.KEYFORMAT || "identity" };
      } else if (l.startsWith("#EXT-X-MAP:")) {
        const a = attrs(l.slice(11));
        map = { url: resolveUrl(a.URI, baseUrl), range: a.BYTERANGE ? parseRange(a.BYTERANGE, 0) : null };
      } else if (l.startsWith("#EXTINF:")) pendingDur = parseFloat(l.slice(8));
      else if (l.startsWith("#EXT-X-BYTERANGE:")) pendingRange = l.slice(17);
      else if (!l.startsWith("#")) {
        let range = null;
        if (pendingRange) {
          range = parseRange(pendingRange, lastRangeEnd);
          lastRangeEnd = range[1] + 1;
        }
        segments.push({ url: resolveUrl(l, baseUrl), duration: pendingDur, range, key, map, seq: seq + segments.length, discontinuity });
        pendingDur = 0;
        pendingRange = null;
        discontinuity = false;
      }
    }
    return { type: "media", segments, endlist, targetDuration, duration: segments.reduce((s, x) => s + x.duration, 0) };
  }
  function parseRange(s, defaultStart) {
    const [len, off] = s.split("@").map(Number);
    const start = off !== void 0 && !Number.isNaN(off) ? off : defaultStart;
    return [start, start + len - 1];
  }
  var hexToBytes;
  var init_hls = __esm({
    "src/core/hls.js"() {
      init_util();
      hexToBytes = (hex) => {
        hex = hex.replace(/^0x/i, "").padStart(32, "0");
        return Uint8Array.from(hex.match(/../g).map((h) => parseInt(h, 16)));
      };
    }
  });

  // src/core/xml.js
  function parseXml(src) {
    const root = { name: "#root", attrs: {}, children: [], text: "" };
    const stack = [root];
    const re = /<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<\/([^\s>]+)\s*>|<([^\s/>!?]+)((?:\s+[^\s=/>]+(?:\s*=\s*(?:"[^"]*"|'[^']*'))?)*)\s*(\/?)>|([^<]+)/g;
    let m;
    while (m = re.exec(src)) {
      const top = stack[stack.length - 1];
      if (m[1] !== void 0) top.text += m[1];
      else if (m[2]) {
        if (stack.length > 1) stack.pop();
      } else if (m[3]) {
        const el = { name: m[3].replace(/^.*:/, ""), attrs: {}, children: [], text: "" };
        const ar = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'))?/g;
        let a;
        while (a = ar.exec(m[4] || "")) el.attrs[a[1].replace(/^.*:/, "")] = unescapeXml(a[2] ?? a[3] ?? "");
        top.children.push(el);
        if (!m[5]) stack.push(el);
      } else if (m[6] !== void 0) top.text += unescapeXml(m[6]);
    }
    return root.children[0];
  }
  var ENT, unescapeXml, kids, kid;
  var init_xml = __esm({
    "src/core/xml.js"() {
      ENT = { "&lt;": "<", "&gt;": ">", "&amp;": "&", "&quot;": '"', "&apos;": "'" };
      unescapeXml = (s) => s.replace(/&(lt|gt|amp|quot|apos);|&#(\d+);|&#x([0-9a-f]+);/gi, (m, _n, d, h) => ENT[m] || String.fromCodePoint(d ? parseInt(d, 10) : parseInt(h, 16)));
      kids = (el, name) => el ? el.children.filter((c) => c.name === name) : [];
      kid = (el, name) => kids(el, name)[0];
    }
  });

  // src/core/dash.js
  function parseIsoDuration(s) {
    if (!s) return 0;
    const m = /^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec(s);
    if (!m) return 0;
    return (+m[1] || 0) * 86400 + (+m[2] || 0) * 3600 + (+m[3] || 0) * 60 + (+m[4] || 0);
  }
  function expand(tpl, { id, bandwidth, number, time }) {
    return tpl.replace(/\$(RepresentationID|Number|Bandwidth|Time)(?:%0(\d+)d)?\$/g, (_m, k, pad) => {
      const v = { RepresentationID: id, Number: number, Bandwidth: bandwidth, Time: time }[k];
      return pad ? String(v).padStart(+pad, "0") : String(v);
    }).replace(/\$\$/g, "$");
  }
  function parseDash(text, mpdUrl) {
    const mpd = parseXml(text);
    if (!mpd || mpd.name !== "MPD") throw new Error("Not a DASH manifest");
    const dynamic = mpd.attrs.type === "dynamic";
    const mpdBase = baseOf(mpd, mpdUrl);
    const periods = kids(mpd, "Period");
    const total = parseIsoDuration(mpd.attrs.mediaPresentationDuration);
    const pDur = (p) => parseIsoDuration(p.attrs.duration) || total / Math.max(1, periods.length);
    const period = periods.slice().sort((a, b) => pDur(b) - pDur(a))[0];
    if (!period) throw new Error("MPD has no Period");
    const periodDuration = pDur(period) || total;
    const periodBase = baseOf(period, mpdBase);
    const out = { video: [], audio: [], encrypted: false, dynamic, duration: periodDuration };
    for (const as of kids(period, "AdaptationSet")) {
      const asBase = baseOf(as, periodBase);
      if (kids(as, "ContentProtection").length) out.encrypted = true;
      for (const rep of kids(as, "Representation")) {
        if (kids(rep, "ContentProtection").length) out.encrypted = true;
        const a = mergeAttrs(as, rep);
        const mime = a.mimeType || "";
        const ctype = a.contentType || mime.split("/")[0] || (a.codecs && /^(avc|hev|hvc|vp|av01)/.test(a.codecs) ? "video" : a.codecs && /^(mp4a|ac-3|ec-3|opus)/.test(a.codecs) ? "audio" : "");
        if (ctype !== "video" && ctype !== "audio") continue;
        const base = baseOf(rep, asBase);
        const st = kid(rep, "SegmentTemplate") || kid(as, "SegmentTemplate");
        const sl = kid(rep, "SegmentList") || kid(as, "SegmentList");
        const sb = kid(rep, "SegmentBase") || kid(as, "SegmentBase");
        const r = {
          id: rep.attrs.id,
          type: ctype,
          bandwidth: +a.bandwidth || 0,
          width: +a.width || 0,
          height: +a.height || 0,
          codecs: a.codecs || "",
          mimeType: mime,
          lang: a.lang || "",
          frameRate: a.frameRate || "",
          init: null,
          segments: [],
          single: false
        };
        if (st) {
          const t = st.attrs, timescale = +t.timescale || 1;
          const ctx = { id: r.id, bandwidth: r.bandwidth };
          if (t.initialization) r.init = { url: resolveUrl(expand(t.initialization, ctx), base) };
          const media = t.media;
          const tl = kid(st, "SegmentTimeline");
          if (tl) {
            let time = 0, num = +(t.startNumber ?? 1);
            for (const s of kids(tl, "S")) {
              if (s.attrs.t !== void 0) time = +s.attrs.t;
              const d = +s.attrs.d;
              let rep_ = +(s.attrs.r || 0);
              if (rep_ < 0) rep_ = Math.max(0, Math.ceil((periodDuration * timescale - time) / d) - 1);
              for (let i = 0; i <= rep_; i++) {
                r.segments.push({ url: resolveUrl(expand(media, { ...ctx, number: num++, time }), base) });
                time += d;
              }
            }
          } else {
            const d = +t.duration;
            const start = +(t.startNumber ?? 1);
            if (!d) throw new Error("SegmentTemplate without duration/timeline");
            const count = Math.ceil(periodDuration * timescale / d);
            for (let i = 0; i < count; i++) r.segments.push({ url: resolveUrl(expand(media, { ...ctx, number: start + i, time: i * d }), base) });
          }
        } else if (sl) {
          const ini = kid(sl, "Initialization");
          if (ini) r.init = { url: resolveUrl(ini.attrs.sourceURL || "", base) || base, range: ini.attrs.range ? ini.attrs.range.split("-").map(Number) : null };
          for (const u of kids(sl, "SegmentURL")) {
            r.segments.push({ url: u.attrs.media ? resolveUrl(u.attrs.media, base) : base, range: u.attrs.mediaRange ? u.attrs.mediaRange.split("-").map(Number) : null });
          }
        } else if (sb || kid(rep, "BaseURL")) {
          r.single = true;
          r.segments.push({ url: base });
        } else continue;
        out[ctype].push(r);
      }
    }
    const byQ = (a, b) => b.height - a.height || b.bandwidth - a.bandwidth;
    out.video.sort(byQ);
    out.audio.sort((a, b) => b.bandwidth - a.bandwidth);
    return out;
  }
  var mergeAttrs, baseOf;
  var init_dash = __esm({
    "src/core/dash.js"() {
      init_xml();
      init_util();
      mergeAttrs = (...els) => Object.assign({}, ...els.filter(Boolean).map((e) => e.attrs));
      baseOf = (el, parent) => {
        const b = kid(el, "BaseURL");
        return b ? resolveUrl(b.text.trim(), parent) : parent;
      };
    }
  });

  // node_modules/global/window.js
  var require_window = __commonJS({
    "node_modules/global/window.js"(exports, module) {
      var win;
      if (typeof window !== "undefined") {
        win = window;
      } else if (typeof global !== "undefined") {
        win = global;
      } else if (typeof self !== "undefined") {
        win = self;
      } else {
        win = {};
      }
      module.exports = win;
    }
  });

  // node_modules/mux.js/dist/mux.js
  var require_mux = __commonJS({
    "node_modules/mux.js/dist/mux.js"(exports, module) {
      (function(global2, factory) {
        typeof exports === "object" && typeof module !== "undefined" ? module.exports = factory(require_window()) : typeof define === "function" && define.amd ? define(["global/window"], factory) : (global2 = typeof globalThis !== "undefined" ? globalThis : global2 || self, global2.muxjs = factory(global2.window));
      })(exports, (function(require$$8) {
        "use strict";
        function _interopDefaultLegacy(e) {
          return e && typeof e === "object" && "default" in e ? e : { "default": e };
        }
        var require$$8__default = /* @__PURE__ */ _interopDefaultLegacy(require$$8);
        var Stream$d = function Stream2() {
          this.init = function() {
            var listeners = {};
            this.on = function(type2, listener) {
              if (!listeners[type2]) {
                listeners[type2] = [];
              }
              listeners[type2] = listeners[type2].concat(listener);
            };
            this.off = function(type2, listener) {
              var index;
              if (!listeners[type2]) {
                return false;
              }
              index = listeners[type2].indexOf(listener);
              listeners[type2] = listeners[type2].slice();
              listeners[type2].splice(index, 1);
              return index > -1;
            };
            this.trigger = function(type2) {
              var callbacks, i, length, args;
              callbacks = listeners[type2];
              if (!callbacks) {
                return;
              }
              if (arguments.length === 2) {
                length = callbacks.length;
                for (i = 0; i < length; ++i) {
                  callbacks[i].call(this, arguments[1]);
                }
              } else {
                args = [];
                i = arguments.length;
                for (i = 1; i < arguments.length; ++i) {
                  args.push(arguments[i]);
                }
                length = callbacks.length;
                for (i = 0; i < length; ++i) {
                  callbacks[i].apply(this, args);
                }
              }
            };
            this.dispose = function() {
              listeners = {};
            };
          };
        };
        Stream$d.prototype.pipe = function(destination) {
          this.on("data", function(data) {
            destination.push(data);
          });
          this.on("done", function(flushSource) {
            destination.flush(flushSource);
          });
          this.on("partialdone", function(flushSource) {
            destination.partialFlush(flushSource);
          });
          this.on("endedtimeline", function(flushSource) {
            destination.endTimeline(flushSource);
          });
          this.on("reset", function(flushSource) {
            destination.reset(flushSource);
          });
          return destination;
        };
        Stream$d.prototype.push = function(data) {
          this.trigger("data", data);
        };
        Stream$d.prototype.flush = function(flushSource) {
          this.trigger("done", flushSource);
        };
        Stream$d.prototype.partialFlush = function(flushSource) {
          this.trigger("partialdone", flushSource);
        };
        Stream$d.prototype.endTimeline = function(flushSource) {
          this.trigger("endedtimeline", flushSource);
        };
        Stream$d.prototype.reset = function(flushSource) {
          this.trigger("reset", flushSource);
        };
        var stream = Stream$d;
        var ONE_SECOND_IN_TS$5 = 9e4, secondsToVideoTs, secondsToAudioTs, videoTsToSeconds, audioTsToSeconds, audioTsToVideoTs, videoTsToAudioTs, metadataTsToSeconds;
        secondsToVideoTs = function secondsToVideoTs2(seconds) {
          return seconds * ONE_SECOND_IN_TS$5;
        };
        secondsToAudioTs = function secondsToAudioTs2(seconds, sampleRate) {
          return seconds * sampleRate;
        };
        videoTsToSeconds = function videoTsToSeconds2(timestamp) {
          return timestamp / ONE_SECOND_IN_TS$5;
        };
        audioTsToSeconds = function audioTsToSeconds2(timestamp, sampleRate) {
          return timestamp / sampleRate;
        };
        audioTsToVideoTs = function audioTsToVideoTs2(timestamp, sampleRate) {
          return secondsToVideoTs(audioTsToSeconds(timestamp, sampleRate));
        };
        videoTsToAudioTs = function videoTsToAudioTs2(timestamp, sampleRate) {
          return secondsToAudioTs(videoTsToSeconds(timestamp), sampleRate);
        };
        metadataTsToSeconds = function metadataTsToSeconds2(timestamp, timelineStartPts, keepOriginalTimestamps) {
          return videoTsToSeconds(keepOriginalTimestamps ? timestamp : timestamp - timelineStartPts);
        };
        var clock$3 = {
          ONE_SECOND_IN_TS: ONE_SECOND_IN_TS$5,
          secondsToVideoTs,
          secondsToAudioTs,
          videoTsToSeconds,
          audioTsToSeconds,
          audioTsToVideoTs,
          videoTsToAudioTs,
          metadataTsToSeconds
        };
        var Stream$c = stream;
        var ONE_SECOND_IN_TS$4 = clock$3.ONE_SECOND_IN_TS;
        var _AdtsStream;
        var ADTS_SAMPLING_FREQUENCIES$1 = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350];
        _AdtsStream = function AdtsStream2(handlePartialSegments) {
          var buffer, frameNum = 0;
          _AdtsStream.prototype.init.call(this);
          this.skipWarn_ = function(start, end) {
            this.trigger("log", {
              level: "warn",
              message: "adts skiping bytes " + start + " to " + end + " in frame " + frameNum + " outside syncword"
            });
          };
          this.push = function(packet) {
            var i = 0, frameLength, protectionSkipBytes, oldBuffer, sampleCount, adtsFrameDuration;
            if (!handlePartialSegments) {
              frameNum = 0;
            }
            if (packet.type !== "audio") {
              return;
            }
            if (buffer && buffer.length) {
              oldBuffer = buffer;
              buffer = new Uint8Array(oldBuffer.byteLength + packet.data.byteLength);
              buffer.set(oldBuffer);
              buffer.set(packet.data, oldBuffer.byteLength);
            } else {
              buffer = packet.data;
            }
            var skip;
            while (i + 7 < buffer.length) {
              if (buffer[i] !== 255 || (buffer[i + 1] & 246) !== 240) {
                if (typeof skip !== "number") {
                  skip = i;
                }
                i++;
                continue;
              }
              if (typeof skip === "number") {
                this.skipWarn_(skip, i);
                skip = null;
              }
              protectionSkipBytes = (~buffer[i + 1] & 1) * 2;
              frameLength = (buffer[i + 3] & 3) << 11 | buffer[i + 4] << 3 | (buffer[i + 5] & 224) >> 5;
              sampleCount = ((buffer[i + 6] & 3) + 1) * 1024;
              adtsFrameDuration = sampleCount * ONE_SECOND_IN_TS$4 / ADTS_SAMPLING_FREQUENCIES$1[(buffer[i + 2] & 60) >>> 2];
              if (buffer.byteLength - i < frameLength) {
                break;
              }
              this.trigger("data", {
                pts: packet.pts + frameNum * adtsFrameDuration,
                dts: packet.dts + frameNum * adtsFrameDuration,
                sampleCount,
                audioobjecttype: (buffer[i + 2] >>> 6 & 3) + 1,
                channelcount: (buffer[i + 2] & 1) << 2 | (buffer[i + 3] & 192) >>> 6,
                samplerate: ADTS_SAMPLING_FREQUENCIES$1[(buffer[i + 2] & 60) >>> 2],
                samplingfrequencyindex: (buffer[i + 2] & 60) >>> 2,
                // assume ISO/IEC 14496-12 AudioSampleEntry default of 16
                samplesize: 16,
                // data is the frame without it's header
                data: buffer.subarray(i + 7 + protectionSkipBytes, i + frameLength)
              });
              frameNum++;
              i += frameLength;
            }
            if (typeof skip === "number") {
              this.skipWarn_(skip, i);
              skip = null;
            }
            buffer = buffer.subarray(i);
          };
          this.flush = function() {
            frameNum = 0;
            this.trigger("done");
          };
          this.reset = function() {
            buffer = void 0;
            this.trigger("reset");
          };
          this.endTimeline = function() {
            buffer = void 0;
            this.trigger("endedtimeline");
          };
        };
        _AdtsStream.prototype = new Stream$c();
        var adts = _AdtsStream;
        var ExpGolomb$1;
        ExpGolomb$1 = function ExpGolomb2(workingData) {
          var workingBytesAvailable = workingData.byteLength, workingWord = 0, workingBitsAvailable = 0;
          this.length = function() {
            return 8 * workingBytesAvailable;
          };
          this.bitsAvailable = function() {
            return 8 * workingBytesAvailable + workingBitsAvailable;
          };
          this.loadWord = function() {
            var position = workingData.byteLength - workingBytesAvailable, workingBytes = new Uint8Array(4), availableBytes = Math.min(4, workingBytesAvailable);
            if (availableBytes === 0) {
              throw new Error("no bytes available");
            }
            workingBytes.set(workingData.subarray(position, position + availableBytes));
            workingWord = new DataView(workingBytes.buffer).getUint32(0);
            workingBitsAvailable = availableBytes * 8;
            workingBytesAvailable -= availableBytes;
          };
          this.skipBits = function(count) {
            var skipBytes;
            if (workingBitsAvailable > count) {
              workingWord <<= count;
              workingBitsAvailable -= count;
            } else {
              count -= workingBitsAvailable;
              skipBytes = Math.floor(count / 8);
              count -= skipBytes * 8;
              workingBytesAvailable -= skipBytes;
              this.loadWord();
              workingWord <<= count;
              workingBitsAvailable -= count;
            }
          };
          this.readBits = function(size) {
            var bits = Math.min(workingBitsAvailable, size), valu = workingWord >>> 32 - bits;
            workingBitsAvailable -= bits;
            if (workingBitsAvailable > 0) {
              workingWord <<= bits;
            } else if (workingBytesAvailable > 0) {
              this.loadWord();
            }
            bits = size - bits;
            if (bits > 0) {
              return valu << bits | this.readBits(bits);
            }
            return valu;
          };
          this.skipLeadingZeros = function() {
            var leadingZeroCount;
            for (leadingZeroCount = 0; leadingZeroCount < workingBitsAvailable; ++leadingZeroCount) {
              if ((workingWord & 2147483648 >>> leadingZeroCount) !== 0) {
                workingWord <<= leadingZeroCount;
                workingBitsAvailable -= leadingZeroCount;
                return leadingZeroCount;
              }
            }
            this.loadWord();
            return leadingZeroCount + this.skipLeadingZeros();
          };
          this.skipUnsignedExpGolomb = function() {
            this.skipBits(1 + this.skipLeadingZeros());
          };
          this.skipExpGolomb = function() {
            this.skipBits(1 + this.skipLeadingZeros());
          };
          this.readUnsignedExpGolomb = function() {
            var clz = this.skipLeadingZeros();
            return this.readBits(clz + 1) - 1;
          };
          this.readExpGolomb = function() {
            var valu = this.readUnsignedExpGolomb();
            if (1 & valu) {
              return 1 + valu >>> 1;
            }
            return -1 * (valu >>> 1);
          };
          this.readBoolean = function() {
            return this.readBits(1) === 1;
          };
          this.readUnsignedByte = function() {
            return this.readBits(8);
          };
          this.loadWord();
        };
        var expGolomb = ExpGolomb$1;
        var Stream$b = stream;
        var ExpGolomb = expGolomb;
        var _H264Stream, _NalByteStream;
        var PROFILES_WITH_OPTIONAL_SPS_DATA;
        _NalByteStream = function NalByteStream() {
          var syncPoint = 0, i, buffer;
          _NalByteStream.prototype.init.call(this);
          this.push = function(data) {
            var swapBuffer;
            if (!buffer) {
              buffer = data.data;
            } else {
              swapBuffer = new Uint8Array(buffer.byteLength + data.data.byteLength);
              swapBuffer.set(buffer);
              swapBuffer.set(data.data, buffer.byteLength);
              buffer = swapBuffer;
            }
            var len = buffer.byteLength;
            for (; syncPoint < len - 3; syncPoint++) {
              if (buffer[syncPoint + 2] === 1) {
                i = syncPoint + 5;
                break;
              }
            }
            while (i < len) {
              switch (buffer[i]) {
                case 0:
                  if (buffer[i - 1] !== 0) {
                    i += 2;
                    break;
                  } else if (buffer[i - 2] !== 0) {
                    i++;
                    break;
                  }
                  if (syncPoint + 3 !== i - 2) {
                    this.trigger("data", buffer.subarray(syncPoint + 3, i - 2));
                  }
                  do {
                    i++;
                  } while (buffer[i] !== 1 && i < len);
                  syncPoint = i - 2;
                  i += 3;
                  break;
                case 1:
                  if (buffer[i - 1] !== 0 || buffer[i - 2] !== 0) {
                    i += 3;
                    break;
                  }
                  this.trigger("data", buffer.subarray(syncPoint + 3, i - 2));
                  syncPoint = i - 2;
                  i += 3;
                  break;
                default:
                  i += 3;
                  break;
              }
            }
            buffer = buffer.subarray(syncPoint);
            i -= syncPoint;
            syncPoint = 0;
          };
          this.reset = function() {
            buffer = null;
            syncPoint = 0;
            this.trigger("reset");
          };
          this.flush = function() {
            if (buffer && buffer.byteLength > 3) {
              this.trigger("data", buffer.subarray(syncPoint + 3));
            }
            buffer = null;
            syncPoint = 0;
            this.trigger("done");
          };
          this.endTimeline = function() {
            this.flush();
            this.trigger("endedtimeline");
          };
        };
        _NalByteStream.prototype = new Stream$b();
        PROFILES_WITH_OPTIONAL_SPS_DATA = {
          100: true,
          110: true,
          122: true,
          244: true,
          44: true,
          83: true,
          86: true,
          118: true,
          128: true,
          // TODO: the three profiles below don't
          // appear to have sps data in the specificiation anymore?
          138: true,
          139: true,
          134: true
        };
        _H264Stream = function H264Stream2() {
          var nalByteStream = new _NalByteStream(), self2, trackId, currentPts, currentDts, discardEmulationPreventionBytes2, readSequenceParameterSet, skipScalingList;
          _H264Stream.prototype.init.call(this);
          self2 = this;
          this.push = function(packet) {
            if (packet.type !== "video") {
              return;
            }
            trackId = packet.trackId;
            currentPts = packet.pts;
            currentDts = packet.dts;
            nalByteStream.push(packet);
          };
          nalByteStream.on("data", function(data) {
            var event = {
              trackId,
              pts: currentPts,
              dts: currentDts,
              data,
              nalUnitTypeCode: data[0] & 31
            };
            switch (event.nalUnitTypeCode) {
              case 5:
                event.nalUnitType = "slice_layer_without_partitioning_rbsp_idr";
                break;
              case 6:
                event.nalUnitType = "sei_rbsp";
                event.escapedRBSP = discardEmulationPreventionBytes2(data.subarray(1));
                break;
              case 7:
                event.nalUnitType = "seq_parameter_set_rbsp";
                event.escapedRBSP = discardEmulationPreventionBytes2(data.subarray(1));
                event.config = readSequenceParameterSet(event.escapedRBSP);
                break;
              case 8:
                event.nalUnitType = "pic_parameter_set_rbsp";
                break;
              case 9:
                event.nalUnitType = "access_unit_delimiter_rbsp";
                break;
            }
            self2.trigger("data", event);
          });
          nalByteStream.on("done", function() {
            self2.trigger("done");
          });
          nalByteStream.on("partialdone", function() {
            self2.trigger("partialdone");
          });
          nalByteStream.on("reset", function() {
            self2.trigger("reset");
          });
          nalByteStream.on("endedtimeline", function() {
            self2.trigger("endedtimeline");
          });
          this.flush = function() {
            nalByteStream.flush();
          };
          this.partialFlush = function() {
            nalByteStream.partialFlush();
          };
          this.reset = function() {
            nalByteStream.reset();
          };
          this.endTimeline = function() {
            nalByteStream.endTimeline();
          };
          skipScalingList = function skipScalingList2(count, expGolombDecoder) {
            var lastScale = 8, nextScale = 8, j, deltaScale;
            for (j = 0; j < count; j++) {
              if (nextScale !== 0) {
                deltaScale = expGolombDecoder.readExpGolomb();
                nextScale = (lastScale + deltaScale + 256) % 256;
              }
              lastScale = nextScale === 0 ? lastScale : nextScale;
            }
          };
          discardEmulationPreventionBytes2 = function discardEmulationPreventionBytes3(data) {
            var length = data.byteLength, emulationPreventionBytesPositions = [], i = 1, newLength, newData;
            while (i < length - 2) {
              if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 3) {
                emulationPreventionBytesPositions.push(i + 2);
                i += 2;
              } else {
                i++;
              }
            }
            if (emulationPreventionBytesPositions.length === 0) {
              return data;
            }
            newLength = length - emulationPreventionBytesPositions.length;
            newData = new Uint8Array(newLength);
            var sourceIndex = 0;
            for (i = 0; i < newLength; sourceIndex++, i++) {
              if (sourceIndex === emulationPreventionBytesPositions[0]) {
                sourceIndex++;
                emulationPreventionBytesPositions.shift();
              }
              newData[i] = data[sourceIndex];
            }
            return newData;
          };
          readSequenceParameterSet = function readSequenceParameterSet2(data) {
            var frameCropLeftOffset = 0, frameCropRightOffset = 0, frameCropTopOffset = 0, frameCropBottomOffset = 0, expGolombDecoder, profileIdc, levelIdc, profileCompatibility, chromaFormatIdc, picOrderCntType, numRefFramesInPicOrderCntCycle, picWidthInMbsMinus1, picHeightInMapUnitsMinus1, frameMbsOnlyFlag, scalingListCount, sarRatio = [1, 1], aspectRatioIdc, i;
            expGolombDecoder = new ExpGolomb(data);
            profileIdc = expGolombDecoder.readUnsignedByte();
            profileCompatibility = expGolombDecoder.readUnsignedByte();
            levelIdc = expGolombDecoder.readUnsignedByte();
            expGolombDecoder.skipUnsignedExpGolomb();
            if (PROFILES_WITH_OPTIONAL_SPS_DATA[profileIdc]) {
              chromaFormatIdc = expGolombDecoder.readUnsignedExpGolomb();
              if (chromaFormatIdc === 3) {
                expGolombDecoder.skipBits(1);
              }
              expGolombDecoder.skipUnsignedExpGolomb();
              expGolombDecoder.skipUnsignedExpGolomb();
              expGolombDecoder.skipBits(1);
              if (expGolombDecoder.readBoolean()) {
                scalingListCount = chromaFormatIdc !== 3 ? 8 : 12;
                for (i = 0; i < scalingListCount; i++) {
                  if (expGolombDecoder.readBoolean()) {
                    if (i < 6) {
                      skipScalingList(16, expGolombDecoder);
                    } else {
                      skipScalingList(64, expGolombDecoder);
                    }
                  }
                }
              }
            }
            expGolombDecoder.skipUnsignedExpGolomb();
            picOrderCntType = expGolombDecoder.readUnsignedExpGolomb();
            if (picOrderCntType === 0) {
              expGolombDecoder.readUnsignedExpGolomb();
            } else if (picOrderCntType === 1) {
              expGolombDecoder.skipBits(1);
              expGolombDecoder.skipExpGolomb();
              expGolombDecoder.skipExpGolomb();
              numRefFramesInPicOrderCntCycle = expGolombDecoder.readUnsignedExpGolomb();
              for (i = 0; i < numRefFramesInPicOrderCntCycle; i++) {
                expGolombDecoder.skipExpGolomb();
              }
            }
            expGolombDecoder.skipUnsignedExpGolomb();
            expGolombDecoder.skipBits(1);
            picWidthInMbsMinus1 = expGolombDecoder.readUnsignedExpGolomb();
            picHeightInMapUnitsMinus1 = expGolombDecoder.readUnsignedExpGolomb();
            frameMbsOnlyFlag = expGolombDecoder.readBits(1);
            if (frameMbsOnlyFlag === 0) {
              expGolombDecoder.skipBits(1);
            }
            expGolombDecoder.skipBits(1);
            if (expGolombDecoder.readBoolean()) {
              frameCropLeftOffset = expGolombDecoder.readUnsignedExpGolomb();
              frameCropRightOffset = expGolombDecoder.readUnsignedExpGolomb();
              frameCropTopOffset = expGolombDecoder.readUnsignedExpGolomb();
              frameCropBottomOffset = expGolombDecoder.readUnsignedExpGolomb();
            }
            if (expGolombDecoder.readBoolean()) {
              if (expGolombDecoder.readBoolean()) {
                aspectRatioIdc = expGolombDecoder.readUnsignedByte();
                switch (aspectRatioIdc) {
                  case 1:
                    sarRatio = [1, 1];
                    break;
                  case 2:
                    sarRatio = [12, 11];
                    break;
                  case 3:
                    sarRatio = [10, 11];
                    break;
                  case 4:
                    sarRatio = [16, 11];
                    break;
                  case 5:
                    sarRatio = [40, 33];
                    break;
                  case 6:
                    sarRatio = [24, 11];
                    break;
                  case 7:
                    sarRatio = [20, 11];
                    break;
                  case 8:
                    sarRatio = [32, 11];
                    break;
                  case 9:
                    sarRatio = [80, 33];
                    break;
                  case 10:
                    sarRatio = [18, 11];
                    break;
                  case 11:
                    sarRatio = [15, 11];
                    break;
                  case 12:
                    sarRatio = [64, 33];
                    break;
                  case 13:
                    sarRatio = [160, 99];
                    break;
                  case 14:
                    sarRatio = [4, 3];
                    break;
                  case 15:
                    sarRatio = [3, 2];
                    break;
                  case 16:
                    sarRatio = [2, 1];
                    break;
                  case 255: {
                    sarRatio = [expGolombDecoder.readUnsignedByte() << 8 | expGolombDecoder.readUnsignedByte(), expGolombDecoder.readUnsignedByte() << 8 | expGolombDecoder.readUnsignedByte()];
                    break;
                  }
                }
                if (sarRatio) {
                  sarRatio[0] / sarRatio[1];
                }
              }
            }
            return {
              profileIdc,
              levelIdc,
              profileCompatibility,
              width: (picWidthInMbsMinus1 + 1) * 16 - frameCropLeftOffset * 2 - frameCropRightOffset * 2,
              height: (2 - frameMbsOnlyFlag) * (picHeightInMapUnitsMinus1 + 1) * 16 - frameCropTopOffset * 2 - frameCropBottomOffset * 2,
              // sar is sample aspect ratio
              sarRatio
            };
          };
        };
        _H264Stream.prototype = new Stream$b();
        var h264 = {
          H264Stream: _H264Stream,
          NalByteStream: _NalByteStream
        };
        var codecs$1 = {
          Adts: adts,
          h264
        };
        var MAX_UINT32$1 = Math.pow(2, 32);
        var getUint64$5 = function getUint642(uint8) {
          var dv = new DataView(uint8.buffer, uint8.byteOffset, uint8.byteLength);
          var value;
          if (dv.getBigUint64) {
            value = dv.getBigUint64(0);
            if (value < Number.MAX_SAFE_INTEGER) {
              return Number(value);
            }
            return value;
          }
          return dv.getUint32(0) * MAX_UINT32$1 + dv.getUint32(4);
        };
        var numbers = {
          getUint64: getUint64$5,
          MAX_UINT32: MAX_UINT32$1
        };
        var MAX_UINT32 = numbers.MAX_UINT32;
        var box2, dinf, esds, ftyp, mdat, mfhd, minf, moof, moov, mvex, mvhd, trak, tkhd, mdia, mdhd, hdlr, sdtp, stbl, stsd, traf, trex, trun$1, types, MAJOR_BRAND, MINOR_VERSION, AVC1_BRAND, VIDEO_HDLR, AUDIO_HDLR, HDLR_TYPES, VMHD, SMHD, DREF, STCO, STSC, STSZ, STTS;
        (function() {
          var i;
          types = {
            avc1: [],
            // codingname
            avcC: [],
            btrt: [],
            dinf: [],
            dref: [],
            esds: [],
            ftyp: [],
            hdlr: [],
            mdat: [],
            mdhd: [],
            mdia: [],
            mfhd: [],
            minf: [],
            moof: [],
            moov: [],
            mp4a: [],
            // codingname
            mvex: [],
            mvhd: [],
            pasp: [],
            sdtp: [],
            smhd: [],
            stbl: [],
            stco: [],
            stsc: [],
            stsd: [],
            stsz: [],
            stts: [],
            styp: [],
            tfdt: [],
            tfhd: [],
            traf: [],
            trak: [],
            trun: [],
            trex: [],
            tkhd: [],
            vmhd: []
          };
          if (typeof Uint8Array === "undefined") {
            return;
          }
          for (i in types) {
            if (types.hasOwnProperty(i)) {
              types[i] = [i.charCodeAt(0), i.charCodeAt(1), i.charCodeAt(2), i.charCodeAt(3)];
            }
          }
          MAJOR_BRAND = new Uint8Array(["i".charCodeAt(0), "s".charCodeAt(0), "o".charCodeAt(0), "m".charCodeAt(0)]);
          AVC1_BRAND = new Uint8Array(["a".charCodeAt(0), "v".charCodeAt(0), "c".charCodeAt(0), "1".charCodeAt(0)]);
          MINOR_VERSION = new Uint8Array([0, 0, 0, 1]);
          VIDEO_HDLR = new Uint8Array([
            0,
            // version 0
            0,
            0,
            0,
            // flags
            0,
            0,
            0,
            0,
            // pre_defined
            118,
            105,
            100,
            101,
            // handler_type: 'vide'
            0,
            0,
            0,
            0,
            // reserved
            0,
            0,
            0,
            0,
            // reserved
            0,
            0,
            0,
            0,
            // reserved
            86,
            105,
            100,
            101,
            111,
            72,
            97,
            110,
            100,
            108,
            101,
            114,
            0
            // name: 'VideoHandler'
          ]);
          AUDIO_HDLR = new Uint8Array([
            0,
            // version 0
            0,
            0,
            0,
            // flags
            0,
            0,
            0,
            0,
            // pre_defined
            115,
            111,
            117,
            110,
            // handler_type: 'soun'
            0,
            0,
            0,
            0,
            // reserved
            0,
            0,
            0,
            0,
            // reserved
            0,
            0,
            0,
            0,
            // reserved
            83,
            111,
            117,
            110,
            100,
            72,
            97,
            110,
            100,
            108,
            101,
            114,
            0
            // name: 'SoundHandler'
          ]);
          HDLR_TYPES = {
            video: VIDEO_HDLR,
            audio: AUDIO_HDLR
          };
          DREF = new Uint8Array([
            0,
            // version 0
            0,
            0,
            0,
            // flags
            0,
            0,
            0,
            1,
            // entry_count
            0,
            0,
            0,
            12,
            // entry_size
            117,
            114,
            108,
            32,
            // 'url' type
            0,
            // version 0
            0,
            0,
            1
            // entry_flags
          ]);
          SMHD = new Uint8Array([
            0,
            // version
            0,
            0,
            0,
            // flags
            0,
            0,
            // balance, 0 means centered
            0,
            0
            // reserved
          ]);
          STCO = new Uint8Array([
            0,
            // version
            0,
            0,
            0,
            // flags
            0,
            0,
            0,
            0
            // entry_count
          ]);
          STSC = STCO;
          STSZ = new Uint8Array([
            0,
            // version
            0,
            0,
            0,
            // flags
            0,
            0,
            0,
            0,
            // sample_size
            0,
            0,
            0,
            0
            // sample_count
          ]);
          STTS = STCO;
          VMHD = new Uint8Array([
            0,
            // version
            0,
            0,
            1,
            // flags
            0,
            0,
            // graphicsmode
            0,
            0,
            0,
            0,
            0,
            0
            // opcolor
          ]);
        })();
        box2 = function box3(type2) {
          var payload = [], size = 0, i, result, view;
          for (i = 1; i < arguments.length; i++) {
            payload.push(arguments[i]);
          }
          i = payload.length;
          while (i--) {
            size += payload[i].byteLength;
          }
          result = new Uint8Array(size + 8);
          view = new DataView(result.buffer, result.byteOffset, result.byteLength);
          view.setUint32(0, result.byteLength);
          result.set(type2, 4);
          for (i = 0, size = 8; i < payload.length; i++) {
            result.set(payload[i], size);
            size += payload[i].byteLength;
          }
          return result;
        };
        dinf = function dinf2() {
          return box2(types.dinf, box2(types.dref, DREF));
        };
        esds = function esds2(track) {
          return box2(types.esds, new Uint8Array([
            0,
            // version
            0,
            0,
            0,
            // flags
            // ES_Descriptor
            3,
            // tag, ES_DescrTag
            25,
            // length
            0,
            0,
            // ES_ID
            0,
            // streamDependenceFlag, URL_flag, reserved, streamPriority
            // DecoderConfigDescriptor
            4,
            // tag, DecoderConfigDescrTag
            17,
            // length
            64,
            // object type
            21,
            // streamType
            0,
            6,
            0,
            // bufferSizeDB
            0,
            0,
            218,
            192,
            // maxBitrate
            0,
            0,
            218,
            192,
            // avgBitrate
            // DecoderSpecificInfo
            5,
            // tag, DecoderSpecificInfoTag
            2,
            // length
            // ISO/IEC 14496-3, AudioSpecificConfig
            // for samplingFrequencyIndex see ISO/IEC 13818-7:2006, 8.1.3.2.2, Table 35
            track.audioobjecttype << 3 | track.samplingfrequencyindex >>> 1,
            track.samplingfrequencyindex << 7 | track.channelcount << 3,
            6,
            1,
            2
            // GASpecificConfig
          ]));
        };
        ftyp = function ftyp2() {
          return box2(types.ftyp, MAJOR_BRAND, MINOR_VERSION, MAJOR_BRAND, AVC1_BRAND);
        };
        hdlr = function hdlr2(type2) {
          return box2(types.hdlr, HDLR_TYPES[type2]);
        };
        mdat = function mdat2(data) {
          return box2(types.mdat, data);
        };
        mdhd = function mdhd2(track) {
          var result = new Uint8Array([
            0,
            // version 0
            0,
            0,
            0,
            // flags
            0,
            0,
            0,
            2,
            // creation_time
            0,
            0,
            0,
            3,
            // modification_time
            0,
            1,
            95,
            144,
            // timescale, 90,000 "ticks" per second
            track.duration >>> 24 & 255,
            track.duration >>> 16 & 255,
            track.duration >>> 8 & 255,
            track.duration & 255,
            // duration
            85,
            196,
            // 'und' language (undetermined)
            0,
            0
          ]);
          if (track.samplerate) {
            result[12] = track.samplerate >>> 24 & 255;
            result[13] = track.samplerate >>> 16 & 255;
            result[14] = track.samplerate >>> 8 & 255;
            result[15] = track.samplerate & 255;
          }
          return box2(types.mdhd, result);
        };
        mdia = function mdia2(track) {
          return box2(types.mdia, mdhd(track), hdlr(track.type), minf(track));
        };
        mfhd = function mfhd2(sequenceNumber) {
          return box2(types.mfhd, new Uint8Array([
            0,
            0,
            0,
            0,
            // flags
            (sequenceNumber & 4278190080) >> 24,
            (sequenceNumber & 16711680) >> 16,
            (sequenceNumber & 65280) >> 8,
            sequenceNumber & 255
            // sequence_number
          ]));
        };
        minf = function minf2(track) {
          return box2(types.minf, track.type === "video" ? box2(types.vmhd, VMHD) : box2(types.smhd, SMHD), dinf(), stbl(track));
        };
        moof = function moof2(sequenceNumber, tracks) {
          var trackFragments = [], i = tracks.length;
          while (i--) {
            trackFragments[i] = traf(tracks[i]);
          }
          return box2.apply(null, [types.moof, mfhd(sequenceNumber)].concat(trackFragments));
        };
        moov = function moov2(tracks) {
          var i = tracks.length, boxes2 = [];
          while (i--) {
            boxes2[i] = trak(tracks[i]);
          }
          return box2.apply(null, [types.moov, mvhd(4294967295)].concat(boxes2).concat(mvex(tracks)));
        };
        mvex = function mvex2(tracks) {
          var i = tracks.length, boxes2 = [];
          while (i--) {
            boxes2[i] = trex(tracks[i]);
          }
          return box2.apply(null, [types.mvex].concat(boxes2));
        };
        mvhd = function mvhd2(duration) {
          var bytes = new Uint8Array([
            0,
            // version 0
            0,
            0,
            0,
            // flags
            0,
            0,
            0,
            1,
            // creation_time
            0,
            0,
            0,
            2,
            // modification_time
            0,
            1,
            95,
            144,
            // timescale, 90,000 "ticks" per second
            (duration & 4278190080) >> 24,
            (duration & 16711680) >> 16,
            (duration & 65280) >> 8,
            duration & 255,
            // duration
            0,
            1,
            0,
            0,
            // 1.0 rate
            1,
            0,
            // 1.0 volume
            0,
            0,
            // reserved
            0,
            0,
            0,
            0,
            // reserved
            0,
            0,
            0,
            0,
            // reserved
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            64,
            0,
            0,
            0,
            // transformation: unity matrix
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            // pre_defined
            255,
            255,
            255,
            255
            // next_track_ID
          ]);
          return box2(types.mvhd, bytes);
        };
        sdtp = function sdtp2(track) {
          var samples2 = track.samples || [], bytes = new Uint8Array(4 + samples2.length), flags, i;
          for (i = 0; i < samples2.length; i++) {
            flags = samples2[i].flags;
            bytes[i + 4] = flags.dependsOn << 4 | flags.isDependedOn << 2 | flags.hasRedundancy;
          }
          return box2(types.sdtp, bytes);
        };
        stbl = function stbl2(track) {
          return box2(types.stbl, stsd(track), box2(types.stts, STTS), box2(types.stsc, STSC), box2(types.stsz, STSZ), box2(types.stco, STCO));
        };
        (function() {
          var videoSample, audioSample;
          stsd = function stsd2(track) {
            return box2(types.stsd, new Uint8Array([
              0,
              // version 0
              0,
              0,
              0,
              // flags
              0,
              0,
              0,
              1
            ]), track.type === "video" ? videoSample(track) : audioSample(track));
          };
          videoSample = function videoSample2(track) {
            var sps = track.sps || [], pps = track.pps || [], sequenceParameterSets = [], pictureParameterSets = [], i, avc1Box;
            for (i = 0; i < sps.length; i++) {
              sequenceParameterSets.push((sps[i].byteLength & 65280) >>> 8);
              sequenceParameterSets.push(sps[i].byteLength & 255);
              sequenceParameterSets = sequenceParameterSets.concat(Array.prototype.slice.call(sps[i]));
            }
            for (i = 0; i < pps.length; i++) {
              pictureParameterSets.push((pps[i].byteLength & 65280) >>> 8);
              pictureParameterSets.push(pps[i].byteLength & 255);
              pictureParameterSets = pictureParameterSets.concat(Array.prototype.slice.call(pps[i]));
            }
            avc1Box = [types.avc1, new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              // reserved
              0,
              1,
              // data_reference_index
              0,
              0,
              // pre_defined
              0,
              0,
              // reserved
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              // pre_defined
              (track.width & 65280) >> 8,
              track.width & 255,
              // width
              (track.height & 65280) >> 8,
              track.height & 255,
              // height
              0,
              72,
              0,
              0,
              // horizresolution
              0,
              72,
              0,
              0,
              // vertresolution
              0,
              0,
              0,
              0,
              // reserved
              0,
              1,
              // frame_count
              19,
              118,
              105,
              100,
              101,
              111,
              106,
              115,
              45,
              99,
              111,
              110,
              116,
              114,
              105,
              98,
              45,
              104,
              108,
              115,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              // compressorname
              0,
              24,
              // depth = 24
              17,
              17
              // pre_defined = -1
            ]), box2(types.avcC, new Uint8Array([
              1,
              // configurationVersion
              track.profileIdc,
              // AVCProfileIndication
              track.profileCompatibility,
              // profile_compatibility
              track.levelIdc,
              // AVCLevelIndication
              255
              // lengthSizeMinusOne, hard-coded to 4 bytes
            ].concat(
              [sps.length],
              // numOfSequenceParameterSets
              sequenceParameterSets,
              // "SPS"
              [pps.length],
              // numOfPictureParameterSets
              pictureParameterSets
              // "PPS"
            ))), box2(types.btrt, new Uint8Array([
              0,
              28,
              156,
              128,
              // bufferSizeDB
              0,
              45,
              198,
              192,
              // maxBitrate
              0,
              45,
              198,
              192
              // avgBitrate
            ]))];
            if (track.sarRatio) {
              var hSpacing = track.sarRatio[0], vSpacing = track.sarRatio[1];
              avc1Box.push(box2(types.pasp, new Uint8Array([(hSpacing & 4278190080) >> 24, (hSpacing & 16711680) >> 16, (hSpacing & 65280) >> 8, hSpacing & 255, (vSpacing & 4278190080) >> 24, (vSpacing & 16711680) >> 16, (vSpacing & 65280) >> 8, vSpacing & 255])));
            }
            return box2.apply(null, avc1Box);
          };
          audioSample = function audioSample2(track) {
            return box2(types.mp4a, new Uint8Array([
              // SampleEntry, ISO/IEC 14496-12
              0,
              0,
              0,
              0,
              0,
              0,
              // reserved
              0,
              1,
              // data_reference_index
              // AudioSampleEntry, ISO/IEC 14496-12
              0,
              0,
              0,
              0,
              // reserved
              0,
              0,
              0,
              0,
              // reserved
              (track.channelcount & 65280) >> 8,
              track.channelcount & 255,
              // channelcount
              (track.samplesize & 65280) >> 8,
              track.samplesize & 255,
              // samplesize
              0,
              0,
              // pre_defined
              0,
              0,
              // reserved
              (track.samplerate & 65280) >> 8,
              track.samplerate & 255,
              0,
              0
              // samplerate, 16.16
              // MP4AudioSampleEntry, ISO/IEC 14496-14
            ]), esds(track));
          };
        })();
        tkhd = function tkhd2(track) {
          var result = new Uint8Array([
            0,
            // version 0
            0,
            0,
            7,
            // flags
            0,
            0,
            0,
            0,
            // creation_time
            0,
            0,
            0,
            0,
            // modification_time
            (track.id & 4278190080) >> 24,
            (track.id & 16711680) >> 16,
            (track.id & 65280) >> 8,
            track.id & 255,
            // track_ID
            0,
            0,
            0,
            0,
            // reserved
            (track.duration & 4278190080) >> 24,
            (track.duration & 16711680) >> 16,
            (track.duration & 65280) >> 8,
            track.duration & 255,
            // duration
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            // reserved
            0,
            0,
            // layer
            0,
            0,
            // alternate_group
            1,
            0,
            // non-audio track volume
            0,
            0,
            // reserved
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            64,
            0,
            0,
            0,
            // transformation: unity matrix
            (track.width & 65280) >> 8,
            track.width & 255,
            0,
            0,
            // width
            (track.height & 65280) >> 8,
            track.height & 255,
            0,
            0
            // height
          ]);
          return box2(types.tkhd, result);
        };
        traf = function traf2(track) {
          var trackFragmentHeader, trackFragmentDecodeTime, trackFragmentRun, sampleDependencyTable, dataOffset, upperWordBaseMediaDecodeTime, lowerWordBaseMediaDecodeTime;
          trackFragmentHeader = box2(types.tfhd, new Uint8Array([
            0,
            // version 0
            0,
            0,
            58,
            // flags
            (track.id & 4278190080) >> 24,
            (track.id & 16711680) >> 16,
            (track.id & 65280) >> 8,
            track.id & 255,
            // track_ID
            0,
            0,
            0,
            1,
            // sample_description_index
            0,
            0,
            0,
            0,
            // default_sample_duration
            0,
            0,
            0,
            0,
            // default_sample_size
            0,
            0,
            0,
            0
            // default_sample_flags
          ]));
          upperWordBaseMediaDecodeTime = Math.floor(track.baseMediaDecodeTime / MAX_UINT32);
          lowerWordBaseMediaDecodeTime = Math.floor(track.baseMediaDecodeTime % MAX_UINT32);
          trackFragmentDecodeTime = box2(types.tfdt, new Uint8Array([
            1,
            // version 1
            0,
            0,
            0,
            // flags
            // baseMediaDecodeTime
            upperWordBaseMediaDecodeTime >>> 24 & 255,
            upperWordBaseMediaDecodeTime >>> 16 & 255,
            upperWordBaseMediaDecodeTime >>> 8 & 255,
            upperWordBaseMediaDecodeTime & 255,
            lowerWordBaseMediaDecodeTime >>> 24 & 255,
            lowerWordBaseMediaDecodeTime >>> 16 & 255,
            lowerWordBaseMediaDecodeTime >>> 8 & 255,
            lowerWordBaseMediaDecodeTime & 255
          ]));
          dataOffset = 32 + // tfhd
          20 + // tfdt
          8 + // traf header
          16 + // mfhd
          8 + // moof header
          8;
          if (track.type === "audio") {
            trackFragmentRun = trun$1(track, dataOffset);
            return box2(types.traf, trackFragmentHeader, trackFragmentDecodeTime, trackFragmentRun);
          }
          sampleDependencyTable = sdtp(track);
          trackFragmentRun = trun$1(track, sampleDependencyTable.length + dataOffset);
          return box2(types.traf, trackFragmentHeader, trackFragmentDecodeTime, trackFragmentRun, sampleDependencyTable);
        };
        trak = function trak2(track) {
          track.duration = track.duration || 4294967295;
          return box2(types.trak, tkhd(track), mdia(track));
        };
        trex = function trex2(track) {
          var result = new Uint8Array([
            0,
            // version 0
            0,
            0,
            0,
            // flags
            (track.id & 4278190080) >> 24,
            (track.id & 16711680) >> 16,
            (track.id & 65280) >> 8,
            track.id & 255,
            // track_ID
            0,
            0,
            0,
            1,
            // default_sample_description_index
            0,
            0,
            0,
            0,
            // default_sample_duration
            0,
            0,
            0,
            0,
            // default_sample_size
            0,
            1,
            0,
            1
            // default_sample_flags
          ]);
          if (track.type !== "video") {
            result[result.length - 1] = 0;
          }
          return box2(types.trex, result);
        };
        (function() {
          var audioTrun, videoTrun, trunHeader;
          trunHeader = function trunHeader2(samples2, offset) {
            var durationPresent = 0, sizePresent = 0, flagsPresent = 0, compositionTimeOffset = 0;
            if (samples2.length) {
              if (samples2[0].duration !== void 0) {
                durationPresent = 1;
              }
              if (samples2[0].size !== void 0) {
                sizePresent = 2;
              }
              if (samples2[0].flags !== void 0) {
                flagsPresent = 4;
              }
              if (samples2[0].compositionTimeOffset !== void 0) {
                compositionTimeOffset = 8;
              }
            }
            return [
              0,
              // version 0
              0,
              durationPresent | sizePresent | flagsPresent | compositionTimeOffset,
              1,
              // flags
              (samples2.length & 4278190080) >>> 24,
              (samples2.length & 16711680) >>> 16,
              (samples2.length & 65280) >>> 8,
              samples2.length & 255,
              // sample_count
              (offset & 4278190080) >>> 24,
              (offset & 16711680) >>> 16,
              (offset & 65280) >>> 8,
              offset & 255
              // data_offset
            ];
          };
          videoTrun = function videoTrun2(track, offset) {
            var bytesOffest, bytes, header, samples2, sample, i;
            samples2 = track.samples || [];
            offset += 8 + 12 + 16 * samples2.length;
            header = trunHeader(samples2, offset);
            bytes = new Uint8Array(header.length + samples2.length * 16);
            bytes.set(header);
            bytesOffest = header.length;
            for (i = 0; i < samples2.length; i++) {
              sample = samples2[i];
              bytes[bytesOffest++] = (sample.duration & 4278190080) >>> 24;
              bytes[bytesOffest++] = (sample.duration & 16711680) >>> 16;
              bytes[bytesOffest++] = (sample.duration & 65280) >>> 8;
              bytes[bytesOffest++] = sample.duration & 255;
              bytes[bytesOffest++] = (sample.size & 4278190080) >>> 24;
              bytes[bytesOffest++] = (sample.size & 16711680) >>> 16;
              bytes[bytesOffest++] = (sample.size & 65280) >>> 8;
              bytes[bytesOffest++] = sample.size & 255;
              bytes[bytesOffest++] = sample.flags.isLeading << 2 | sample.flags.dependsOn;
              bytes[bytesOffest++] = sample.flags.isDependedOn << 6 | sample.flags.hasRedundancy << 4 | sample.flags.paddingValue << 1 | sample.flags.isNonSyncSample;
              bytes[bytesOffest++] = sample.flags.degradationPriority & 240 << 8;
              bytes[bytesOffest++] = sample.flags.degradationPriority & 15;
              bytes[bytesOffest++] = (sample.compositionTimeOffset & 4278190080) >>> 24;
              bytes[bytesOffest++] = (sample.compositionTimeOffset & 16711680) >>> 16;
              bytes[bytesOffest++] = (sample.compositionTimeOffset & 65280) >>> 8;
              bytes[bytesOffest++] = sample.compositionTimeOffset & 255;
            }
            return box2(types.trun, bytes);
          };
          audioTrun = function audioTrun2(track, offset) {
            var bytes, bytesOffest, header, samples2, sample, i;
            samples2 = track.samples || [];
            offset += 8 + 12 + 8 * samples2.length;
            header = trunHeader(samples2, offset);
            bytes = new Uint8Array(header.length + samples2.length * 8);
            bytes.set(header);
            bytesOffest = header.length;
            for (i = 0; i < samples2.length; i++) {
              sample = samples2[i];
              bytes[bytesOffest++] = (sample.duration & 4278190080) >>> 24;
              bytes[bytesOffest++] = (sample.duration & 16711680) >>> 16;
              bytes[bytesOffest++] = (sample.duration & 65280) >>> 8;
              bytes[bytesOffest++] = sample.duration & 255;
              bytes[bytesOffest++] = (sample.size & 4278190080) >>> 24;
              bytes[bytesOffest++] = (sample.size & 16711680) >>> 16;
              bytes[bytesOffest++] = (sample.size & 65280) >>> 8;
              bytes[bytesOffest++] = sample.size & 255;
            }
            return box2(types.trun, bytes);
          };
          trun$1 = function trun2(track, offset) {
            if (track.type === "audio") {
              return audioTrun(track, offset);
            }
            return videoTrun(track, offset);
          };
        })();
        var mp4Generator = {
          ftyp,
          mdat,
          moof,
          moov,
          initSegment: function initSegment(tracks) {
            var fileType = ftyp(), movie = moov(tracks), result;
            result = new Uint8Array(fileType.byteLength + movie.byteLength);
            result.set(fileType);
            result.set(movie, fileType.byteLength);
            return result;
          }
        };
        var toUnsigned$3 = function toUnsigned2(value) {
          return value >>> 0;
        };
        var toHexString$1 = function toHexString2(value) {
          return ("00" + value.toString(16)).slice(-2);
        };
        var bin = {
          toUnsigned: toUnsigned$3,
          toHexString: toHexString$1
        };
        var parseType$5 = function parseType2(buffer) {
          var result = "";
          result += String.fromCharCode(buffer[0]);
          result += String.fromCharCode(buffer[1]);
          result += String.fromCharCode(buffer[2]);
          result += String.fromCharCode(buffer[3]);
          return result;
        };
        var parseType_1 = parseType$5;
        var toUnsigned$2 = bin.toUnsigned;
        var parseType$4 = parseType_1;
        var findBox$5 = function findBox2(data, path) {
          var results = [], i, size, type2, end, subresults;
          if (!path.length) {
            return null;
          }
          for (i = 0; i < data.byteLength; ) {
            size = toUnsigned$2(data[i] << 24 | data[i + 1] << 16 | data[i + 2] << 8 | data[i + 3]);
            type2 = parseType$4(data.subarray(i + 4, i + 8));
            end = size > 1 ? i + size : data.byteLength;
            if (type2 === path[0]) {
              if (path.length === 1) {
                results.push(data.subarray(i + 8, end));
              } else {
                subresults = findBox2(data.subarray(i + 8, end), path.slice(1));
                if (subresults.length) {
                  results = results.concat(subresults);
                }
              }
            }
            i = end;
          }
          return results;
        };
        var findBox_1 = findBox$5;
        var uint8ToCString$1 = function uint8ToCString2(data) {
          var index = 0;
          var curChar = String.fromCharCode(data[index]);
          var retString = "";
          while (curChar !== "\0") {
            retString += curChar;
            index++;
            curChar = String.fromCharCode(data[index]);
          }
          retString += curChar;
          return retString;
        };
        var string = {
          uint8ToCString: uint8ToCString$1
        };
        var uint8ToCString = string.uint8ToCString;
        var getUint64$4 = numbers.getUint64;
        var parseEmsgBox = function parseEmsgBox2(boxData) {
          var offset = 4;
          var version = boxData[0];
          var scheme_id_uri, value, timescale2, presentation_time, presentation_time_delta, event_duration, id, message_data;
          if (version === 0) {
            scheme_id_uri = uint8ToCString(boxData.subarray(offset));
            offset += scheme_id_uri.length;
            value = uint8ToCString(boxData.subarray(offset));
            offset += value.length;
            var dv = new DataView(boxData.buffer);
            timescale2 = dv.getUint32(offset);
            offset += 4;
            presentation_time_delta = dv.getUint32(offset);
            offset += 4;
            event_duration = dv.getUint32(offset);
            offset += 4;
            id = dv.getUint32(offset);
            offset += 4;
          } else if (version === 1) {
            var dv = new DataView(boxData.buffer);
            timescale2 = dv.getUint32(offset);
            offset += 4;
            presentation_time = getUint64$4(boxData.subarray(offset));
            offset += 8;
            event_duration = dv.getUint32(offset);
            offset += 4;
            id = dv.getUint32(offset);
            offset += 4;
            scheme_id_uri = uint8ToCString(boxData.subarray(offset));
            offset += scheme_id_uri.length;
            value = uint8ToCString(boxData.subarray(offset));
            offset += value.length;
          }
          message_data = new Uint8Array(boxData.subarray(offset, boxData.byteLength));
          var emsgBox = {
            scheme_id_uri,
            value,
            // if timescale is undefined or 0 set to 1 
            timescale: timescale2 ? timescale2 : 1,
            presentation_time,
            presentation_time_delta,
            event_duration,
            id,
            message_data
          };
          return isValidEmsgBox(version, emsgBox) ? emsgBox : void 0;
        };
        var scaleTime = function scaleTime2(presentationTime, timescale2, timeDelta, offset) {
          return presentationTime || presentationTime === 0 ? presentationTime / timescale2 : offset + timeDelta / timescale2;
        };
        var isValidEmsgBox = function isValidEmsgBox2(version, emsg2) {
          var hasScheme = emsg2.scheme_id_uri !== "\0";
          var isValidV0Box = version === 0 && isDefined(emsg2.presentation_time_delta) && hasScheme;
          var isValidV1Box = version === 1 && isDefined(emsg2.presentation_time) && hasScheme;
          return !(version > 1) && isValidV0Box || isValidV1Box;
        };
        var isDefined = function isDefined2(data) {
          return data !== void 0 || data !== null;
        };
        var emsg$1 = {
          parseEmsgBox,
          scaleTime
        };
        var tfhd = function tfhd2(data) {
          var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
            version: data[0],
            flags: new Uint8Array(data.subarray(1, 4)),
            trackId: view.getUint32(4)
          }, baseDataOffsetPresent = result.flags[2] & 1, sampleDescriptionIndexPresent = result.flags[2] & 2, defaultSampleDurationPresent = result.flags[2] & 8, defaultSampleSizePresent = result.flags[2] & 16, defaultSampleFlagsPresent = result.flags[2] & 32, durationIsEmpty = result.flags[0] & 65536, defaultBaseIsMoof = result.flags[0] & 131072, i;
          i = 8;
          if (baseDataOffsetPresent) {
            i += 4;
            result.baseDataOffset = view.getUint32(12);
            i += 4;
          }
          if (sampleDescriptionIndexPresent) {
            result.sampleDescriptionIndex = view.getUint32(i);
            i += 4;
          }
          if (defaultSampleDurationPresent) {
            result.defaultSampleDuration = view.getUint32(i);
            i += 4;
          }
          if (defaultSampleSizePresent) {
            result.defaultSampleSize = view.getUint32(i);
            i += 4;
          }
          if (defaultSampleFlagsPresent) {
            result.defaultSampleFlags = view.getUint32(i);
          }
          if (durationIsEmpty) {
            result.durationIsEmpty = true;
          }
          if (!baseDataOffsetPresent && defaultBaseIsMoof) {
            result.baseDataOffsetIsMoof = true;
          }
          return result;
        };
        var parseTfhd$2 = tfhd;
        var parseSampleFlags$1 = function parseSampleFlags2(flags) {
          return {
            isLeading: (flags[0] & 12) >>> 2,
            dependsOn: flags[0] & 3,
            isDependedOn: (flags[1] & 192) >>> 6,
            hasRedundancy: (flags[1] & 48) >>> 4,
            paddingValue: (flags[1] & 14) >>> 1,
            isNonSyncSample: flags[1] & 1,
            degradationPriority: flags[2] << 8 | flags[3]
          };
        };
        var parseSampleFlags_1 = parseSampleFlags$1;
        var parseSampleFlags = parseSampleFlags_1;
        var trun = function trun2(data) {
          var result = {
            version: data[0],
            flags: new Uint8Array(data.subarray(1, 4)),
            samples: []
          }, view = new DataView(data.buffer, data.byteOffset, data.byteLength), dataOffsetPresent = result.flags[2] & 1, firstSampleFlagsPresent = result.flags[2] & 4, sampleDurationPresent = result.flags[1] & 1, sampleSizePresent = result.flags[1] & 2, sampleFlagsPresent = result.flags[1] & 4, sampleCompositionTimeOffsetPresent = result.flags[1] & 8, sampleCount = view.getUint32(4), offset = 8, sample;
          if (dataOffsetPresent) {
            result.dataOffset = view.getInt32(offset);
            offset += 4;
          }
          if (firstSampleFlagsPresent && sampleCount) {
            sample = {
              flags: parseSampleFlags(data.subarray(offset, offset + 4))
            };
            offset += 4;
            if (sampleDurationPresent) {
              sample.duration = view.getUint32(offset);
              offset += 4;
            }
            if (sampleSizePresent) {
              sample.size = view.getUint32(offset);
              offset += 4;
            }
            if (sampleCompositionTimeOffsetPresent) {
              if (result.version === 1) {
                sample.compositionTimeOffset = view.getInt32(offset);
              } else {
                sample.compositionTimeOffset = view.getUint32(offset);
              }
              offset += 4;
            }
            result.samples.push(sample);
            sampleCount--;
          }
          while (sampleCount--) {
            sample = {};
            if (sampleDurationPresent) {
              sample.duration = view.getUint32(offset);
              offset += 4;
            }
            if (sampleSizePresent) {
              sample.size = view.getUint32(offset);
              offset += 4;
            }
            if (sampleFlagsPresent) {
              sample.flags = parseSampleFlags(data.subarray(offset, offset + 4));
              offset += 4;
            }
            if (sampleCompositionTimeOffsetPresent) {
              if (result.version === 1) {
                sample.compositionTimeOffset = view.getInt32(offset);
              } else {
                sample.compositionTimeOffset = view.getUint32(offset);
              }
              offset += 4;
            }
            result.samples.push(sample);
          }
          return result;
        };
        var parseTrun$2 = trun;
        var toUnsigned$1 = bin.toUnsigned;
        var getUint64$3 = numbers.getUint64;
        var tfdt = function tfdt2(data) {
          var result = {
            version: data[0],
            flags: new Uint8Array(data.subarray(1, 4))
          };
          if (result.version === 1) {
            result.baseMediaDecodeTime = getUint64$3(data.subarray(4));
          } else {
            result.baseMediaDecodeTime = toUnsigned$1(data[4] << 24 | data[5] << 16 | data[6] << 8 | data[7]);
          }
          return result;
        };
        var parseTfdt$3 = tfdt;
        var typedArrayIndexOf$1 = function typedArrayIndexOf2(typedArray2, element, fromIndex) {
          if (!typedArray2) {
            return -1;
          }
          var currentIndex = fromIndex;
          for (; currentIndex < typedArray2.length; currentIndex++) {
            if (typedArray2[currentIndex] === element) {
              return currentIndex;
            }
          }
          return -1;
        };
        var typedArray = {
          typedArrayIndexOf: typedArrayIndexOf$1
        };
        var typedArrayIndexOf = typedArray.typedArrayIndexOf, textEncodingDescriptionByte = {
          Iso88591: 0,
          // ISO-8859-1, terminated with \0.
          Utf16: 1,
          // UTF-16 encoded Unicode BOM, terminated with \0\0
          Utf16be: 2,
          // UTF-16BE encoded Unicode, without BOM, terminated with \0\0
          Utf8: 3
          // UTF-8 encoded Unicode, terminated with \0
        }, percentEncode$1 = function percentEncode2(bytes, start, end) {
          var i, result = "";
          for (i = start; i < end; i++) {
            result += "%" + ("00" + bytes[i].toString(16)).slice(-2);
          }
          return result;
        }, parseUtf8 = function parseUtf82(bytes, start, end) {
          return decodeURIComponent(percentEncode$1(bytes, start, end));
        }, parseIso88591$1 = function parseIso885912(bytes, start, end) {
          return unescape(percentEncode$1(bytes, start, end));
        }, parseSyncSafeInteger$1 = function parseSyncSafeInteger2(data) {
          return data[0] << 21 | data[1] << 14 | data[2] << 7 | data[3];
        }, frameParsers = {
          "APIC": function APIC(frame) {
            var i = 1, mimeTypeEndIndex, descriptionEndIndex, LINK_MIME_TYPE = "-->";
            if (frame.data[0] !== textEncodingDescriptionByte.Utf8) {
              return;
            }
            mimeTypeEndIndex = typedArrayIndexOf(frame.data, 0, i);
            if (mimeTypeEndIndex < 0) {
              return;
            }
            frame.mimeType = parseIso88591$1(frame.data, i, mimeTypeEndIndex);
            i = mimeTypeEndIndex + 1;
            frame.pictureType = frame.data[i];
            i++;
            descriptionEndIndex = typedArrayIndexOf(frame.data, 0, i);
            if (descriptionEndIndex < 0) {
              return;
            }
            frame.description = parseUtf8(frame.data, i, descriptionEndIndex);
            i = descriptionEndIndex + 1;
            if (frame.mimeType === LINK_MIME_TYPE) {
              frame.url = parseIso88591$1(frame.data, i, frame.data.length);
            } else {
              frame.pictureData = frame.data.subarray(i, frame.data.length);
            }
          },
          "T*": function T(frame) {
            if (frame.data[0] !== textEncodingDescriptionByte.Utf8) {
              return;
            }
            frame.value = parseUtf8(frame.data, 1, frame.data.length).replace(/\0*$/, "");
            frame.values = frame.value.split("\0");
          },
          "TXXX": function TXXX(frame) {
            var descriptionEndIndex;
            if (frame.data[0] !== textEncodingDescriptionByte.Utf8) {
              return;
            }
            descriptionEndIndex = typedArrayIndexOf(frame.data, 0, 1);
            if (descriptionEndIndex === -1) {
              return;
            }
            frame.description = parseUtf8(frame.data, 1, descriptionEndIndex);
            frame.value = parseUtf8(frame.data, descriptionEndIndex + 1, frame.data.length).replace(/\0*$/, "");
            frame.data = frame.value;
          },
          "W*": function W(frame) {
            frame.url = parseIso88591$1(frame.data, 0, frame.data.length).replace(/\0.*$/, "");
          },
          "WXXX": function WXXX(frame) {
            var descriptionEndIndex;
            if (frame.data[0] !== textEncodingDescriptionByte.Utf8) {
              return;
            }
            descriptionEndIndex = typedArrayIndexOf(frame.data, 0, 1);
            if (descriptionEndIndex === -1) {
              return;
            }
            frame.description = parseUtf8(frame.data, 1, descriptionEndIndex);
            frame.url = parseIso88591$1(frame.data, descriptionEndIndex + 1, frame.data.length).replace(/\0.*$/, "");
          },
          "PRIV": function PRIV(frame) {
            var i;
            for (i = 0; i < frame.data.length; i++) {
              if (frame.data[i] === 0) {
                frame.owner = parseIso88591$1(frame.data, 0, i);
                break;
              }
            }
            frame.privateData = frame.data.subarray(i + 1);
            frame.data = frame.privateData;
          }
        };
        var parseId3Frames$1 = function parseId3Frames2(data) {
          var frameSize, frameHeader, frameStart = 10, tagSize = 0, frames = [];
          if (data.length < 10 || data[0] !== "I".charCodeAt(0) || data[1] !== "D".charCodeAt(0) || data[2] !== "3".charCodeAt(0)) {
            return;
          }
          tagSize = parseSyncSafeInteger$1(data.subarray(6, 10));
          tagSize += 10;
          var hasExtendedHeader = data[5] & 64;
          if (hasExtendedHeader) {
            frameStart += 4;
            frameStart += parseSyncSafeInteger$1(data.subarray(10, 14));
            tagSize -= parseSyncSafeInteger$1(data.subarray(16, 20));
          }
          do {
            frameSize = parseSyncSafeInteger$1(data.subarray(frameStart + 4, frameStart + 8));
            if (frameSize < 1) {
              break;
            }
            frameHeader = String.fromCharCode(data[frameStart], data[frameStart + 1], data[frameStart + 2], data[frameStart + 3]);
            var frame = {
              id: frameHeader,
              data: data.subarray(frameStart + 10, frameStart + frameSize + 10)
            };
            frame.key = frame.id;
            if (frameParsers[frame.id]) {
              frameParsers[frame.id](frame);
            } else if (frame.id[0] === "T") {
              frameParsers["T*"](frame);
            } else if (frame.id[0] === "W") {
              frameParsers["W*"](frame);
            }
            frames.push(frame);
            frameStart += 10;
            frameStart += frameSize;
          } while (frameStart < tagSize);
          return frames;
        };
        var parseId3 = {
          parseId3Frames: parseId3Frames$1,
          parseSyncSafeInteger: parseSyncSafeInteger$1,
          frameParsers
        };
        var toUnsigned = bin.toUnsigned;
        var toHexString = bin.toHexString;
        var findBox$4 = findBox_1;
        var parseType$3 = parseType_1;
        var emsg = emsg$1;
        var parseTfhd$1 = parseTfhd$2;
        var parseTrun$1 = parseTrun$2;
        var parseTfdt$2 = parseTfdt$3;
        var getUint64$2 = numbers.getUint64;
        var timescale, startTime, compositionStartTime, getVideoTrackIds, getTracks, getTimescaleFromMediaHeader$1, getEmsgID3;
        var window$1 = require$$8__default["default"];
        var parseId3Frames = parseId3.parseId3Frames;
        timescale = function timescale2(init) {
          var result = {}, traks = findBox$4(init, ["moov", "trak"]);
          return traks.reduce(function(result2, trak2) {
            var tkhd2, version, index, id, mdhd2;
            tkhd2 = findBox$4(trak2, ["tkhd"])[0];
            if (!tkhd2) {
              return null;
            }
            version = tkhd2[0];
            index = version === 0 ? 12 : 20;
            id = toUnsigned(tkhd2[index] << 24 | tkhd2[index + 1] << 16 | tkhd2[index + 2] << 8 | tkhd2[index + 3]);
            mdhd2 = findBox$4(trak2, ["mdia", "mdhd"])[0];
            if (!mdhd2) {
              return null;
            }
            version = mdhd2[0];
            index = version === 0 ? 12 : 20;
            result2[id] = toUnsigned(mdhd2[index] << 24 | mdhd2[index + 1] << 16 | mdhd2[index + 2] << 8 | mdhd2[index + 3]);
            return result2;
          }, result);
        };
        startTime = function startTime2(timescale2, fragment) {
          var trafs;
          trafs = findBox$4(fragment, ["moof", "traf"]);
          var lowestTime = trafs.reduce(function(acc, traf2) {
            var tfhd2 = findBox$4(traf2, ["tfhd"])[0];
            var id = toUnsigned(tfhd2[4] << 24 | tfhd2[5] << 16 | tfhd2[6] << 8 | tfhd2[7]);
            var scale = timescale2[id] || 9e4;
            var tfdt2 = findBox$4(traf2, ["tfdt"])[0];
            var dv = new DataView(tfdt2.buffer, tfdt2.byteOffset, tfdt2.byteLength);
            var baseTime;
            if (tfdt2[0] === 1) {
              baseTime = getUint64$2(tfdt2.subarray(4, 12));
            } else {
              baseTime = dv.getUint32(4);
            }
            var seconds;
            if (typeof baseTime === "bigint") {
              seconds = baseTime / window$1.BigInt(scale);
            } else if (typeof baseTime === "number" && !isNaN(baseTime)) {
              seconds = baseTime / scale;
            }
            if (seconds < Number.MAX_SAFE_INTEGER) {
              seconds = Number(seconds);
            }
            if (seconds < acc) {
              acc = seconds;
            }
            return acc;
          }, Infinity);
          return typeof lowestTime === "bigint" || isFinite(lowestTime) ? lowestTime : 0;
        };
        compositionStartTime = function compositionStartTime2(timescales, fragment) {
          var trafBoxes = findBox$4(fragment, ["moof", "traf"]);
          var baseMediaDecodeTime = 0;
          var compositionTimeOffset = 0;
          var trackId;
          if (trafBoxes && trafBoxes.length) {
            var tfhd2 = findBox$4(trafBoxes[0], ["tfhd"])[0];
            var trun2 = findBox$4(trafBoxes[0], ["trun"])[0];
            var tfdt2 = findBox$4(trafBoxes[0], ["tfdt"])[0];
            if (tfhd2) {
              var parsedTfhd = parseTfhd$1(tfhd2);
              trackId = parsedTfhd.trackId;
            }
            if (tfdt2) {
              var parsedTfdt = parseTfdt$2(tfdt2);
              baseMediaDecodeTime = parsedTfdt.baseMediaDecodeTime;
            }
            if (trun2) {
              var parsedTrun = parseTrun$1(trun2);
              if (parsedTrun.samples && parsedTrun.samples.length) {
                compositionTimeOffset = parsedTrun.samples[0].compositionTimeOffset || 0;
              }
            }
          }
          var timescale2 = timescales[trackId] || 9e4;
          if (typeof baseMediaDecodeTime === "bigint") {
            compositionTimeOffset = window$1.BigInt(compositionTimeOffset);
            timescale2 = window$1.BigInt(timescale2);
          }
          var result = (baseMediaDecodeTime + compositionTimeOffset) / timescale2;
          if (typeof result === "bigint" && result < Number.MAX_SAFE_INTEGER) {
            result = Number(result);
          }
          return result;
        };
        getVideoTrackIds = function getVideoTrackIds2(init) {
          var traks = findBox$4(init, ["moov", "trak"]);
          var videoTrackIds = [];
          traks.forEach(function(trak2) {
            var hdlrs = findBox$4(trak2, ["mdia", "hdlr"]);
            var tkhds = findBox$4(trak2, ["tkhd"]);
            hdlrs.forEach(function(hdlr2, index) {
              var handlerType = parseType$3(hdlr2.subarray(8, 12));
              var tkhd2 = tkhds[index];
              var view;
              var version;
              var trackId;
              if (handlerType === "vide") {
                view = new DataView(tkhd2.buffer, tkhd2.byteOffset, tkhd2.byteLength);
                version = view.getUint8(0);
                trackId = version === 0 ? view.getUint32(12) : view.getUint32(20);
                videoTrackIds.push(trackId);
              }
            });
          });
          return videoTrackIds;
        };
        getTimescaleFromMediaHeader$1 = function getTimescaleFromMediaHeader2(mdhd2) {
          var version = mdhd2[0];
          var index = version === 0 ? 12 : 20;
          return toUnsigned(mdhd2[index] << 24 | mdhd2[index + 1] << 16 | mdhd2[index + 2] << 8 | mdhd2[index + 3]);
        };
        getTracks = function getTracks2(init) {
          var traks = findBox$4(init, ["moov", "trak"]);
          var tracks = [];
          traks.forEach(function(trak2) {
            var track = {};
            var tkhd2 = findBox$4(trak2, ["tkhd"])[0];
            var view, tkhdVersion;
            if (tkhd2) {
              view = new DataView(tkhd2.buffer, tkhd2.byteOffset, tkhd2.byteLength);
              tkhdVersion = view.getUint8(0);
              track.id = tkhdVersion === 0 ? view.getUint32(12) : view.getUint32(20);
            }
            var hdlr2 = findBox$4(trak2, ["mdia", "hdlr"])[0];
            if (hdlr2) {
              var type2 = parseType$3(hdlr2.subarray(8, 12));
              if (type2 === "vide") {
                track.type = "video";
              } else if (type2 === "soun") {
                track.type = "audio";
              } else {
                track.type = type2;
              }
            }
            var stsd2 = findBox$4(trak2, ["mdia", "minf", "stbl", "stsd"])[0];
            if (stsd2) {
              var sampleDescriptions = stsd2.subarray(8);
              track.codec = parseType$3(sampleDescriptions.subarray(4, 8));
              var codecBox = findBox$4(sampleDescriptions, [track.codec])[0];
              var codecConfig, codecConfigType;
              if (codecBox) {
                if (/^[asm]vc[1-9]$/i.test(track.codec)) {
                  codecConfig = codecBox.subarray(78);
                  codecConfigType = parseType$3(codecConfig.subarray(4, 8));
                  if (codecConfigType === "avcC" && codecConfig.length > 11) {
                    track.codec += ".";
                    track.codec += toHexString(codecConfig[9]);
                    track.codec += toHexString(codecConfig[10]);
                    track.codec += toHexString(codecConfig[11]);
                  } else {
                    track.codec = "avc1.4d400d";
                  }
                } else if (/^mp4[a,v]$/i.test(track.codec)) {
                  codecConfig = codecBox.subarray(28);
                  codecConfigType = parseType$3(codecConfig.subarray(4, 8));
                  if (codecConfigType === "esds" && codecConfig.length > 20 && codecConfig[19] !== 0) {
                    track.codec += "." + toHexString(codecConfig[19]);
                    track.codec += "." + toHexString(codecConfig[20] >>> 2 & 63).replace(/^0/, "");
                  } else {
                    track.codec = "mp4a.40.2";
                  }
                } else {
                  track.codec = track.codec.toLowerCase();
                }
              }
            }
            var mdhd2 = findBox$4(trak2, ["mdia", "mdhd"])[0];
            if (mdhd2) {
              track.timescale = getTimescaleFromMediaHeader$1(mdhd2);
            }
            tracks.push(track);
          });
          return tracks;
        };
        getEmsgID3 = function getEmsgID32(segmentData, offset) {
          if (offset === void 0) {
            offset = 0;
          }
          var emsgBoxes = findBox$4(segmentData, ["emsg"]);
          return emsgBoxes.map(function(data) {
            var parsedBox = emsg.parseEmsgBox(new Uint8Array(data));
            var parsedId3Frames = parseId3Frames(parsedBox.message_data);
            return {
              cueTime: emsg.scaleTime(parsedBox.presentation_time, parsedBox.timescale, parsedBox.presentation_time_delta, offset),
              duration: emsg.scaleTime(parsedBox.event_duration, parsedBox.timescale),
              frames: parsedId3Frames
            };
          });
        };
        var probe$2 = {
          // export mp4 inspector's findBox and parseType for backwards compatibility
          findBox: findBox$4,
          parseType: parseType$3,
          timescale,
          startTime,
          compositionStartTime,
          videoTrackIds: getVideoTrackIds,
          tracks: getTracks,
          getTimescaleFromMediaHeader: getTimescaleFromMediaHeader$1,
          getEmsgID3
        };
        var groupNalsIntoFrames = function groupNalsIntoFrames2(nalUnits) {
          var i, currentNal, currentFrame = [], frames = [];
          frames.byteLength = 0;
          frames.nalCount = 0;
          frames.duration = 0;
          currentFrame.byteLength = 0;
          for (i = 0; i < nalUnits.length; i++) {
            currentNal = nalUnits[i];
            if (currentNal.nalUnitType === "access_unit_delimiter_rbsp") {
              if (currentFrame.length) {
                currentFrame.duration = currentNal.dts - currentFrame.dts;
                frames.byteLength += currentFrame.byteLength;
                frames.nalCount += currentFrame.length;
                frames.duration += currentFrame.duration;
                frames.push(currentFrame);
              }
              currentFrame = [currentNal];
              currentFrame.byteLength = currentNal.data.byteLength;
              currentFrame.pts = currentNal.pts;
              currentFrame.dts = currentNal.dts;
            } else {
              if (currentNal.nalUnitType === "slice_layer_without_partitioning_rbsp_idr") {
                currentFrame.keyFrame = true;
              }
              currentFrame.duration = currentNal.dts - currentFrame.dts;
              currentFrame.byteLength += currentNal.data.byteLength;
              currentFrame.push(currentNal);
            }
          }
          if (frames.length && (!currentFrame.duration || currentFrame.duration <= 0)) {
            currentFrame.duration = frames[frames.length - 1].duration;
          }
          frames.byteLength += currentFrame.byteLength;
          frames.nalCount += currentFrame.length;
          frames.duration += currentFrame.duration;
          frames.push(currentFrame);
          return frames;
        };
        var groupFramesIntoGops = function groupFramesIntoGops2(frames) {
          var i, currentFrame, currentGop = [], gops = [];
          currentGop.byteLength = 0;
          currentGop.nalCount = 0;
          currentGop.duration = 0;
          currentGop.pts = frames[0].pts;
          currentGop.dts = frames[0].dts;
          gops.byteLength = 0;
          gops.nalCount = 0;
          gops.duration = 0;
          gops.pts = frames[0].pts;
          gops.dts = frames[0].dts;
          for (i = 0; i < frames.length; i++) {
            currentFrame = frames[i];
            if (currentFrame.keyFrame) {
              if (currentGop.length) {
                gops.push(currentGop);
                gops.byteLength += currentGop.byteLength;
                gops.nalCount += currentGop.nalCount;
                gops.duration += currentGop.duration;
              }
              currentGop = [currentFrame];
              currentGop.nalCount = currentFrame.length;
              currentGop.byteLength = currentFrame.byteLength;
              currentGop.pts = currentFrame.pts;
              currentGop.dts = currentFrame.dts;
              currentGop.duration = currentFrame.duration;
            } else {
              currentGop.duration += currentFrame.duration;
              currentGop.nalCount += currentFrame.length;
              currentGop.byteLength += currentFrame.byteLength;
              currentGop.push(currentFrame);
            }
          }
          if (gops.length && currentGop.duration <= 0) {
            currentGop.duration = gops[gops.length - 1].duration;
          }
          gops.byteLength += currentGop.byteLength;
          gops.nalCount += currentGop.nalCount;
          gops.duration += currentGop.duration;
          gops.push(currentGop);
          return gops;
        };
        var extendFirstKeyFrame = function extendFirstKeyFrame2(gops) {
          var currentGop;
          if (!gops[0][0].keyFrame && gops.length > 1) {
            currentGop = gops.shift();
            gops.byteLength -= currentGop.byteLength;
            gops.nalCount -= currentGop.nalCount;
            gops[0][0].dts = currentGop.dts;
            gops[0][0].pts = currentGop.pts;
            gops[0][0].duration += currentGop.duration;
          }
          return gops;
        };
        var createDefaultSample = function createDefaultSample2() {
          return {
            size: 0,
            flags: {
              isLeading: 0,
              dependsOn: 1,
              isDependedOn: 0,
              hasRedundancy: 0,
              degradationPriority: 0,
              isNonSyncSample: 1
            }
          };
        };
        var sampleForFrame = function sampleForFrame2(frame, dataOffset) {
          var sample = createDefaultSample();
          sample.dataOffset = dataOffset;
          sample.compositionTimeOffset = frame.pts - frame.dts;
          sample.duration = frame.duration;
          sample.size = 4 * frame.length;
          sample.size += frame.byteLength;
          if (frame.keyFrame) {
            sample.flags.dependsOn = 2;
            sample.flags.isNonSyncSample = 0;
          }
          return sample;
        };
        var generateSampleTable$1 = function generateSampleTable2(gops, baseDataOffset) {
          var h, i, sample, currentGop, currentFrame, dataOffset = baseDataOffset || 0, samples2 = [];
          for (h = 0; h < gops.length; h++) {
            currentGop = gops[h];
            for (i = 0; i < currentGop.length; i++) {
              currentFrame = currentGop[i];
              sample = sampleForFrame(currentFrame, dataOffset);
              dataOffset += sample.size;
              samples2.push(sample);
            }
          }
          return samples2;
        };
        var concatenateNalData = function concatenateNalData2(gops) {
          var h, i, j, currentGop, currentFrame, currentNal, dataOffset = 0, nalsByteLength = gops.byteLength, numberOfNals = gops.nalCount, totalByteLength = nalsByteLength + 4 * numberOfNals, data = new Uint8Array(totalByteLength), view = new DataView(data.buffer);
          for (h = 0; h < gops.length; h++) {
            currentGop = gops[h];
            for (i = 0; i < currentGop.length; i++) {
              currentFrame = currentGop[i];
              for (j = 0; j < currentFrame.length; j++) {
                currentNal = currentFrame[j];
                view.setUint32(dataOffset, currentNal.data.byteLength);
                dataOffset += 4;
                data.set(currentNal.data, dataOffset);
                dataOffset += currentNal.data.byteLength;
              }
            }
          }
          return data;
        };
        var generateSampleTableForFrame = function generateSampleTableForFrame2(frame, baseDataOffset) {
          var sample, dataOffset = baseDataOffset || 0, samples2 = [];
          sample = sampleForFrame(frame, dataOffset);
          samples2.push(sample);
          return samples2;
        };
        var concatenateNalDataForFrame = function concatenateNalDataForFrame2(frame) {
          var i, currentNal, dataOffset = 0, nalsByteLength = frame.byteLength, numberOfNals = frame.length, totalByteLength = nalsByteLength + 4 * numberOfNals, data = new Uint8Array(totalByteLength), view = new DataView(data.buffer);
          for (i = 0; i < frame.length; i++) {
            currentNal = frame[i];
            view.setUint32(dataOffset, currentNal.data.byteLength);
            dataOffset += 4;
            data.set(currentNal.data, dataOffset);
            dataOffset += currentNal.data.byteLength;
          }
          return data;
        };
        var frameUtils$2 = {
          groupNalsIntoFrames,
          groupFramesIntoGops,
          extendFirstKeyFrame,
          generateSampleTable: generateSampleTable$1,
          concatenateNalData,
          generateSampleTableForFrame,
          concatenateNalDataForFrame
        };
        var highPrefix = [33, 16, 5, 32, 164, 27];
        var lowPrefix = [33, 65, 108, 84, 1, 2, 4, 8, 168, 2, 4, 8, 17, 191, 252];
        var zeroFill = function zeroFill2(count) {
          var a = [];
          while (count--) {
            a.push(0);
          }
          return a;
        };
        var makeTable = function makeTable2(metaTable) {
          return Object.keys(metaTable).reduce(function(obj, key) {
            obj[key] = new Uint8Array(metaTable[key].reduce(function(arr, part) {
              return arr.concat(part);
            }, []));
            return obj;
          }, {});
        };
        var silence;
        var silence_1 = function silence_12() {
          if (!silence) {
            var coneOfSilence2 = {
              96e3: [highPrefix, [227, 64], zeroFill(154), [56]],
              88200: [highPrefix, [231], zeroFill(170), [56]],
              64e3: [highPrefix, [248, 192], zeroFill(240), [56]],
              48e3: [highPrefix, [255, 192], zeroFill(268), [55, 148, 128], zeroFill(54), [112]],
              44100: [highPrefix, [255, 192], zeroFill(268), [55, 163, 128], zeroFill(84), [112]],
              32e3: [highPrefix, [255, 192], zeroFill(268), [55, 234], zeroFill(226), [112]],
              24e3: [highPrefix, [255, 192], zeroFill(268), [55, 255, 128], zeroFill(268), [111, 112], zeroFill(126), [224]],
              16e3: [highPrefix, [255, 192], zeroFill(268), [55, 255, 128], zeroFill(268), [111, 255], zeroFill(269), [223, 108], zeroFill(195), [1, 192]],
              12e3: [lowPrefix, zeroFill(268), [3, 127, 248], zeroFill(268), [6, 255, 240], zeroFill(268), [13, 255, 224], zeroFill(268), [27, 253, 128], zeroFill(259), [56]],
              11025: [lowPrefix, zeroFill(268), [3, 127, 248], zeroFill(268), [6, 255, 240], zeroFill(268), [13, 255, 224], zeroFill(268), [27, 255, 192], zeroFill(268), [55, 175, 128], zeroFill(108), [112]],
              8e3: [lowPrefix, zeroFill(268), [3, 121, 16], zeroFill(47), [7]]
            };
            silence = makeTable(coneOfSilence2);
          }
          return silence;
        };
        var coneOfSilence = silence_1;
        var clock$2 = clock$3;
        var sumFrameByteLengths = function sumFrameByteLengths2(array) {
          var i, currentObj, sum = 0;
          for (i = 0; i < array.length; i++) {
            currentObj = array[i];
            sum += currentObj.data.byteLength;
          }
          return sum;
        };
        var prefixWithSilence = function prefixWithSilence2(track, frames, audioAppendStartTs, videoBaseMediaDecodeTime) {
          var baseMediaDecodeTimeTs, frameDuration = 0, audioGapDuration = 0, audioFillFrameCount = 0, audioFillDuration = 0, silentFrame, i, firstFrame;
          if (!frames.length) {
            return;
          }
          baseMediaDecodeTimeTs = clock$2.audioTsToVideoTs(track.baseMediaDecodeTime, track.samplerate);
          frameDuration = Math.ceil(clock$2.ONE_SECOND_IN_TS / (track.samplerate / 1024));
          if (audioAppendStartTs && videoBaseMediaDecodeTime) {
            audioGapDuration = baseMediaDecodeTimeTs - Math.max(audioAppendStartTs, videoBaseMediaDecodeTime);
            audioFillFrameCount = Math.floor(audioGapDuration / frameDuration);
            audioFillDuration = audioFillFrameCount * frameDuration;
          }
          if (audioFillFrameCount < 1 || audioFillDuration > clock$2.ONE_SECOND_IN_TS / 2) {
            return;
          }
          silentFrame = coneOfSilence()[track.samplerate];
          if (!silentFrame) {
            silentFrame = frames[0].data;
          }
          for (i = 0; i < audioFillFrameCount; i++) {
            firstFrame = frames[0];
            frames.splice(0, 0, {
              data: silentFrame,
              dts: firstFrame.dts - frameDuration,
              pts: firstFrame.pts - frameDuration
            });
          }
          track.baseMediaDecodeTime -= Math.floor(clock$2.videoTsToAudioTs(audioFillDuration, track.samplerate));
          return audioFillDuration;
        };
        var trimAdtsFramesByEarliestDts = function trimAdtsFramesByEarliestDts2(adtsFrames, track, earliestAllowedDts) {
          if (track.minSegmentDts >= earliestAllowedDts) {
            return adtsFrames;
          }
          track.minSegmentDts = Infinity;
          return adtsFrames.filter(function(currentFrame) {
            if (currentFrame.dts >= earliestAllowedDts) {
              track.minSegmentDts = Math.min(track.minSegmentDts, currentFrame.dts);
              track.minSegmentPts = track.minSegmentDts;
              return true;
            }
            return false;
          });
        };
        var generateSampleTable = function generateSampleTable2(frames) {
          var i, currentFrame, samples2 = [];
          for (i = 0; i < frames.length; i++) {
            currentFrame = frames[i];
            samples2.push({
              size: currentFrame.data.byteLength,
              duration: 1024
              // For AAC audio, all samples contain 1024 samples
            });
          }
          return samples2;
        };
        var concatenateFrameData = function concatenateFrameData2(frames) {
          var i, currentFrame, dataOffset = 0, data = new Uint8Array(sumFrameByteLengths(frames));
          for (i = 0; i < frames.length; i++) {
            currentFrame = frames[i];
            data.set(currentFrame.data, dataOffset);
            dataOffset += currentFrame.data.byteLength;
          }
          return data;
        };
        var audioFrameUtils$2 = {
          prefixWithSilence,
          trimAdtsFramesByEarliestDts,
          generateSampleTable,
          concatenateFrameData
        };
        var ONE_SECOND_IN_TS$3 = clock$3.ONE_SECOND_IN_TS;
        var collectDtsInfo = function collectDtsInfo2(track, data) {
          if (typeof data.pts === "number") {
            if (track.timelineStartInfo.pts === void 0) {
              track.timelineStartInfo.pts = data.pts;
            }
            if (track.minSegmentPts === void 0) {
              track.minSegmentPts = data.pts;
            } else {
              track.minSegmentPts = Math.min(track.minSegmentPts, data.pts);
            }
            if (track.maxSegmentPts === void 0) {
              track.maxSegmentPts = data.pts;
            } else {
              track.maxSegmentPts = Math.max(track.maxSegmentPts, data.pts);
            }
          }
          if (typeof data.dts === "number") {
            if (track.timelineStartInfo.dts === void 0) {
              track.timelineStartInfo.dts = data.dts;
            }
            if (track.minSegmentDts === void 0) {
              track.minSegmentDts = data.dts;
            } else {
              track.minSegmentDts = Math.min(track.minSegmentDts, data.dts);
            }
            if (track.maxSegmentDts === void 0) {
              track.maxSegmentDts = data.dts;
            } else {
              track.maxSegmentDts = Math.max(track.maxSegmentDts, data.dts);
            }
          }
        };
        var clearDtsInfo = function clearDtsInfo2(track) {
          delete track.minSegmentDts;
          delete track.maxSegmentDts;
          delete track.minSegmentPts;
          delete track.maxSegmentPts;
        };
        var calculateTrackBaseMediaDecodeTime = function calculateTrackBaseMediaDecodeTime2(track, keepOriginalTimestamps) {
          var baseMediaDecodeTime, scale, minSegmentDts = track.minSegmentDts;
          if (!keepOriginalTimestamps) {
            minSegmentDts -= track.timelineStartInfo.dts;
          }
          baseMediaDecodeTime = track.timelineStartInfo.baseMediaDecodeTime;
          baseMediaDecodeTime += minSegmentDts;
          baseMediaDecodeTime = Math.max(0, baseMediaDecodeTime);
          if (track.type === "audio") {
            scale = track.samplerate / ONE_SECOND_IN_TS$3;
            baseMediaDecodeTime *= scale;
            baseMediaDecodeTime = Math.floor(baseMediaDecodeTime);
          }
          return baseMediaDecodeTime;
        };
        var trackDecodeInfo$1 = {
          clearDtsInfo,
          calculateTrackBaseMediaDecodeTime,
          collectDtsInfo
        };
        var USER_DATA_REGISTERED_ITU_T_T35 = 4, RBSP_TRAILING_BITS = 128;
        var parseSei = function parseSei2(bytes) {
          var i = 0, result = {
            payloadType: -1,
            payloadSize: 0
          }, payloadType = 0, payloadSize = 0;
          while (i < bytes.byteLength) {
            if (bytes[i] === RBSP_TRAILING_BITS) {
              break;
            }
            while (bytes[i] === 255) {
              payloadType += 255;
              i++;
            }
            payloadType += bytes[i++];
            while (bytes[i] === 255) {
              payloadSize += 255;
              i++;
            }
            payloadSize += bytes[i++];
            if (!result.payload && payloadType === USER_DATA_REGISTERED_ITU_T_T35) {
              var userIdentifier = String.fromCharCode(bytes[i + 3], bytes[i + 4], bytes[i + 5], bytes[i + 6]);
              if (userIdentifier === "GA94") {
                result.payloadType = payloadType;
                result.payloadSize = payloadSize;
                result.payload = bytes.subarray(i, i + payloadSize);
                break;
              } else {
                result.payload = void 0;
              }
            }
            i += payloadSize;
            payloadType = 0;
            payloadSize = 0;
          }
          return result;
        };
        var parseUserData = function parseUserData2(sei) {
          if (sei.payload[0] !== 181) {
            return null;
          }
          if ((sei.payload[1] << 8 | sei.payload[2]) !== 49) {
            return null;
          }
          if (String.fromCharCode(sei.payload[3], sei.payload[4], sei.payload[5], sei.payload[6]) !== "GA94") {
            return null;
          }
          if (sei.payload[7] !== 3) {
            return null;
          }
          return sei.payload.subarray(8, sei.payload.length - 1);
        };
        var parseCaptionPackets = function parseCaptionPackets2(pts, userData) {
          var results = [], i, count, offset, data;
          if (!(userData[0] & 64)) {
            return results;
          }
          count = userData[0] & 31;
          for (i = 0; i < count; i++) {
            offset = i * 3;
            data = {
              type: userData[offset + 2] & 3,
              pts
            };
            if (userData[offset + 2] & 4) {
              data.ccData = userData[offset + 3] << 8 | userData[offset + 4];
              results.push(data);
            }
          }
          return results;
        };
        var discardEmulationPreventionBytes$1 = function discardEmulationPreventionBytes2(data) {
          var length = data.byteLength, emulationPreventionBytesPositions = [], i = 1, newLength, newData;
          while (i < length - 2) {
            if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 3) {
              emulationPreventionBytesPositions.push(i + 2);
              i += 2;
            } else {
              i++;
            }
          }
          if (emulationPreventionBytesPositions.length === 0) {
            return data;
          }
          newLength = length - emulationPreventionBytesPositions.length;
          newData = new Uint8Array(newLength);
          var sourceIndex = 0;
          for (i = 0; i < newLength; sourceIndex++, i++) {
            if (sourceIndex === emulationPreventionBytesPositions[0]) {
              sourceIndex++;
              emulationPreventionBytesPositions.shift();
            }
            newData[i] = data[sourceIndex];
          }
          return newData;
        };
        var captionPacketParser = {
          parseSei,
          parseUserData,
          parseCaptionPackets,
          discardEmulationPreventionBytes: discardEmulationPreventionBytes$1,
          USER_DATA_REGISTERED_ITU_T_T35
        };
        var Stream$a = stream;
        var cea708Parser = captionPacketParser;
        var CaptionStream$2 = function CaptionStream2(options) {
          options = options || {};
          CaptionStream2.prototype.init.call(this);
          this.parse708captions_ = typeof options.parse708captions === "boolean" ? options.parse708captions : true;
          this.captionPackets_ = [];
          this.ccStreams_ = [
            new Cea608Stream(0, 0),
            // eslint-disable-line no-use-before-define
            new Cea608Stream(0, 1),
            // eslint-disable-line no-use-before-define
            new Cea608Stream(1, 0),
            // eslint-disable-line no-use-before-define
            new Cea608Stream(1, 1)
            // eslint-disable-line no-use-before-define
          ];
          if (this.parse708captions_) {
            this.cc708Stream_ = new Cea708Stream({
              captionServices: options.captionServices
            });
          }
          this.reset();
          this.ccStreams_.forEach(function(cc) {
            cc.on("data", this.trigger.bind(this, "data"));
            cc.on("partialdone", this.trigger.bind(this, "partialdone"));
            cc.on("done", this.trigger.bind(this, "done"));
          }, this);
          if (this.parse708captions_) {
            this.cc708Stream_.on("data", this.trigger.bind(this, "data"));
            this.cc708Stream_.on("partialdone", this.trigger.bind(this, "partialdone"));
            this.cc708Stream_.on("done", this.trigger.bind(this, "done"));
          }
        };
        CaptionStream$2.prototype = new Stream$a();
        CaptionStream$2.prototype.push = function(event) {
          var sei, userData, newCaptionPackets;
          if (event.nalUnitType !== "sei_rbsp") {
            return;
          }
          sei = cea708Parser.parseSei(event.escapedRBSP);
          if (!sei.payload) {
            return;
          }
          if (sei.payloadType !== cea708Parser.USER_DATA_REGISTERED_ITU_T_T35) {
            return;
          }
          userData = cea708Parser.parseUserData(sei);
          if (!userData) {
            return;
          }
          if (event.dts < this.latestDts_) {
            this.ignoreNextEqualDts_ = true;
            return;
          } else if (event.dts === this.latestDts_ && this.ignoreNextEqualDts_) {
            this.numSameDts_--;
            if (!this.numSameDts_) {
              this.ignoreNextEqualDts_ = false;
            }
            return;
          }
          newCaptionPackets = cea708Parser.parseCaptionPackets(event.pts, userData);
          this.captionPackets_ = this.captionPackets_.concat(newCaptionPackets);
          if (this.latestDts_ !== event.dts) {
            this.numSameDts_ = 0;
          }
          this.numSameDts_++;
          this.latestDts_ = event.dts;
        };
        CaptionStream$2.prototype.flushCCStreams = function(flushType) {
          this.ccStreams_.forEach(function(cc) {
            return flushType === "flush" ? cc.flush() : cc.partialFlush();
          }, this);
        };
        CaptionStream$2.prototype.flushStream = function(flushType) {
          if (!this.captionPackets_.length) {
            this.flushCCStreams(flushType);
            return;
          }
          this.captionPackets_.forEach(function(elem, idx) {
            elem.presortIndex = idx;
          });
          this.captionPackets_.sort(function(a, b) {
            if (a.pts === b.pts) {
              return a.presortIndex - b.presortIndex;
            }
            return a.pts - b.pts;
          });
          this.captionPackets_.forEach(function(packet) {
            if (packet.type < 2) {
              this.dispatchCea608Packet(packet);
            } else {
              this.dispatchCea708Packet(packet);
            }
          }, this);
          this.captionPackets_.length = 0;
          this.flushCCStreams(flushType);
        };
        CaptionStream$2.prototype.flush = function() {
          return this.flushStream("flush");
        };
        CaptionStream$2.prototype.partialFlush = function() {
          return this.flushStream("partialFlush");
        };
        CaptionStream$2.prototype.reset = function() {
          this.latestDts_ = null;
          this.ignoreNextEqualDts_ = false;
          this.numSameDts_ = 0;
          this.activeCea608Channel_ = [null, null];
          this.ccStreams_.forEach(function(ccStream) {
            ccStream.reset();
          });
        };
        CaptionStream$2.prototype.dispatchCea608Packet = function(packet) {
          if (this.setsTextOrXDSActive(packet)) {
            this.activeCea608Channel_[packet.type] = null;
          } else if (this.setsChannel1Active(packet)) {
            this.activeCea608Channel_[packet.type] = 0;
          } else if (this.setsChannel2Active(packet)) {
            this.activeCea608Channel_[packet.type] = 1;
          }
          if (this.activeCea608Channel_[packet.type] === null) {
            return;
          }
          this.ccStreams_[(packet.type << 1) + this.activeCea608Channel_[packet.type]].push(packet);
        };
        CaptionStream$2.prototype.setsChannel1Active = function(packet) {
          return (packet.ccData & 30720) === 4096;
        };
        CaptionStream$2.prototype.setsChannel2Active = function(packet) {
          return (packet.ccData & 30720) === 6144;
        };
        CaptionStream$2.prototype.setsTextOrXDSActive = function(packet) {
          return (packet.ccData & 28928) === 256 || (packet.ccData & 30974) === 4138 || (packet.ccData & 30974) === 6186;
        };
        CaptionStream$2.prototype.dispatchCea708Packet = function(packet) {
          if (this.parse708captions_) {
            this.cc708Stream_.push(packet);
          }
        };
        var CHARACTER_TRANSLATION_708 = {
          127: 9834,
          // ♪
          4128: 32,
          // Transparent Space
          4129: 160,
          // Nob-breaking Transparent Space
          4133: 8230,
          // …
          4138: 352,
          // Š
          4140: 338,
          // Œ
          4144: 9608,
          // █
          4145: 8216,
          // ‘
          4146: 8217,
          // ’
          4147: 8220,
          // “
          4148: 8221,
          // ”
          4149: 8226,
          // •
          4153: 8482,
          // ™
          4154: 353,
          // š
          4156: 339,
          // œ
          4157: 8480,
          // ℠
          4159: 376,
          // Ÿ
          4214: 8539,
          // ⅛
          4215: 8540,
          // ⅜
          4216: 8541,
          // ⅝
          4217: 8542,
          // ⅞
          4218: 9168,
          // ⏐
          4219: 9124,
          // ⎤
          4220: 9123,
          // ⎣
          4221: 9135,
          // ⎯
          4222: 9126,
          // ⎦
          4223: 9121,
          // ⎡
          4256: 12600
          // ㄸ (CC char)
        };
        var get708CharFromCode = function get708CharFromCode2(code) {
          var newCode = CHARACTER_TRANSLATION_708[code] || code;
          if (code & 4096 && code === newCode) {
            return "";
          }
          return String.fromCharCode(newCode);
        };
        var within708TextBlock = function within708TextBlock2(b) {
          return 32 <= b && b <= 127 || 160 <= b && b <= 255;
        };
        var Cea708Window = function Cea708Window2(windowNum) {
          this.windowNum = windowNum;
          this.reset();
        };
        Cea708Window.prototype.reset = function() {
          this.clearText();
          this.pendingNewLine = false;
          this.winAttr = {};
          this.penAttr = {};
          this.penLoc = {};
          this.penColor = {};
          this.visible = 0;
          this.rowLock = 0;
          this.columnLock = 0;
          this.priority = 0;
          this.relativePositioning = 0;
          this.anchorVertical = 0;
          this.anchorHorizontal = 0;
          this.anchorPoint = 0;
          this.rowCount = 1;
          this.virtualRowCount = this.rowCount + 1;
          this.columnCount = 41;
          this.windowStyle = 0;
          this.penStyle = 0;
        };
        Cea708Window.prototype.getText = function() {
          return this.rows.join("\n");
        };
        Cea708Window.prototype.clearText = function() {
          this.rows = [""];
          this.rowIdx = 0;
        };
        Cea708Window.prototype.newLine = function(pts) {
          if (this.rows.length >= this.virtualRowCount && typeof this.beforeRowOverflow === "function") {
            this.beforeRowOverflow(pts);
          }
          if (this.rows.length > 0) {
            this.rows.push("");
            this.rowIdx++;
          }
          while (this.rows.length > this.virtualRowCount) {
            this.rows.shift();
            this.rowIdx--;
          }
        };
        Cea708Window.prototype.isEmpty = function() {
          if (this.rows.length === 0) {
            return true;
          } else if (this.rows.length === 1) {
            return this.rows[0] === "";
          }
          return false;
        };
        Cea708Window.prototype.addText = function(text) {
          this.rows[this.rowIdx] += text;
        };
        Cea708Window.prototype.backspace = function() {
          if (!this.isEmpty()) {
            var row = this.rows[this.rowIdx];
            this.rows[this.rowIdx] = row.substr(0, row.length - 1);
          }
        };
        var Cea708Service = function Cea708Service2(serviceNum, encoding, stream2) {
          this.serviceNum = serviceNum;
          this.text = "";
          this.currentWindow = new Cea708Window(-1);
          this.windows = [];
          this.stream = stream2;
          if (typeof encoding === "string") {
            this.createTextDecoder(encoding);
          }
        };
        Cea708Service.prototype.init = function(pts, beforeRowOverflow) {
          this.startPts = pts;
          for (var win = 0; win < 8; win++) {
            this.windows[win] = new Cea708Window(win);
            if (typeof beforeRowOverflow === "function") {
              this.windows[win].beforeRowOverflow = beforeRowOverflow;
            }
          }
        };
        Cea708Service.prototype.setCurrentWindow = function(windowNum) {
          this.currentWindow = this.windows[windowNum];
        };
        Cea708Service.prototype.createTextDecoder = function(encoding) {
          if (typeof TextDecoder === "undefined") {
            this.stream.trigger("log", {
              level: "warn",
              message: "The `encoding` option is unsupported without TextDecoder support"
            });
          } else {
            try {
              this.textDecoder_ = new TextDecoder(encoding);
            } catch (error) {
              this.stream.trigger("log", {
                level: "warn",
                message: "TextDecoder could not be created with " + encoding + " encoding. " + error
              });
            }
          }
        };
        var Cea708Stream = function Cea708Stream2(options) {
          options = options || {};
          Cea708Stream2.prototype.init.call(this);
          var self2 = this;
          var captionServices = options.captionServices || {};
          var captionServiceEncodings = {};
          var serviceProps;
          Object.keys(captionServices).forEach(function(serviceName) {
            serviceProps = captionServices[serviceName];
            if (/^SERVICE/.test(serviceName)) {
              captionServiceEncodings[serviceName] = serviceProps.encoding;
            }
          });
          this.serviceEncodings = captionServiceEncodings;
          this.current708Packet = null;
          this.services = {};
          this.push = function(packet) {
            if (packet.type === 3) {
              self2.new708Packet();
              self2.add708Bytes(packet);
            } else {
              if (self2.current708Packet === null) {
                self2.new708Packet();
              }
              self2.add708Bytes(packet);
            }
          };
        };
        Cea708Stream.prototype = new Stream$a();
        Cea708Stream.prototype.new708Packet = function() {
          if (this.current708Packet !== null) {
            this.push708Packet();
          }
          this.current708Packet = {
            data: [],
            ptsVals: []
          };
        };
        Cea708Stream.prototype.add708Bytes = function(packet) {
          var data = packet.ccData;
          var byte0 = data >>> 8;
          var byte1 = data & 255;
          this.current708Packet.ptsVals.push(packet.pts);
          this.current708Packet.data.push(byte0);
          this.current708Packet.data.push(byte1);
        };
        Cea708Stream.prototype.push708Packet = function() {
          var packet708 = this.current708Packet;
          var packetData = packet708.data;
          var serviceNum = null;
          var blockSize = null;
          var i = 0;
          var b = packetData[i++];
          packet708.seq = b >> 6;
          packet708.sizeCode = b & 63;
          for (; i < packetData.length; i++) {
            b = packetData[i++];
            serviceNum = b >> 5;
            blockSize = b & 31;
            if (serviceNum === 7 && blockSize > 0) {
              b = packetData[i++];
              serviceNum = b;
            }
            this.pushServiceBlock(serviceNum, i, blockSize);
            if (blockSize > 0) {
              i += blockSize - 1;
            }
          }
        };
        Cea708Stream.prototype.pushServiceBlock = function(serviceNum, start, size) {
          var b;
          var i = start;
          var packetData = this.current708Packet.data;
          var service = this.services[serviceNum];
          if (!service) {
            service = this.initService(serviceNum, i);
          }
          for (; i < start + size && i < packetData.length; i++) {
            b = packetData[i];
            if (within708TextBlock(b)) {
              i = this.handleText(i, service);
            } else if (b === 24) {
              i = this.multiByteCharacter(i, service);
            } else if (b === 16) {
              i = this.extendedCommands(i, service);
            } else if (128 <= b && b <= 135) {
              i = this.setCurrentWindow(i, service);
            } else if (152 <= b && b <= 159) {
              i = this.defineWindow(i, service);
            } else if (b === 136) {
              i = this.clearWindows(i, service);
            } else if (b === 140) {
              i = this.deleteWindows(i, service);
            } else if (b === 137) {
              i = this.displayWindows(i, service);
            } else if (b === 138) {
              i = this.hideWindows(i, service);
            } else if (b === 139) {
              i = this.toggleWindows(i, service);
            } else if (b === 151) {
              i = this.setWindowAttributes(i, service);
            } else if (b === 144) {
              i = this.setPenAttributes(i, service);
            } else if (b === 145) {
              i = this.setPenColor(i, service);
            } else if (b === 146) {
              i = this.setPenLocation(i, service);
            } else if (b === 143) {
              service = this.reset(i, service);
            } else if (b === 8) {
              service.currentWindow.backspace();
            } else if (b === 12) {
              service.currentWindow.clearText();
            } else if (b === 13) {
              service.currentWindow.pendingNewLine = true;
            } else if (b === 14) {
              service.currentWindow.clearText();
            } else if (b === 141) {
              i++;
            } else ;
          }
        };
        Cea708Stream.prototype.extendedCommands = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[++i];
          if (within708TextBlock(b)) {
            i = this.handleText(i, service, {
              isExtended: true
            });
          }
          return i;
        };
        Cea708Stream.prototype.getPts = function(byteIndex) {
          return this.current708Packet.ptsVals[Math.floor(byteIndex / 2)];
        };
        Cea708Stream.prototype.initService = function(serviceNum, i) {
          var serviceName = "SERVICE" + serviceNum;
          var self2 = this;
          var serviceName;
          var encoding;
          if (serviceName in this.serviceEncodings) {
            encoding = this.serviceEncodings[serviceName];
          }
          this.services[serviceNum] = new Cea708Service(serviceNum, encoding, self2);
          this.services[serviceNum].init(this.getPts(i), function(pts) {
            self2.flushDisplayed(pts, self2.services[serviceNum]);
          });
          return this.services[serviceNum];
        };
        Cea708Stream.prototype.handleText = function(i, service, options) {
          var isExtended = options && options.isExtended;
          var isMultiByte = options && options.isMultiByte;
          var packetData = this.current708Packet.data;
          var extended = isExtended ? 4096 : 0;
          var currentByte = packetData[i];
          var nextByte = packetData[i + 1];
          var win = service.currentWindow;
          var char;
          var charCodeArray;
          function toHexString2(byteArray) {
            return byteArray.map(function(byte) {
              return ("0" + (byte & 255).toString(16)).slice(-2);
            }).join("");
          }
          if (isMultiByte) {
            charCodeArray = [currentByte, nextByte];
            i++;
          } else {
            charCodeArray = [currentByte];
          }
          if (service.textDecoder_ && !isExtended) {
            char = service.textDecoder_.decode(new Uint8Array(charCodeArray));
          } else {
            if (isMultiByte) {
              var unicode = toHexString2(charCodeArray);
              char = String.fromCharCode(parseInt(unicode, 16));
            } else {
              char = get708CharFromCode(extended | currentByte);
            }
          }
          if (win.pendingNewLine && !win.isEmpty()) {
            win.newLine(this.getPts(i));
          }
          win.pendingNewLine = false;
          win.addText(char);
          return i;
        };
        Cea708Stream.prototype.multiByteCharacter = function(i, service) {
          var packetData = this.current708Packet.data;
          var firstByte = packetData[i + 1];
          var secondByte = packetData[i + 2];
          if (within708TextBlock(firstByte) && within708TextBlock(secondByte)) {
            i = this.handleText(++i, service, {
              isMultiByte: true
            });
          }
          return i;
        };
        Cea708Stream.prototype.setCurrentWindow = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[i];
          var windowNum = b & 7;
          service.setCurrentWindow(windowNum);
          return i;
        };
        Cea708Stream.prototype.defineWindow = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[i];
          var windowNum = b & 7;
          service.setCurrentWindow(windowNum);
          var win = service.currentWindow;
          b = packetData[++i];
          win.visible = (b & 32) >> 5;
          win.rowLock = (b & 16) >> 4;
          win.columnLock = (b & 8) >> 3;
          win.priority = b & 7;
          b = packetData[++i];
          win.relativePositioning = (b & 128) >> 7;
          win.anchorVertical = b & 127;
          b = packetData[++i];
          win.anchorHorizontal = b;
          b = packetData[++i];
          win.anchorPoint = (b & 240) >> 4;
          win.rowCount = b & 15;
          b = packetData[++i];
          win.columnCount = b & 63;
          b = packetData[++i];
          win.windowStyle = (b & 56) >> 3;
          win.penStyle = b & 7;
          win.virtualRowCount = win.rowCount + 1;
          return i;
        };
        Cea708Stream.prototype.setWindowAttributes = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[i];
          var winAttr = service.currentWindow.winAttr;
          b = packetData[++i];
          winAttr.fillOpacity = (b & 192) >> 6;
          winAttr.fillRed = (b & 48) >> 4;
          winAttr.fillGreen = (b & 12) >> 2;
          winAttr.fillBlue = b & 3;
          b = packetData[++i];
          winAttr.borderType = (b & 192) >> 6;
          winAttr.borderRed = (b & 48) >> 4;
          winAttr.borderGreen = (b & 12) >> 2;
          winAttr.borderBlue = b & 3;
          b = packetData[++i];
          winAttr.borderType += (b & 128) >> 5;
          winAttr.wordWrap = (b & 64) >> 6;
          winAttr.printDirection = (b & 48) >> 4;
          winAttr.scrollDirection = (b & 12) >> 2;
          winAttr.justify = b & 3;
          b = packetData[++i];
          winAttr.effectSpeed = (b & 240) >> 4;
          winAttr.effectDirection = (b & 12) >> 2;
          winAttr.displayEffect = b & 3;
          return i;
        };
        Cea708Stream.prototype.flushDisplayed = function(pts, service) {
          var displayedText = [];
          for (var winId = 0; winId < 8; winId++) {
            if (service.windows[winId].visible && !service.windows[winId].isEmpty()) {
              displayedText.push(service.windows[winId].getText());
            }
          }
          service.endPts = pts;
          service.text = displayedText.join("\n\n");
          this.pushCaption(service);
          service.startPts = pts;
        };
        Cea708Stream.prototype.pushCaption = function(service) {
          if (service.text !== "") {
            this.trigger("data", {
              startPts: service.startPts,
              endPts: service.endPts,
              text: service.text,
              stream: "cc708_" + service.serviceNum
            });
            service.text = "";
            service.startPts = service.endPts;
          }
        };
        Cea708Stream.prototype.displayWindows = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[++i];
          var pts = this.getPts(i);
          this.flushDisplayed(pts, service);
          for (var winId = 0; winId < 8; winId++) {
            if (b & 1 << winId) {
              service.windows[winId].visible = 1;
            }
          }
          return i;
        };
        Cea708Stream.prototype.hideWindows = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[++i];
          var pts = this.getPts(i);
          this.flushDisplayed(pts, service);
          for (var winId = 0; winId < 8; winId++) {
            if (b & 1 << winId) {
              service.windows[winId].visible = 0;
            }
          }
          return i;
        };
        Cea708Stream.prototype.toggleWindows = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[++i];
          var pts = this.getPts(i);
          this.flushDisplayed(pts, service);
          for (var winId = 0; winId < 8; winId++) {
            if (b & 1 << winId) {
              service.windows[winId].visible ^= 1;
            }
          }
          return i;
        };
        Cea708Stream.prototype.clearWindows = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[++i];
          var pts = this.getPts(i);
          this.flushDisplayed(pts, service);
          for (var winId = 0; winId < 8; winId++) {
            if (b & 1 << winId) {
              service.windows[winId].clearText();
            }
          }
          return i;
        };
        Cea708Stream.prototype.deleteWindows = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[++i];
          var pts = this.getPts(i);
          this.flushDisplayed(pts, service);
          for (var winId = 0; winId < 8; winId++) {
            if (b & 1 << winId) {
              service.windows[winId].reset();
            }
          }
          return i;
        };
        Cea708Stream.prototype.setPenAttributes = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[i];
          var penAttr = service.currentWindow.penAttr;
          b = packetData[++i];
          penAttr.textTag = (b & 240) >> 4;
          penAttr.offset = (b & 12) >> 2;
          penAttr.penSize = b & 3;
          b = packetData[++i];
          penAttr.italics = (b & 128) >> 7;
          penAttr.underline = (b & 64) >> 6;
          penAttr.edgeType = (b & 56) >> 3;
          penAttr.fontStyle = b & 7;
          return i;
        };
        Cea708Stream.prototype.setPenColor = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[i];
          var penColor = service.currentWindow.penColor;
          b = packetData[++i];
          penColor.fgOpacity = (b & 192) >> 6;
          penColor.fgRed = (b & 48) >> 4;
          penColor.fgGreen = (b & 12) >> 2;
          penColor.fgBlue = b & 3;
          b = packetData[++i];
          penColor.bgOpacity = (b & 192) >> 6;
          penColor.bgRed = (b & 48) >> 4;
          penColor.bgGreen = (b & 12) >> 2;
          penColor.bgBlue = b & 3;
          b = packetData[++i];
          penColor.edgeRed = (b & 48) >> 4;
          penColor.edgeGreen = (b & 12) >> 2;
          penColor.edgeBlue = b & 3;
          return i;
        };
        Cea708Stream.prototype.setPenLocation = function(i, service) {
          var packetData = this.current708Packet.data;
          var b = packetData[i];
          var penLoc = service.currentWindow.penLoc;
          service.currentWindow.pendingNewLine = true;
          b = packetData[++i];
          penLoc.row = b & 15;
          b = packetData[++i];
          penLoc.column = b & 63;
          return i;
        };
        Cea708Stream.prototype.reset = function(i, service) {
          var pts = this.getPts(i);
          this.flushDisplayed(pts, service);
          return this.initService(service.serviceNum, i);
        };
        var CHARACTER_TRANSLATION = {
          42: 225,
          // á
          92: 233,
          // é
          94: 237,
          // í
          95: 243,
          // ó
          96: 250,
          // ú
          123: 231,
          // ç
          124: 247,
          // ÷
          125: 209,
          // Ñ
          126: 241,
          // ñ
          127: 9608,
          // █
          304: 174,
          // ®
          305: 176,
          // °
          306: 189,
          // ½
          307: 191,
          // ¿
          308: 8482,
          // ™
          309: 162,
          // ¢
          310: 163,
          // £
          311: 9834,
          // ♪
          312: 224,
          // à
          313: 160,
          //
          314: 232,
          // è
          315: 226,
          // â
          316: 234,
          // ê
          317: 238,
          // î
          318: 244,
          // ô
          319: 251,
          // û
          544: 193,
          // Á
          545: 201,
          // É
          546: 211,
          // Ó
          547: 218,
          // Ú
          548: 220,
          // Ü
          549: 252,
          // ü
          550: 8216,
          // ‘
          551: 161,
          // ¡
          552: 42,
          // *
          553: 39,
          // '
          554: 8212,
          // —
          555: 169,
          // ©
          556: 8480,
          // ℠
          557: 8226,
          // •
          558: 8220,
          // “
          559: 8221,
          // ”
          560: 192,
          // À
          561: 194,
          // Â
          562: 199,
          // Ç
          563: 200,
          // È
          564: 202,
          // Ê
          565: 203,
          // Ë
          566: 235,
          // ë
          567: 206,
          // Î
          568: 207,
          // Ï
          569: 239,
          // ï
          570: 212,
          // Ô
          571: 217,
          // Ù
          572: 249,
          // ù
          573: 219,
          // Û
          574: 171,
          // «
          575: 187,
          // »
          800: 195,
          // Ã
          801: 227,
          // ã
          802: 205,
          // Í
          803: 204,
          // Ì
          804: 236,
          // ì
          805: 210,
          // Ò
          806: 242,
          // ò
          807: 213,
          // Õ
          808: 245,
          // õ
          809: 123,
          // {
          810: 125,
          // }
          811: 92,
          // \
          812: 94,
          // ^
          813: 95,
          // _
          814: 124,
          // |
          815: 126,
          // ~
          816: 196,
          // Ä
          817: 228,
          // ä
          818: 214,
          // Ö
          819: 246,
          // ö
          820: 223,
          // ß
          821: 165,
          // ¥
          822: 164,
          // ¤
          823: 9474,
          // │
          824: 197,
          // Å
          825: 229,
          // å
          826: 216,
          // Ø
          827: 248,
          // ø
          828: 9484,
          // ┌
          829: 9488,
          // ┐
          830: 9492,
          // └
          831: 9496
          // ┘
        };
        var getCharFromCode = function getCharFromCode2(code) {
          if (code === null) {
            return "";
          }
          code = CHARACTER_TRANSLATION[code] || code;
          return String.fromCharCode(code);
        };
        var BOTTOM_ROW = 14;
        var ROWS = [4352, 4384, 4608, 4640, 5376, 5408, 5632, 5664, 5888, 5920, 4096, 4864, 4896, 5120, 5152];
        var createDisplayBuffer = function createDisplayBuffer2() {
          var result = [], i = BOTTOM_ROW + 1;
          while (i--) {
            result.push({
              text: "",
              indent: 0,
              offset: 0
            });
          }
          return result;
        };
        var Cea608Stream = function Cea608Stream2(field, dataChannel) {
          Cea608Stream2.prototype.init.call(this);
          this.field_ = field || 0;
          this.dataChannel_ = dataChannel || 0;
          this.name_ = "CC" + ((this.field_ << 1 | this.dataChannel_) + 1);
          this.setConstants();
          this.reset();
          this.push = function(packet) {
            var data, swap, char0, char1, text;
            data = packet.ccData & 32639;
            if (data === this.lastControlCode_) {
              this.lastControlCode_ = null;
              return;
            }
            if ((data & 61440) === 4096) {
              this.lastControlCode_ = data;
            } else if (data !== this.PADDING_) {
              this.lastControlCode_ = null;
            }
            char0 = data >>> 8;
            char1 = data & 255;
            if (data === this.PADDING_) {
              return;
            } else if (data === this.RESUME_CAPTION_LOADING_) {
              this.mode_ = "popOn";
            } else if (data === this.END_OF_CAPTION_) {
              this.mode_ = "popOn";
              this.clearFormatting(packet.pts);
              this.flushDisplayed(packet.pts);
              swap = this.displayed_;
              this.displayed_ = this.nonDisplayed_;
              this.nonDisplayed_ = swap;
              this.startPts_ = packet.pts;
            } else if (data === this.ROLL_UP_2_ROWS_) {
              this.rollUpRows_ = 2;
              this.setRollUp(packet.pts);
            } else if (data === this.ROLL_UP_3_ROWS_) {
              this.rollUpRows_ = 3;
              this.setRollUp(packet.pts);
            } else if (data === this.ROLL_UP_4_ROWS_) {
              this.rollUpRows_ = 4;
              this.setRollUp(packet.pts);
            } else if (data === this.CARRIAGE_RETURN_) {
              this.clearFormatting(packet.pts);
              this.flushDisplayed(packet.pts);
              this.shiftRowsUp_();
              this.startPts_ = packet.pts;
            } else if (data === this.BACKSPACE_) {
              if (this.mode_ === "popOn") {
                this.nonDisplayed_[this.row_].text = this.nonDisplayed_[this.row_].text.slice(0, -1);
              } else {
                this.displayed_[this.row_].text = this.displayed_[this.row_].text.slice(0, -1);
              }
            } else if (data === this.ERASE_DISPLAYED_MEMORY_) {
              this.flushDisplayed(packet.pts);
              this.displayed_ = createDisplayBuffer();
            } else if (data === this.ERASE_NON_DISPLAYED_MEMORY_) {
              this.nonDisplayed_ = createDisplayBuffer();
            } else if (data === this.RESUME_DIRECT_CAPTIONING_) {
              if (this.mode_ !== "paintOn") {
                this.flushDisplayed(packet.pts);
                this.displayed_ = createDisplayBuffer();
              }
              this.mode_ = "paintOn";
              this.startPts_ = packet.pts;
            } else if (this.isSpecialCharacter(char0, char1)) {
              char0 = (char0 & 3) << 8;
              text = getCharFromCode(char0 | char1);
              this[this.mode_](packet.pts, text);
              this.column_++;
            } else if (this.isExtCharacter(char0, char1)) {
              if (this.mode_ === "popOn") {
                this.nonDisplayed_[this.row_].text = this.nonDisplayed_[this.row_].text.slice(0, -1);
              } else {
                this.displayed_[this.row_].text = this.displayed_[this.row_].text.slice(0, -1);
              }
              char0 = (char0 & 3) << 8;
              text = getCharFromCode(char0 | char1);
              this[this.mode_](packet.pts, text);
              this.column_++;
            } else if (this.isMidRowCode(char0, char1)) {
              this.clearFormatting(packet.pts);
              this[this.mode_](packet.pts, " ");
              this.column_++;
              if ((char1 & 14) === 14) {
                this.addFormatting(packet.pts, ["i"]);
              }
              if ((char1 & 1) === 1) {
                this.addFormatting(packet.pts, ["u"]);
              }
            } else if (this.isOffsetControlCode(char0, char1)) {
              var offset = char1 & 3;
              this.nonDisplayed_[this.row_].offset = offset;
              this.column_ += offset;
            } else if (this.isPAC(char0, char1)) {
              var row = ROWS.indexOf(data & 7968);
              if (this.mode_ === "rollUp") {
                if (row - this.rollUpRows_ + 1 < 0) {
                  row = this.rollUpRows_ - 1;
                }
                this.setRollUp(packet.pts, row);
              }
              if (row !== this.row_ && row >= 0 && row <= 14) {
                this.clearFormatting(packet.pts);
                this.row_ = row;
              }
              if (char1 & 1 && this.formatting_.indexOf("u") === -1) {
                this.addFormatting(packet.pts, ["u"]);
              }
              if ((data & 16) === 16) {
                var indentations = (data & 14) >> 1;
                this.column_ = indentations * 4;
                this.nonDisplayed_[this.row_].indent += indentations;
              }
              if (this.isColorPAC(char1)) {
                if ((char1 & 14) === 14) {
                  this.addFormatting(packet.pts, ["i"]);
                }
              }
            } else if (this.isNormalChar(char0)) {
              if (char1 === 0) {
                char1 = null;
              }
              text = getCharFromCode(char0);
              text += getCharFromCode(char1);
              this[this.mode_](packet.pts, text);
              this.column_ += text.length;
            }
          };
        };
        Cea608Stream.prototype = new Stream$a();
        Cea608Stream.prototype.flushDisplayed = function(pts) {
          var _this = this;
          var logWarning = function logWarning2(index) {
            _this.trigger("log", {
              level: "warn",
              message: "Skipping a malformed 608 caption at index " + index + "."
            });
          };
          var content = [];
          this.displayed_.forEach(function(row, i) {
            if (row && row.text && row.text.length) {
              try {
                row.text = row.text.trim();
              } catch (e) {
                logWarning(i);
              }
              if (row.text.length) {
                content.push({
                  // The text to be displayed in the caption from this specific row, with whitespace removed.
                  text: row.text,
                  // Value between 1 and 15 representing the PAC row used to calculate line height.
                  line: i + 1,
                  // A number representing the indent position by percentage (CEA-608 PAC indent code).
                  // The value will be a number between 10 and 80. Offset is used to add an aditional
                  // value to the position if necessary.
                  position: 10 + Math.min(70, row.indent * 10) + row.offset * 2.5
                });
              }
            } else if (row === void 0 || row === null) {
              logWarning(i);
            }
          });
          if (content.length) {
            this.trigger("data", {
              startPts: this.startPts_,
              endPts: pts,
              content,
              stream: this.name_
            });
          }
        };
        Cea608Stream.prototype.reset = function() {
          this.mode_ = "popOn";
          this.topRow_ = 0;
          this.startPts_ = 0;
          this.displayed_ = createDisplayBuffer();
          this.nonDisplayed_ = createDisplayBuffer();
          this.lastControlCode_ = null;
          this.column_ = 0;
          this.row_ = BOTTOM_ROW;
          this.rollUpRows_ = 2;
          this.formatting_ = [];
        };
        Cea608Stream.prototype.setConstants = function() {
          if (this.dataChannel_ === 0) {
            this.BASE_ = 16;
            this.EXT_ = 17;
            this.CONTROL_ = (20 | this.field_) << 8;
            this.OFFSET_ = 23;
          } else if (this.dataChannel_ === 1) {
            this.BASE_ = 24;
            this.EXT_ = 25;
            this.CONTROL_ = (28 | this.field_) << 8;
            this.OFFSET_ = 31;
          }
          this.PADDING_ = 0;
          this.RESUME_CAPTION_LOADING_ = this.CONTROL_ | 32;
          this.END_OF_CAPTION_ = this.CONTROL_ | 47;
          this.ROLL_UP_2_ROWS_ = this.CONTROL_ | 37;
          this.ROLL_UP_3_ROWS_ = this.CONTROL_ | 38;
          this.ROLL_UP_4_ROWS_ = this.CONTROL_ | 39;
          this.CARRIAGE_RETURN_ = this.CONTROL_ | 45;
          this.RESUME_DIRECT_CAPTIONING_ = this.CONTROL_ | 41;
          this.BACKSPACE_ = this.CONTROL_ | 33;
          this.ERASE_DISPLAYED_MEMORY_ = this.CONTROL_ | 44;
          this.ERASE_NON_DISPLAYED_MEMORY_ = this.CONTROL_ | 46;
        };
        Cea608Stream.prototype.isSpecialCharacter = function(char0, char1) {
          return char0 === this.EXT_ && char1 >= 48 && char1 <= 63;
        };
        Cea608Stream.prototype.isExtCharacter = function(char0, char1) {
          return (char0 === this.EXT_ + 1 || char0 === this.EXT_ + 2) && char1 >= 32 && char1 <= 63;
        };
        Cea608Stream.prototype.isMidRowCode = function(char0, char1) {
          return char0 === this.EXT_ && char1 >= 32 && char1 <= 47;
        };
        Cea608Stream.prototype.isOffsetControlCode = function(char0, char1) {
          return char0 === this.OFFSET_ && char1 >= 33 && char1 <= 35;
        };
        Cea608Stream.prototype.isPAC = function(char0, char1) {
          return char0 >= this.BASE_ && char0 < this.BASE_ + 8 && char1 >= 64 && char1 <= 127;
        };
        Cea608Stream.prototype.isColorPAC = function(char1) {
          return char1 >= 64 && char1 <= 79 || char1 >= 96 && char1 <= 127;
        };
        Cea608Stream.prototype.isNormalChar = function(char) {
          return char >= 32 && char <= 127;
        };
        Cea608Stream.prototype.setRollUp = function(pts, newBaseRow) {
          if (this.mode_ !== "rollUp") {
            this.row_ = BOTTOM_ROW;
            this.mode_ = "rollUp";
            this.flushDisplayed(pts);
            this.nonDisplayed_ = createDisplayBuffer();
            this.displayed_ = createDisplayBuffer();
          }
          if (newBaseRow !== void 0 && newBaseRow !== this.row_) {
            for (var i = 0; i < this.rollUpRows_; i++) {
              this.displayed_[newBaseRow - i] = this.displayed_[this.row_ - i];
              this.displayed_[this.row_ - i] = {
                text: "",
                indent: 0,
                offset: 0
              };
            }
          }
          if (newBaseRow === void 0) {
            newBaseRow = this.row_;
          }
          this.topRow_ = newBaseRow - this.rollUpRows_ + 1;
        };
        Cea608Stream.prototype.addFormatting = function(pts, format) {
          this.formatting_ = this.formatting_.concat(format);
          var text = format.reduce(function(text2, format2) {
            return text2 + "<" + format2 + ">";
          }, "");
          this[this.mode_](pts, text);
        };
        Cea608Stream.prototype.clearFormatting = function(pts) {
          if (!this.formatting_.length) {
            return;
          }
          var text = this.formatting_.reverse().reduce(function(text2, format) {
            return text2 + "</" + format + ">";
          }, "");
          this.formatting_ = [];
          this[this.mode_](pts, text);
        };
        Cea608Stream.prototype.popOn = function(pts, text) {
          var baseRow = this.nonDisplayed_[this.row_].text;
          baseRow += text;
          this.nonDisplayed_[this.row_].text = baseRow;
        };
        Cea608Stream.prototype.rollUp = function(pts, text) {
          var baseRow = this.displayed_[this.row_].text;
          baseRow += text;
          this.displayed_[this.row_].text = baseRow;
        };
        Cea608Stream.prototype.shiftRowsUp_ = function() {
          var i;
          for (i = 0; i < this.topRow_; i++) {
            this.displayed_[i] = {
              text: "",
              indent: 0,
              offset: 0
            };
          }
          for (i = this.row_ + 1; i < BOTTOM_ROW + 1; i++) {
            this.displayed_[i] = {
              text: "",
              indent: 0,
              offset: 0
            };
          }
          for (i = this.topRow_; i < this.row_; i++) {
            this.displayed_[i] = this.displayed_[i + 1];
          }
          this.displayed_[this.row_] = {
            text: "",
            indent: 0,
            offset: 0
          };
        };
        Cea608Stream.prototype.paintOn = function(pts, text) {
          var baseRow = this.displayed_[this.row_].text;
          baseRow += text;
          this.displayed_[this.row_].text = baseRow;
        };
        var captionStream = {
          CaptionStream: CaptionStream$2,
          Cea608Stream,
          Cea708Stream
        };
        var streamTypes = {
          H264_STREAM_TYPE: 27,
          ADTS_STREAM_TYPE: 15,
          METADATA_STREAM_TYPE: 21
        };
        var Stream$9 = stream;
        var MAX_TS = 8589934592;
        var RO_THRESH = 4294967296;
        var TYPE_SHARED = "shared";
        var handleRollover$1 = function handleRollover2(value, reference) {
          var direction = 1;
          if (value > reference) {
            direction = -1;
          }
          while (Math.abs(reference - value) > RO_THRESH) {
            value += direction * MAX_TS;
          }
          return value;
        };
        var TimestampRolloverStream$1 = function TimestampRolloverStream2(type2) {
          var lastDTS, referenceDTS;
          TimestampRolloverStream2.prototype.init.call(this);
          this.type_ = type2 || TYPE_SHARED;
          this.push = function(data) {
            if (data.type === "metadata") {
              this.trigger("data", data);
              return;
            }
            if (this.type_ !== TYPE_SHARED && data.type !== this.type_) {
              return;
            }
            if (referenceDTS === void 0) {
              referenceDTS = data.dts;
            }
            data.dts = handleRollover$1(data.dts, referenceDTS);
            data.pts = handleRollover$1(data.pts, referenceDTS);
            lastDTS = data.dts;
            this.trigger("data", data);
          };
          this.flush = function() {
            referenceDTS = lastDTS;
            this.trigger("done");
          };
          this.endTimeline = function() {
            this.flush();
            this.trigger("endedtimeline");
          };
          this.discontinuity = function() {
            referenceDTS = void 0;
            lastDTS = void 0;
          };
          this.reset = function() {
            this.discontinuity();
            this.trigger("reset");
          };
        };
        TimestampRolloverStream$1.prototype = new Stream$9();
        var timestampRolloverStream = {
          TimestampRolloverStream: TimestampRolloverStream$1,
          handleRollover: handleRollover$1
        };
        var Stream$8 = stream, StreamTypes$3 = streamTypes, id3 = parseId3, _MetadataStream;
        _MetadataStream = function MetadataStream(options) {
          var settings2 = {
            // the bytes of the program-level descriptor field in MP2T
            // see ISO/IEC 13818-1:2013 (E), section 2.6 "Program and
            // program element descriptors"
            descriptor: options && options.descriptor
          }, tagSize = 0, buffer = [], bufferSize = 0, i;
          _MetadataStream.prototype.init.call(this);
          this.dispatchType = StreamTypes$3.METADATA_STREAM_TYPE.toString(16);
          if (settings2.descriptor) {
            for (i = 0; i < settings2.descriptor.length; i++) {
              this.dispatchType += ("00" + settings2.descriptor[i].toString(16)).slice(-2);
            }
          }
          this.push = function(chunk) {
            var tag, frameStart, frameSize, frame, i2, frameHeader;
            if (chunk.type !== "timed-metadata") {
              return;
            }
            if (chunk.dataAlignmentIndicator) {
              bufferSize = 0;
              buffer.length = 0;
            }
            if (buffer.length === 0 && (chunk.data.length < 10 || chunk.data[0] !== "I".charCodeAt(0) || chunk.data[1] !== "D".charCodeAt(0) || chunk.data[2] !== "3".charCodeAt(0))) {
              this.trigger("log", {
                level: "warn",
                message: "Skipping unrecognized metadata packet"
              });
              return;
            }
            buffer.push(chunk);
            bufferSize += chunk.data.byteLength;
            if (buffer.length === 1) {
              tagSize = id3.parseSyncSafeInteger(chunk.data.subarray(6, 10));
              tagSize += 10;
            }
            if (bufferSize < tagSize) {
              return;
            }
            tag = {
              data: new Uint8Array(tagSize),
              frames: [],
              pts: buffer[0].pts,
              dts: buffer[0].dts
            };
            for (i2 = 0; i2 < tagSize; ) {
              tag.data.set(buffer[0].data.subarray(0, tagSize - i2), i2);
              i2 += buffer[0].data.byteLength;
              bufferSize -= buffer[0].data.byteLength;
              buffer.shift();
            }
            frameStart = 10;
            if (tag.data[5] & 64) {
              frameStart += 4;
              frameStart += id3.parseSyncSafeInteger(tag.data.subarray(10, 14));
              tagSize -= id3.parseSyncSafeInteger(tag.data.subarray(16, 20));
            }
            do {
              frameSize = id3.parseSyncSafeInteger(tag.data.subarray(frameStart + 4, frameStart + 8));
              if (frameSize < 1) {
                this.trigger("log", {
                  level: "warn",
                  message: "Malformed ID3 frame encountered. Skipping remaining metadata parsing."
                });
                break;
              }
              frameHeader = String.fromCharCode(tag.data[frameStart], tag.data[frameStart + 1], tag.data[frameStart + 2], tag.data[frameStart + 3]);
              frame = {
                id: frameHeader,
                data: tag.data.subarray(frameStart + 10, frameStart + frameSize + 10)
              };
              frame.key = frame.id;
              if (id3.frameParsers[frame.id]) {
                id3.frameParsers[frame.id](frame);
              } else if (frame.id[0] === "T") {
                id3.frameParsers["T*"](frame);
              } else if (frame.id[0] === "W") {
                id3.frameParsers["W*"](frame);
              }
              if (frame.owner === "com.apple.streaming.transportStreamTimestamp") {
                var d = frame.data, size = (d[3] & 1) << 30 | d[4] << 22 | d[5] << 14 | d[6] << 6 | d[7] >>> 2;
                size *= 4;
                size += d[7] & 3;
                frame.timeStamp = size;
                if (tag.pts === void 0 && tag.dts === void 0) {
                  tag.pts = frame.timeStamp;
                  tag.dts = frame.timeStamp;
                }
                this.trigger("timestamp", frame);
              }
              tag.frames.push(frame);
              frameStart += 10;
              frameStart += frameSize;
            } while (frameStart < tagSize);
            this.trigger("data", tag);
          };
        };
        _MetadataStream.prototype = new Stream$8();
        var metadataStream = _MetadataStream;
        var Stream$7 = stream, CaptionStream$1 = captionStream, StreamTypes$2 = streamTypes, TimestampRolloverStream = timestampRolloverStream.TimestampRolloverStream;
        var _TransportPacketStream, _TransportParseStream, _ElementaryStream;
        var MP2T_PACKET_LENGTH$1 = 188, SYNC_BYTE$1 = 71;
        _TransportPacketStream = function TransportPacketStream() {
          var buffer = new Uint8Array(MP2T_PACKET_LENGTH$1), bytesInBuffer = 0;
          _TransportPacketStream.prototype.init.call(this);
          this.push = function(bytes) {
            var startIndex = 0, endIndex = MP2T_PACKET_LENGTH$1, everything;
            if (bytesInBuffer) {
              everything = new Uint8Array(bytes.byteLength + bytesInBuffer);
              everything.set(buffer.subarray(0, bytesInBuffer));
              everything.set(bytes, bytesInBuffer);
              bytesInBuffer = 0;
            } else {
              everything = bytes;
            }
            while (endIndex < everything.byteLength) {
              if (everything[startIndex] === SYNC_BYTE$1 && everything[endIndex] === SYNC_BYTE$1) {
                this.trigger("data", everything.subarray(startIndex, endIndex));
                startIndex += MP2T_PACKET_LENGTH$1;
                endIndex += MP2T_PACKET_LENGTH$1;
                continue;
              }
              startIndex++;
              endIndex++;
            }
            if (startIndex < everything.byteLength) {
              buffer.set(everything.subarray(startIndex), 0);
              bytesInBuffer = everything.byteLength - startIndex;
            }
          };
          this.flush = function() {
            if (bytesInBuffer === MP2T_PACKET_LENGTH$1 && buffer[0] === SYNC_BYTE$1) {
              this.trigger("data", buffer);
              bytesInBuffer = 0;
            }
            this.trigger("done");
          };
          this.endTimeline = function() {
            this.flush();
            this.trigger("endedtimeline");
          };
          this.reset = function() {
            bytesInBuffer = 0;
            this.trigger("reset");
          };
        };
        _TransportPacketStream.prototype = new Stream$7();
        _TransportParseStream = function TransportParseStream() {
          var parsePsi, parsePat2, parsePmt2, self2;
          _TransportParseStream.prototype.init.call(this);
          self2 = this;
          this.packetsWaitingForPmt = [];
          this.programMapTable = void 0;
          parsePsi = function parsePsi2(payload, psi) {
            var offset = 0;
            if (psi.payloadUnitStartIndicator) {
              offset += payload[offset] + 1;
            }
            if (psi.type === "pat") {
              parsePat2(payload.subarray(offset), psi);
            } else {
              parsePmt2(payload.subarray(offset), psi);
            }
          };
          parsePat2 = function parsePat3(payload, pat) {
            pat.section_number = payload[7];
            pat.last_section_number = payload[8];
            self2.pmtPid = (payload[10] & 31) << 8 | payload[11];
            pat.pmtPid = self2.pmtPid;
          };
          parsePmt2 = function parsePmt3(payload, pmt) {
            var sectionLength, tableEnd, programInfoLength, offset;
            if (!(payload[5] & 1)) {
              return;
            }
            self2.programMapTable = {
              video: null,
              audio: null,
              "timed-metadata": {}
            };
            sectionLength = (payload[1] & 15) << 8 | payload[2];
            tableEnd = 3 + sectionLength - 4;
            programInfoLength = (payload[10] & 15) << 8 | payload[11];
            offset = 12 + programInfoLength;
            while (offset < tableEnd) {
              var streamType = payload[offset];
              var pid = (payload[offset + 1] & 31) << 8 | payload[offset + 2];
              if (streamType === StreamTypes$2.H264_STREAM_TYPE && self2.programMapTable.video === null) {
                self2.programMapTable.video = pid;
              } else if (streamType === StreamTypes$2.ADTS_STREAM_TYPE && self2.programMapTable.audio === null) {
                self2.programMapTable.audio = pid;
              } else if (streamType === StreamTypes$2.METADATA_STREAM_TYPE) {
                self2.programMapTable["timed-metadata"][pid] = streamType;
              }
              offset += ((payload[offset + 3] & 15) << 8 | payload[offset + 4]) + 5;
            }
            pmt.programMapTable = self2.programMapTable;
          };
          this.push = function(packet) {
            var result = {}, offset = 4;
            result.payloadUnitStartIndicator = !!(packet[1] & 64);
            result.pid = packet[1] & 31;
            result.pid <<= 8;
            result.pid |= packet[2];
            if ((packet[3] & 48) >>> 4 > 1) {
              offset += packet[offset] + 1;
            }
            if (result.pid === 0) {
              result.type = "pat";
              parsePsi(packet.subarray(offset), result);
              this.trigger("data", result);
            } else if (result.pid === this.pmtPid) {
              result.type = "pmt";
              parsePsi(packet.subarray(offset), result);
              this.trigger("data", result);
              while (this.packetsWaitingForPmt.length) {
                this.processPes_.apply(this, this.packetsWaitingForPmt.shift());
              }
            } else if (this.programMapTable === void 0) {
              this.packetsWaitingForPmt.push([packet, offset, result]);
            } else {
              this.processPes_(packet, offset, result);
            }
          };
          this.processPes_ = function(packet, offset, result) {
            if (result.pid === this.programMapTable.video) {
              result.streamType = StreamTypes$2.H264_STREAM_TYPE;
            } else if (result.pid === this.programMapTable.audio) {
              result.streamType = StreamTypes$2.ADTS_STREAM_TYPE;
            } else {
              result.streamType = this.programMapTable["timed-metadata"][result.pid];
            }
            result.type = "pes";
            result.data = packet.subarray(offset);
            this.trigger("data", result);
          };
        };
        _TransportParseStream.prototype = new Stream$7();
        _TransportParseStream.STREAM_TYPES = {
          h264: 27,
          adts: 15
        };
        _ElementaryStream = function ElementaryStream() {
          var self2 = this, segmentHadPmt = false, video = {
            data: [],
            size: 0
          }, audio = {
            data: [],
            size: 0
          }, timedMetadata = {
            data: [],
            size: 0
          }, programMapTable, parsePes = function parsePes2(payload, pes) {
            var ptsDtsFlags;
            var startPrefix = payload[0] << 16 | payload[1] << 8 | payload[2];
            pes.data = new Uint8Array();
            if (startPrefix !== 1) {
              return;
            }
            pes.packetLength = 6 + (payload[4] << 8 | payload[5]);
            pes.dataAlignmentIndicator = (payload[6] & 4) !== 0;
            ptsDtsFlags = payload[7];
            if (ptsDtsFlags & 192) {
              pes.pts = (payload[9] & 14) << 27 | (payload[10] & 255) << 20 | (payload[11] & 254) << 12 | (payload[12] & 255) << 5 | (payload[13] & 254) >>> 3;
              pes.pts *= 4;
              pes.pts += (payload[13] & 6) >>> 1;
              pes.dts = pes.pts;
              if (ptsDtsFlags & 64) {
                pes.dts = (payload[14] & 14) << 27 | (payload[15] & 255) << 20 | (payload[16] & 254) << 12 | (payload[17] & 255) << 5 | (payload[18] & 254) >>> 3;
                pes.dts *= 4;
                pes.dts += (payload[18] & 6) >>> 1;
              }
            }
            pes.data = payload.subarray(9 + payload[8]);
          }, flushStream = function flushStream2(stream2, type2, forceFlush) {
            var packetData = new Uint8Array(stream2.size), event = {
              type: type2
            }, i = 0, offset = 0, packetFlushable = false, fragment;
            if (!stream2.data.length || stream2.size < 9) {
              return;
            }
            event.trackId = stream2.data[0].pid;
            for (i = 0; i < stream2.data.length; i++) {
              fragment = stream2.data[i];
              packetData.set(fragment.data, offset);
              offset += fragment.data.byteLength;
            }
            parsePes(packetData, event);
            packetFlushable = type2 === "video" || event.packetLength <= stream2.size;
            if (forceFlush || packetFlushable) {
              stream2.size = 0;
              stream2.data.length = 0;
            }
            if (packetFlushable) {
              self2.trigger("data", event);
            }
          };
          _ElementaryStream.prototype.init.call(this);
          this.push = function(data) {
            ({
              pat: function pat() {
              },
              pes: function pes() {
                var stream2, streamType;
                switch (data.streamType) {
                  case StreamTypes$2.H264_STREAM_TYPE:
                    stream2 = video;
                    streamType = "video";
                    break;
                  case StreamTypes$2.ADTS_STREAM_TYPE:
                    stream2 = audio;
                    streamType = "audio";
                    break;
                  case StreamTypes$2.METADATA_STREAM_TYPE:
                    stream2 = timedMetadata;
                    streamType = "timed-metadata";
                    break;
                  default:
                    return;
                }
                if (data.payloadUnitStartIndicator) {
                  flushStream(stream2, streamType, true);
                }
                stream2.data.push(data);
                stream2.size += data.data.byteLength;
              },
              pmt: function pmt() {
                var event = {
                  type: "metadata",
                  tracks: []
                };
                programMapTable = data.programMapTable;
                if (programMapTable.video !== null) {
                  event.tracks.push({
                    timelineStartInfo: {
                      baseMediaDecodeTime: 0
                    },
                    id: +programMapTable.video,
                    codec: "avc",
                    type: "video"
                  });
                }
                if (programMapTable.audio !== null) {
                  event.tracks.push({
                    timelineStartInfo: {
                      baseMediaDecodeTime: 0
                    },
                    id: +programMapTable.audio,
                    codec: "adts",
                    type: "audio"
                  });
                }
                segmentHadPmt = true;
                self2.trigger("data", event);
              }
            })[data.type]();
          };
          this.reset = function() {
            video.size = 0;
            video.data.length = 0;
            audio.size = 0;
            audio.data.length = 0;
            this.trigger("reset");
          };
          this.flushStreams_ = function() {
            flushStream(video, "video");
            flushStream(audio, "audio");
            flushStream(timedMetadata, "timed-metadata");
          };
          this.flush = function() {
            if (!segmentHadPmt && programMapTable) {
              var pmt = {
                type: "metadata",
                tracks: []
              };
              if (programMapTable.video !== null) {
                pmt.tracks.push({
                  timelineStartInfo: {
                    baseMediaDecodeTime: 0
                  },
                  id: +programMapTable.video,
                  codec: "avc",
                  type: "video"
                });
              }
              if (programMapTable.audio !== null) {
                pmt.tracks.push({
                  timelineStartInfo: {
                    baseMediaDecodeTime: 0
                  },
                  id: +programMapTable.audio,
                  codec: "adts",
                  type: "audio"
                });
              }
              self2.trigger("data", pmt);
            }
            segmentHadPmt = false;
            this.flushStreams_();
            this.trigger("done");
          };
        };
        _ElementaryStream.prototype = new Stream$7();
        var m2ts$4 = {
          PAT_PID: 0,
          MP2T_PACKET_LENGTH: MP2T_PACKET_LENGTH$1,
          TransportPacketStream: _TransportPacketStream,
          TransportParseStream: _TransportParseStream,
          ElementaryStream: _ElementaryStream,
          TimestampRolloverStream,
          CaptionStream: CaptionStream$1.CaptionStream,
          Cea608Stream: CaptionStream$1.Cea608Stream,
          Cea708Stream: CaptionStream$1.Cea708Stream,
          MetadataStream: metadataStream
        };
        for (var type in StreamTypes$2) {
          if (StreamTypes$2.hasOwnProperty(type)) {
            m2ts$4[type] = StreamTypes$2[type];
          }
        }
        var m2ts_1 = m2ts$4;
        var ADTS_SAMPLING_FREQUENCIES = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350];
        var parseId3TagSize = function parseId3TagSize2(header, byteIndex) {
          var returnSize = header[byteIndex + 6] << 21 | header[byteIndex + 7] << 14 | header[byteIndex + 8] << 7 | header[byteIndex + 9], flags = header[byteIndex + 5], footerPresent = (flags & 16) >> 4;
          returnSize = returnSize >= 0 ? returnSize : 0;
          if (footerPresent) {
            return returnSize + 20;
          }
          return returnSize + 10;
        };
        var getId3Offset = function getId3Offset2(data, offset) {
          if (data.length - offset < 10 || data[offset] !== "I".charCodeAt(0) || data[offset + 1] !== "D".charCodeAt(0) || data[offset + 2] !== "3".charCodeAt(0)) {
            return offset;
          }
          offset += parseId3TagSize(data, offset);
          return getId3Offset2(data, offset);
        };
        var isLikelyAacData$2 = function isLikelyAacData2(data) {
          var offset = getId3Offset(data, 0);
          return data.length >= offset + 2 && (data[offset] & 255) === 255 && (data[offset + 1] & 240) === 240 && // verify that the 2 layer bits are 0, aka this
          // is not mp3 data but aac data.
          (data[offset + 1] & 22) === 16;
        };
        var parseSyncSafeInteger = function parseSyncSafeInteger2(data) {
          return data[0] << 21 | data[1] << 14 | data[2] << 7 | data[3];
        };
        var percentEncode = function percentEncode2(bytes, start, end) {
          var i, result = "";
          for (i = start; i < end; i++) {
            result += "%" + ("00" + bytes[i].toString(16)).slice(-2);
          }
          return result;
        };
        var parseIso88591 = function parseIso885912(bytes, start, end) {
          return unescape(percentEncode(bytes, start, end));
        };
        var parseAdtsSize = function parseAdtsSize2(header, byteIndex) {
          var lowThree = (header[byteIndex + 5] & 224) >> 5, middle = header[byteIndex + 4] << 3, highTwo = header[byteIndex + 3] & 3 << 11;
          return highTwo | middle | lowThree;
        };
        var parseType$2 = function parseType2(header, byteIndex) {
          if (header[byteIndex] === "I".charCodeAt(0) && header[byteIndex + 1] === "D".charCodeAt(0) && header[byteIndex + 2] === "3".charCodeAt(0)) {
            return "timed-metadata";
          } else if (header[byteIndex] & true && (header[byteIndex + 1] & 240) === 240) {
            return "audio";
          }
          return null;
        };
        var parseSampleRate = function parseSampleRate2(packet) {
          var i = 0;
          while (i + 5 < packet.length) {
            if (packet[i] !== 255 || (packet[i + 1] & 246) !== 240) {
              i++;
              continue;
            }
            return ADTS_SAMPLING_FREQUENCIES[(packet[i + 2] & 60) >>> 2];
          }
          return null;
        };
        var parseAacTimestamp = function parseAacTimestamp2(packet) {
          var frameStart, frameSize, frame, frameHeader;
          frameStart = 10;
          if (packet[5] & 64) {
            frameStart += 4;
            frameStart += parseSyncSafeInteger(packet.subarray(10, 14));
          }
          do {
            frameSize = parseSyncSafeInteger(packet.subarray(frameStart + 4, frameStart + 8));
            if (frameSize < 1) {
              return null;
            }
            frameHeader = String.fromCharCode(packet[frameStart], packet[frameStart + 1], packet[frameStart + 2], packet[frameStart + 3]);
            if (frameHeader === "PRIV") {
              frame = packet.subarray(frameStart + 10, frameStart + frameSize + 10);
              for (var i = 0; i < frame.byteLength; i++) {
                if (frame[i] === 0) {
                  var owner = parseIso88591(frame, 0, i);
                  if (owner === "com.apple.streaming.transportStreamTimestamp") {
                    var d = frame.subarray(i + 1);
                    var size = (d[3] & 1) << 30 | d[4] << 22 | d[5] << 14 | d[6] << 6 | d[7] >>> 2;
                    size *= 4;
                    size += d[7] & 3;
                    return size;
                  }
                  break;
                }
              }
            }
            frameStart += 10;
            frameStart += frameSize;
          } while (frameStart < packet.byteLength);
          return null;
        };
        var utils = {
          isLikelyAacData: isLikelyAacData$2,
          parseId3TagSize,
          parseAdtsSize,
          parseType: parseType$2,
          parseSampleRate,
          parseAacTimestamp
        };
        var Stream$6 = stream;
        var aacUtils = utils;
        var _AacStream;
        _AacStream = function AacStream2() {
          var everything = new Uint8Array(), timeStamp = 0;
          _AacStream.prototype.init.call(this);
          this.setTimestamp = function(timestamp) {
            timeStamp = timestamp;
          };
          this.push = function(bytes) {
            var frameSize = 0, byteIndex = 0, bytesLeft, chunk, packet, tempLength;
            if (everything.length) {
              tempLength = everything.length;
              everything = new Uint8Array(bytes.byteLength + tempLength);
              everything.set(everything.subarray(0, tempLength));
              everything.set(bytes, tempLength);
            } else {
              everything = bytes;
            }
            while (everything.length - byteIndex >= 3) {
              if (everything[byteIndex] === "I".charCodeAt(0) && everything[byteIndex + 1] === "D".charCodeAt(0) && everything[byteIndex + 2] === "3".charCodeAt(0)) {
                if (everything.length - byteIndex < 10) {
                  break;
                }
                frameSize = aacUtils.parseId3TagSize(everything, byteIndex);
                if (byteIndex + frameSize > everything.length) {
                  break;
                }
                chunk = {
                  type: "timed-metadata",
                  data: everything.subarray(byteIndex, byteIndex + frameSize)
                };
                this.trigger("data", chunk);
                byteIndex += frameSize;
                continue;
              } else if ((everything[byteIndex] & 255) === 255 && (everything[byteIndex + 1] & 240) === 240) {
                if (everything.length - byteIndex < 7) {
                  break;
                }
                frameSize = aacUtils.parseAdtsSize(everything, byteIndex);
                if (byteIndex + frameSize > everything.length) {
                  break;
                }
                packet = {
                  type: "audio",
                  data: everything.subarray(byteIndex, byteIndex + frameSize),
                  pts: timeStamp,
                  dts: timeStamp
                };
                this.trigger("data", packet);
                byteIndex += frameSize;
                continue;
              }
              byteIndex++;
            }
            bytesLeft = everything.length - byteIndex;
            if (bytesLeft > 0) {
              everything = everything.subarray(byteIndex);
            } else {
              everything = new Uint8Array();
            }
          };
          this.reset = function() {
            everything = new Uint8Array();
            this.trigger("reset");
          };
          this.endTimeline = function() {
            everything = new Uint8Array();
            this.trigger("endedtimeline");
          };
        };
        _AacStream.prototype = new Stream$6();
        var aac = _AacStream;
        var AUDIO_PROPERTIES$2 = ["audioobjecttype", "channelcount", "samplerate", "samplingfrequencyindex", "samplesize"];
        var audioProperties = AUDIO_PROPERTIES$2;
        var VIDEO_PROPERTIES$2 = ["width", "height", "profileIdc", "levelIdc", "profileCompatibility", "sarRatio"];
        var videoProperties = VIDEO_PROPERTIES$2;
        var Stream$5 = stream;
        var mp4$3 = mp4Generator;
        var frameUtils$1 = frameUtils$2;
        var audioFrameUtils$1 = audioFrameUtils$2;
        var trackDecodeInfo = trackDecodeInfo$1;
        var m2ts$3 = m2ts_1;
        var clock$1 = clock$3;
        var AdtsStream$2 = adts;
        var H264Stream$1 = h264.H264Stream;
        var AacStream$1 = aac;
        var isLikelyAacData$1 = utils.isLikelyAacData;
        var ONE_SECOND_IN_TS$2 = clock$3.ONE_SECOND_IN_TS;
        var AUDIO_PROPERTIES$1 = audioProperties;
        var VIDEO_PROPERTIES$1 = videoProperties;
        var _VideoSegmentStream$1, _AudioSegmentStream$1, _Transmuxer$1, _CoalesceStream;
        var retriggerForStream = function retriggerForStream2(key, event) {
          event.stream = key;
          this.trigger("log", event);
        };
        var addPipelineLogRetriggers = function addPipelineLogRetriggers2(transmuxer2, pipeline) {
          var keys = Object.keys(pipeline);
          for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            if (key === "headOfPipeline" || !pipeline[key].on) {
              continue;
            }
            pipeline[key].on("log", retriggerForStream.bind(transmuxer2, key));
          }
        };
        var arrayEquals = function arrayEquals2(a, b) {
          var i;
          if (a.length !== b.length) {
            return false;
          }
          for (i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) {
              return false;
            }
          }
          return true;
        };
        var generateSegmentTimingInfo = function generateSegmentTimingInfo2(baseMediaDecodeTime, startDts, startPts, endDts, endPts, prependedContentDuration) {
          var ptsOffsetFromDts = startPts - startDts, decodeDuration = endDts - startDts, presentationDuration = endPts - startPts;
          return {
            start: {
              dts: baseMediaDecodeTime,
              pts: baseMediaDecodeTime + ptsOffsetFromDts
            },
            end: {
              dts: baseMediaDecodeTime + decodeDuration,
              pts: baseMediaDecodeTime + presentationDuration
            },
            prependedContentDuration,
            baseMediaDecodeTime
          };
        };
        _AudioSegmentStream$1 = function AudioSegmentStream2(track, options) {
          var adtsFrames = [], sequenceNumber, earliestAllowedDts = 0, audioAppendStartTs = 0, videoBaseMediaDecodeTime = Infinity;
          options = options || {};
          sequenceNumber = options.firstSequenceNumber || 0;
          _AudioSegmentStream$1.prototype.init.call(this);
          this.push = function(data) {
            trackDecodeInfo.collectDtsInfo(track, data);
            if (track) {
              AUDIO_PROPERTIES$1.forEach(function(prop) {
                track[prop] = data[prop];
              });
            }
            adtsFrames.push(data);
          };
          this.setEarliestDts = function(earliestDts) {
            earliestAllowedDts = earliestDts;
          };
          this.setVideoBaseMediaDecodeTime = function(baseMediaDecodeTime) {
            videoBaseMediaDecodeTime = baseMediaDecodeTime;
          };
          this.setAudioAppendStart = function(timestamp) {
            audioAppendStartTs = timestamp;
          };
          this.flush = function() {
            var frames, moof2, mdat2, boxes2, frameDuration, segmentDuration, videoClockCyclesOfSilencePrefixed;
            if (adtsFrames.length === 0) {
              this.trigger("done", "AudioSegmentStream");
              return;
            }
            frames = audioFrameUtils$1.trimAdtsFramesByEarliestDts(adtsFrames, track, earliestAllowedDts);
            track.baseMediaDecodeTime = trackDecodeInfo.calculateTrackBaseMediaDecodeTime(track, options.keepOriginalTimestamps);
            videoClockCyclesOfSilencePrefixed = audioFrameUtils$1.prefixWithSilence(track, frames, audioAppendStartTs, videoBaseMediaDecodeTime);
            track.samples = audioFrameUtils$1.generateSampleTable(frames);
            mdat2 = mp4$3.mdat(audioFrameUtils$1.concatenateFrameData(frames));
            adtsFrames = [];
            moof2 = mp4$3.moof(sequenceNumber, [track]);
            boxes2 = new Uint8Array(moof2.byteLength + mdat2.byteLength);
            sequenceNumber++;
            boxes2.set(moof2);
            boxes2.set(mdat2, moof2.byteLength);
            trackDecodeInfo.clearDtsInfo(track);
            frameDuration = Math.ceil(ONE_SECOND_IN_TS$2 * 1024 / track.samplerate);
            if (frames.length) {
              segmentDuration = frames.length * frameDuration;
              this.trigger("segmentTimingInfo", generateSegmentTimingInfo(
                // The audio track's baseMediaDecodeTime is in audio clock cycles, but the
                // frame info is in video clock cycles. Convert to match expectation of
                // listeners (that all timestamps will be based on video clock cycles).
                clock$1.audioTsToVideoTs(track.baseMediaDecodeTime, track.samplerate),
                // frame times are already in video clock, as is segment duration
                frames[0].dts,
                frames[0].pts,
                frames[0].dts + segmentDuration,
                frames[0].pts + segmentDuration,
                videoClockCyclesOfSilencePrefixed || 0
              ));
              this.trigger("timingInfo", {
                start: frames[0].pts,
                end: frames[0].pts + segmentDuration
              });
            }
            this.trigger("data", {
              track,
              boxes: boxes2
            });
            this.trigger("done", "AudioSegmentStream");
          };
          this.reset = function() {
            trackDecodeInfo.clearDtsInfo(track);
            adtsFrames = [];
            this.trigger("reset");
          };
        };
        _AudioSegmentStream$1.prototype = new Stream$5();
        _VideoSegmentStream$1 = function VideoSegmentStream2(track, options) {
          var sequenceNumber, nalUnits = [], gopsToAlignWith = [], config, pps;
          options = options || {};
          sequenceNumber = options.firstSequenceNumber || 0;
          _VideoSegmentStream$1.prototype.init.call(this);
          delete track.minPTS;
          this.gopCache_ = [];
          this.push = function(nalUnit) {
            trackDecodeInfo.collectDtsInfo(track, nalUnit);
            if (nalUnit.nalUnitType === "seq_parameter_set_rbsp" && !config) {
              config = nalUnit.config;
              track.sps = [nalUnit.data];
              VIDEO_PROPERTIES$1.forEach(function(prop) {
                track[prop] = config[prop];
              }, this);
            }
            if (nalUnit.nalUnitType === "pic_parameter_set_rbsp" && !pps) {
              pps = nalUnit.data;
              track.pps = [nalUnit.data];
            }
            nalUnits.push(nalUnit);
          };
          this.flush = function() {
            var frames, gopForFusion, gops, moof2, mdat2, boxes2, prependedContentDuration = 0, firstGop, lastGop;
            while (nalUnits.length) {
              if (nalUnits[0].nalUnitType === "access_unit_delimiter_rbsp") {
                break;
              }
              nalUnits.shift();
            }
            if (nalUnits.length === 0) {
              this.resetStream_();
              this.trigger("done", "VideoSegmentStream");
              return;
            }
            frames = frameUtils$1.groupNalsIntoFrames(nalUnits);
            gops = frameUtils$1.groupFramesIntoGops(frames);
            if (!gops[0][0].keyFrame) {
              gopForFusion = this.getGopForFusion_(nalUnits[0], track);
              if (gopForFusion) {
                prependedContentDuration = gopForFusion.duration;
                gops.unshift(gopForFusion);
                gops.byteLength += gopForFusion.byteLength;
                gops.nalCount += gopForFusion.nalCount;
                gops.pts = gopForFusion.pts;
                gops.dts = gopForFusion.dts;
                gops.duration += gopForFusion.duration;
              } else {
                gops = frameUtils$1.extendFirstKeyFrame(gops);
              }
            }
            if (gopsToAlignWith.length) {
              var alignedGops;
              if (options.alignGopsAtEnd) {
                alignedGops = this.alignGopsAtEnd_(gops);
              } else {
                alignedGops = this.alignGopsAtStart_(gops);
              }
              if (!alignedGops) {
                this.gopCache_.unshift({
                  gop: gops.pop(),
                  pps: track.pps,
                  sps: track.sps
                });
                this.gopCache_.length = Math.min(6, this.gopCache_.length);
                nalUnits = [];
                this.resetStream_();
                this.trigger("done", "VideoSegmentStream");
                return;
              }
              trackDecodeInfo.clearDtsInfo(track);
              gops = alignedGops;
            }
            trackDecodeInfo.collectDtsInfo(track, gops);
            track.samples = frameUtils$1.generateSampleTable(gops);
            mdat2 = mp4$3.mdat(frameUtils$1.concatenateNalData(gops));
            track.baseMediaDecodeTime = trackDecodeInfo.calculateTrackBaseMediaDecodeTime(track, options.keepOriginalTimestamps);
            this.trigger("processedGopsInfo", gops.map(function(gop) {
              return {
                pts: gop.pts,
                dts: gop.dts,
                byteLength: gop.byteLength
              };
            }));
            firstGop = gops[0];
            lastGop = gops[gops.length - 1];
            this.trigger("segmentTimingInfo", generateSegmentTimingInfo(track.baseMediaDecodeTime, firstGop.dts, firstGop.pts, lastGop.dts + lastGop.duration, lastGop.pts + lastGop.duration, prependedContentDuration));
            this.trigger("timingInfo", {
              start: gops[0].pts,
              end: gops[gops.length - 1].pts + gops[gops.length - 1].duration
            });
            this.gopCache_.unshift({
              gop: gops.pop(),
              pps: track.pps,
              sps: track.sps
            });
            this.gopCache_.length = Math.min(6, this.gopCache_.length);
            nalUnits = [];
            this.trigger("baseMediaDecodeTime", track.baseMediaDecodeTime);
            this.trigger("timelineStartInfo", track.timelineStartInfo);
            moof2 = mp4$3.moof(sequenceNumber, [track]);
            boxes2 = new Uint8Array(moof2.byteLength + mdat2.byteLength);
            sequenceNumber++;
            boxes2.set(moof2);
            boxes2.set(mdat2, moof2.byteLength);
            this.trigger("data", {
              track,
              boxes: boxes2
            });
            this.resetStream_();
            this.trigger("done", "VideoSegmentStream");
          };
          this.reset = function() {
            this.resetStream_();
            nalUnits = [];
            this.gopCache_.length = 0;
            gopsToAlignWith.length = 0;
            this.trigger("reset");
          };
          this.resetStream_ = function() {
            trackDecodeInfo.clearDtsInfo(track);
            config = void 0;
            pps = void 0;
          };
          this.getGopForFusion_ = function(nalUnit) {
            var halfSecond = 45e3, allowableOverlap = 1e4, nearestDistance = Infinity, dtsDistance, nearestGopObj, currentGop, currentGopObj, i;
            for (i = 0; i < this.gopCache_.length; i++) {
              currentGopObj = this.gopCache_[i];
              currentGop = currentGopObj.gop;
              if (!(track.pps && arrayEquals(track.pps[0], currentGopObj.pps[0])) || !(track.sps && arrayEquals(track.sps[0], currentGopObj.sps[0]))) {
                continue;
              }
              if (currentGop.dts < track.timelineStartInfo.dts) {
                continue;
              }
              dtsDistance = nalUnit.dts - currentGop.dts - currentGop.duration;
              if (dtsDistance >= -allowableOverlap && dtsDistance <= halfSecond) {
                if (!nearestGopObj || nearestDistance > dtsDistance) {
                  nearestGopObj = currentGopObj;
                  nearestDistance = dtsDistance;
                }
              }
            }
            if (nearestGopObj) {
              return nearestGopObj.gop;
            }
            return null;
          };
          this.alignGopsAtStart_ = function(gops) {
            var alignIndex, gopIndex, align, gop, byteLength, nalCount, duration, alignedGops;
            byteLength = gops.byteLength;
            nalCount = gops.nalCount;
            duration = gops.duration;
            alignIndex = gopIndex = 0;
            while (alignIndex < gopsToAlignWith.length && gopIndex < gops.length) {
              align = gopsToAlignWith[alignIndex];
              gop = gops[gopIndex];
              if (align.pts === gop.pts) {
                break;
              }
              if (gop.pts > align.pts) {
                alignIndex++;
                continue;
              }
              gopIndex++;
              byteLength -= gop.byteLength;
              nalCount -= gop.nalCount;
              duration -= gop.duration;
            }
            if (gopIndex === 0) {
              return gops;
            }
            if (gopIndex === gops.length) {
              return null;
            }
            alignedGops = gops.slice(gopIndex);
            alignedGops.byteLength = byteLength;
            alignedGops.duration = duration;
            alignedGops.nalCount = nalCount;
            alignedGops.pts = alignedGops[0].pts;
            alignedGops.dts = alignedGops[0].dts;
            return alignedGops;
          };
          this.alignGopsAtEnd_ = function(gops) {
            var alignIndex, gopIndex, align, gop, alignEndIndex, matchFound;
            alignIndex = gopsToAlignWith.length - 1;
            gopIndex = gops.length - 1;
            alignEndIndex = null;
            matchFound = false;
            while (alignIndex >= 0 && gopIndex >= 0) {
              align = gopsToAlignWith[alignIndex];
              gop = gops[gopIndex];
              if (align.pts === gop.pts) {
                matchFound = true;
                break;
              }
              if (align.pts > gop.pts) {
                alignIndex--;
                continue;
              }
              if (alignIndex === gopsToAlignWith.length - 1) {
                alignEndIndex = gopIndex;
              }
              gopIndex--;
            }
            if (!matchFound && alignEndIndex === null) {
              return null;
            }
            var trimIndex;
            if (matchFound) {
              trimIndex = gopIndex;
            } else {
              trimIndex = alignEndIndex;
            }
            if (trimIndex === 0) {
              return gops;
            }
            var alignedGops = gops.slice(trimIndex);
            var metadata = alignedGops.reduce(function(total, gop2) {
              total.byteLength += gop2.byteLength;
              total.duration += gop2.duration;
              total.nalCount += gop2.nalCount;
              return total;
            }, {
              byteLength: 0,
              duration: 0,
              nalCount: 0
            });
            alignedGops.byteLength = metadata.byteLength;
            alignedGops.duration = metadata.duration;
            alignedGops.nalCount = metadata.nalCount;
            alignedGops.pts = alignedGops[0].pts;
            alignedGops.dts = alignedGops[0].dts;
            return alignedGops;
          };
          this.alignGopsWith = function(newGopsToAlignWith) {
            gopsToAlignWith = newGopsToAlignWith;
          };
        };
        _VideoSegmentStream$1.prototype = new Stream$5();
        _CoalesceStream = function CoalesceStream2(options, metadataStream2) {
          this.numberOfTracks = 0;
          this.metadataStream = metadataStream2;
          options = options || {};
          if (typeof options.remux !== "undefined") {
            this.remuxTracks = !!options.remux;
          } else {
            this.remuxTracks = true;
          }
          if (typeof options.keepOriginalTimestamps === "boolean") {
            this.keepOriginalTimestamps = options.keepOriginalTimestamps;
          } else {
            this.keepOriginalTimestamps = false;
          }
          this.pendingTracks = [];
          this.videoTrack = null;
          this.pendingBoxes = [];
          this.pendingCaptions = [];
          this.pendingMetadata = [];
          this.pendingBytes = 0;
          this.emittedTracks = 0;
          _CoalesceStream.prototype.init.call(this);
          this.push = function(output) {
            if (output.content || output.text) {
              return this.pendingCaptions.push(output);
            }
            if (output.frames) {
              return this.pendingMetadata.push(output);
            }
            this.pendingTracks.push(output.track);
            this.pendingBytes += output.boxes.byteLength;
            if (output.track.type === "video") {
              this.videoTrack = output.track;
              this.pendingBoxes.push(output.boxes);
            }
            if (output.track.type === "audio") {
              this.audioTrack = output.track;
              this.pendingBoxes.unshift(output.boxes);
            }
          };
        };
        _CoalesceStream.prototype = new Stream$5();
        _CoalesceStream.prototype.flush = function(flushSource) {
          var offset = 0, event = {
            captions: [],
            captionStreams: {},
            metadata: [],
            info: {}
          }, caption, id32, initSegment, timelineStartPts = 0, i;
          if (this.pendingTracks.length < this.numberOfTracks) {
            if (flushSource !== "VideoSegmentStream" && flushSource !== "AudioSegmentStream") {
              return;
            } else if (this.remuxTracks) {
              return;
            } else if (this.pendingTracks.length === 0) {
              this.emittedTracks++;
              if (this.emittedTracks >= this.numberOfTracks) {
                this.trigger("done");
                this.emittedTracks = 0;
              }
              return;
            }
          }
          if (this.videoTrack) {
            timelineStartPts = this.videoTrack.timelineStartInfo.pts;
            VIDEO_PROPERTIES$1.forEach(function(prop) {
              event.info[prop] = this.videoTrack[prop];
            }, this);
          } else if (this.audioTrack) {
            timelineStartPts = this.audioTrack.timelineStartInfo.pts;
            AUDIO_PROPERTIES$1.forEach(function(prop) {
              event.info[prop] = this.audioTrack[prop];
            }, this);
          }
          if (this.videoTrack || this.audioTrack) {
            if (this.pendingTracks.length === 1) {
              event.type = this.pendingTracks[0].type;
            } else {
              event.type = "combined";
            }
            this.emittedTracks += this.pendingTracks.length;
            initSegment = mp4$3.initSegment(this.pendingTracks);
            event.initSegment = new Uint8Array(initSegment.byteLength);
            event.initSegment.set(initSegment);
            event.data = new Uint8Array(this.pendingBytes);
            for (i = 0; i < this.pendingBoxes.length; i++) {
              event.data.set(this.pendingBoxes[i], offset);
              offset += this.pendingBoxes[i].byteLength;
            }
            for (i = 0; i < this.pendingCaptions.length; i++) {
              caption = this.pendingCaptions[i];
              caption.startTime = clock$1.metadataTsToSeconds(caption.startPts, timelineStartPts, this.keepOriginalTimestamps);
              caption.endTime = clock$1.metadataTsToSeconds(caption.endPts, timelineStartPts, this.keepOriginalTimestamps);
              event.captionStreams[caption.stream] = true;
              event.captions.push(caption);
            }
            for (i = 0; i < this.pendingMetadata.length; i++) {
              id32 = this.pendingMetadata[i];
              id32.cueTime = clock$1.metadataTsToSeconds(id32.pts, timelineStartPts, this.keepOriginalTimestamps);
              event.metadata.push(id32);
            }
            event.metadata.dispatchType = this.metadataStream.dispatchType;
            this.pendingTracks.length = 0;
            this.videoTrack = null;
            this.pendingBoxes.length = 0;
            this.pendingCaptions.length = 0;
            this.pendingBytes = 0;
            this.pendingMetadata.length = 0;
            this.trigger("data", event);
            for (i = 0; i < event.captions.length; i++) {
              caption = event.captions[i];
              this.trigger("caption", caption);
            }
            for (i = 0; i < event.metadata.length; i++) {
              id32 = event.metadata[i];
              this.trigger("id3Frame", id32);
            }
          }
          if (this.emittedTracks >= this.numberOfTracks) {
            this.trigger("done");
            this.emittedTracks = 0;
          }
        };
        _CoalesceStream.prototype.setRemux = function(val) {
          this.remuxTracks = val;
        };
        _Transmuxer$1 = function Transmuxer2(options) {
          var self2 = this, hasFlushed = true, videoTrack, audioTrack;
          _Transmuxer$1.prototype.init.call(this);
          options = options || {};
          this.baseMediaDecodeTime = options.baseMediaDecodeTime || 0;
          this.transmuxPipeline_ = {};
          this.setupAacPipeline = function() {
            var pipeline = {};
            this.transmuxPipeline_ = pipeline;
            pipeline.type = "aac";
            pipeline.metadataStream = new m2ts$3.MetadataStream();
            pipeline.aacStream = new AacStream$1();
            pipeline.audioTimestampRolloverStream = new m2ts$3.TimestampRolloverStream("audio");
            pipeline.timedMetadataTimestampRolloverStream = new m2ts$3.TimestampRolloverStream("timed-metadata");
            pipeline.adtsStream = new AdtsStream$2();
            pipeline.coalesceStream = new _CoalesceStream(options, pipeline.metadataStream);
            pipeline.headOfPipeline = pipeline.aacStream;
            pipeline.aacStream.pipe(pipeline.audioTimestampRolloverStream).pipe(pipeline.adtsStream);
            pipeline.aacStream.pipe(pipeline.timedMetadataTimestampRolloverStream).pipe(pipeline.metadataStream).pipe(pipeline.coalesceStream);
            pipeline.metadataStream.on("timestamp", function(frame) {
              pipeline.aacStream.setTimestamp(frame.timeStamp);
            });
            pipeline.aacStream.on("data", function(data) {
              if (data.type !== "timed-metadata" && data.type !== "audio" || pipeline.audioSegmentStream) {
                return;
              }
              audioTrack = audioTrack || {
                timelineStartInfo: {
                  baseMediaDecodeTime: self2.baseMediaDecodeTime
                },
                codec: "adts",
                type: "audio"
              };
              pipeline.coalesceStream.numberOfTracks++;
              pipeline.audioSegmentStream = new _AudioSegmentStream$1(audioTrack, options);
              pipeline.audioSegmentStream.on("log", self2.getLogTrigger_("audioSegmentStream"));
              pipeline.audioSegmentStream.on("timingInfo", self2.trigger.bind(self2, "audioTimingInfo"));
              pipeline.adtsStream.pipe(pipeline.audioSegmentStream).pipe(pipeline.coalesceStream);
              self2.trigger("trackinfo", {
                hasAudio: !!audioTrack,
                hasVideo: !!videoTrack
              });
            });
            pipeline.coalesceStream.on("data", this.trigger.bind(this, "data"));
            pipeline.coalesceStream.on("done", this.trigger.bind(this, "done"));
            addPipelineLogRetriggers(this, pipeline);
          };
          this.setupTsPipeline = function() {
            var pipeline = {};
            this.transmuxPipeline_ = pipeline;
            pipeline.type = "ts";
            pipeline.metadataStream = new m2ts$3.MetadataStream();
            pipeline.packetStream = new m2ts$3.TransportPacketStream();
            pipeline.parseStream = new m2ts$3.TransportParseStream();
            pipeline.elementaryStream = new m2ts$3.ElementaryStream();
            pipeline.timestampRolloverStream = new m2ts$3.TimestampRolloverStream();
            pipeline.adtsStream = new AdtsStream$2();
            pipeline.h264Stream = new H264Stream$1();
            pipeline.captionStream = new m2ts$3.CaptionStream(options);
            pipeline.coalesceStream = new _CoalesceStream(options, pipeline.metadataStream);
            pipeline.headOfPipeline = pipeline.packetStream;
            pipeline.packetStream.pipe(pipeline.parseStream).pipe(pipeline.elementaryStream).pipe(pipeline.timestampRolloverStream);
            pipeline.timestampRolloverStream.pipe(pipeline.h264Stream);
            pipeline.timestampRolloverStream.pipe(pipeline.adtsStream);
            pipeline.timestampRolloverStream.pipe(pipeline.metadataStream).pipe(pipeline.coalesceStream);
            pipeline.h264Stream.pipe(pipeline.captionStream).pipe(pipeline.coalesceStream);
            pipeline.elementaryStream.on("data", function(data) {
              var i;
              if (data.type === "metadata") {
                i = data.tracks.length;
                while (i--) {
                  if (!videoTrack && data.tracks[i].type === "video") {
                    videoTrack = data.tracks[i];
                    videoTrack.timelineStartInfo.baseMediaDecodeTime = self2.baseMediaDecodeTime;
                  } else if (!audioTrack && data.tracks[i].type === "audio") {
                    audioTrack = data.tracks[i];
                    audioTrack.timelineStartInfo.baseMediaDecodeTime = self2.baseMediaDecodeTime;
                  }
                }
                if (videoTrack && !pipeline.videoSegmentStream) {
                  pipeline.coalesceStream.numberOfTracks++;
                  pipeline.videoSegmentStream = new _VideoSegmentStream$1(videoTrack, options);
                  pipeline.videoSegmentStream.on("log", self2.getLogTrigger_("videoSegmentStream"));
                  pipeline.videoSegmentStream.on("timelineStartInfo", function(timelineStartInfo) {
                    if (audioTrack && !options.keepOriginalTimestamps) {
                      audioTrack.timelineStartInfo = timelineStartInfo;
                      pipeline.audioSegmentStream.setEarliestDts(timelineStartInfo.dts - self2.baseMediaDecodeTime);
                    }
                  });
                  pipeline.videoSegmentStream.on("processedGopsInfo", self2.trigger.bind(self2, "gopInfo"));
                  pipeline.videoSegmentStream.on("segmentTimingInfo", self2.trigger.bind(self2, "videoSegmentTimingInfo"));
                  pipeline.videoSegmentStream.on("baseMediaDecodeTime", function(baseMediaDecodeTime) {
                    if (audioTrack) {
                      pipeline.audioSegmentStream.setVideoBaseMediaDecodeTime(baseMediaDecodeTime);
                    }
                  });
                  pipeline.videoSegmentStream.on("timingInfo", self2.trigger.bind(self2, "videoTimingInfo"));
                  pipeline.h264Stream.pipe(pipeline.videoSegmentStream).pipe(pipeline.coalesceStream);
                }
                if (audioTrack && !pipeline.audioSegmentStream) {
                  pipeline.coalesceStream.numberOfTracks++;
                  pipeline.audioSegmentStream = new _AudioSegmentStream$1(audioTrack, options);
                  pipeline.audioSegmentStream.on("log", self2.getLogTrigger_("audioSegmentStream"));
                  pipeline.audioSegmentStream.on("timingInfo", self2.trigger.bind(self2, "audioTimingInfo"));
                  pipeline.audioSegmentStream.on("segmentTimingInfo", self2.trigger.bind(self2, "audioSegmentTimingInfo"));
                  pipeline.adtsStream.pipe(pipeline.audioSegmentStream).pipe(pipeline.coalesceStream);
                }
                self2.trigger("trackinfo", {
                  hasAudio: !!audioTrack,
                  hasVideo: !!videoTrack
                });
              }
            });
            pipeline.coalesceStream.on("data", this.trigger.bind(this, "data"));
            pipeline.coalesceStream.on("id3Frame", function(id3Frame) {
              id3Frame.dispatchType = pipeline.metadataStream.dispatchType;
              self2.trigger("id3Frame", id3Frame);
            });
            pipeline.coalesceStream.on("caption", this.trigger.bind(this, "caption"));
            pipeline.coalesceStream.on("done", this.trigger.bind(this, "done"));
            addPipelineLogRetriggers(this, pipeline);
          };
          this.setBaseMediaDecodeTime = function(baseMediaDecodeTime) {
            var pipeline = this.transmuxPipeline_;
            if (!options.keepOriginalTimestamps) {
              this.baseMediaDecodeTime = baseMediaDecodeTime;
            }
            if (audioTrack) {
              audioTrack.timelineStartInfo.dts = void 0;
              audioTrack.timelineStartInfo.pts = void 0;
              trackDecodeInfo.clearDtsInfo(audioTrack);
              if (pipeline.audioTimestampRolloverStream) {
                pipeline.audioTimestampRolloverStream.discontinuity();
              }
            }
            if (videoTrack) {
              if (pipeline.videoSegmentStream) {
                pipeline.videoSegmentStream.gopCache_ = [];
              }
              videoTrack.timelineStartInfo.dts = void 0;
              videoTrack.timelineStartInfo.pts = void 0;
              trackDecodeInfo.clearDtsInfo(videoTrack);
              pipeline.captionStream.reset();
            }
            if (pipeline.timestampRolloverStream) {
              pipeline.timestampRolloverStream.discontinuity();
            }
          };
          this.setAudioAppendStart = function(timestamp) {
            if (audioTrack) {
              this.transmuxPipeline_.audioSegmentStream.setAudioAppendStart(timestamp);
            }
          };
          this.setRemux = function(val) {
            var pipeline = this.transmuxPipeline_;
            options.remux = val;
            if (pipeline && pipeline.coalesceStream) {
              pipeline.coalesceStream.setRemux(val);
            }
          };
          this.alignGopsWith = function(gopsToAlignWith) {
            if (videoTrack && this.transmuxPipeline_.videoSegmentStream) {
              this.transmuxPipeline_.videoSegmentStream.alignGopsWith(gopsToAlignWith);
            }
          };
          this.getLogTrigger_ = function(key) {
            var self3 = this;
            return function(event) {
              event.stream = key;
              self3.trigger("log", event);
            };
          };
          this.push = function(data) {
            if (hasFlushed) {
              var isAac = isLikelyAacData$1(data);
              if (isAac && this.transmuxPipeline_.type !== "aac") {
                this.setupAacPipeline();
              } else if (!isAac && this.transmuxPipeline_.type !== "ts") {
                this.setupTsPipeline();
              }
              hasFlushed = false;
            }
            this.transmuxPipeline_.headOfPipeline.push(data);
          };
          this.flush = function() {
            hasFlushed = true;
            this.transmuxPipeline_.headOfPipeline.flush();
          };
          this.endTimeline = function() {
            this.transmuxPipeline_.headOfPipeline.endTimeline();
          };
          this.reset = function() {
            if (this.transmuxPipeline_.headOfPipeline) {
              this.transmuxPipeline_.headOfPipeline.reset();
            }
          };
          this.resetCaptions = function() {
            if (this.transmuxPipeline_.captionStream) {
              this.transmuxPipeline_.captionStream.reset();
            }
          };
        };
        _Transmuxer$1.prototype = new Stream$5();
        var transmuxer$2 = {
          Transmuxer: _Transmuxer$1,
          VideoSegmentStream: _VideoSegmentStream$1,
          AudioSegmentStream: _AudioSegmentStream$1,
          AUDIO_PROPERTIES: AUDIO_PROPERTIES$1,
          VIDEO_PROPERTIES: VIDEO_PROPERTIES$1,
          // exported for testing
          generateSegmentTimingInfo
        };
        var getUint64$1 = numbers.getUint64;
        var parseSidx = function parseSidx2(data) {
          var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
            version: data[0],
            flags: new Uint8Array(data.subarray(1, 4)),
            references: [],
            referenceId: view.getUint32(4),
            timescale: view.getUint32(8)
          }, i = 12;
          if (result.version === 0) {
            result.earliestPresentationTime = view.getUint32(i);
            result.firstOffset = view.getUint32(i + 4);
            i += 8;
          } else {
            result.earliestPresentationTime = getUint64$1(data.subarray(i));
            result.firstOffset = getUint64$1(data.subarray(i + 8));
            i += 16;
          }
          i += 2;
          var referenceCount = view.getUint16(i);
          i += 2;
          for (; referenceCount > 0; i += 12, referenceCount--) {
            result.references.push({
              referenceType: (data[i] & 128) >>> 7,
              referencedSize: view.getUint32(i) & 2147483647,
              subsegmentDuration: view.getUint32(i + 4),
              startsWithSap: !!(data[i + 8] & 128),
              sapType: (data[i + 8] & 112) >>> 4,
              sapDeltaTime: view.getUint32(i + 8) & 268435455
            });
          }
          return result;
        };
        var parseSidx_1 = parseSidx;
        var numberHelpers = numbers;
        var getUint64 = numberHelpers.getUint64;
        var inspectMp4, _textifyMp, parseMp4Date = function parseMp4Date2(seconds) {
          return new Date(seconds * 1e3 - 20828448e5);
        }, parseType$1 = parseType_1, findBox$3 = findBox_1, nalParse = function nalParse2(avcStream) {
          var avcView = new DataView(avcStream.buffer, avcStream.byteOffset, avcStream.byteLength), result = [], i, length;
          for (i = 0; i + 4 < avcStream.length; i += length) {
            length = avcView.getUint32(i);
            i += 4;
            if (length <= 0) {
              result.push("<span style='color:red;'>MALFORMED DATA</span>");
              continue;
            }
            switch (avcStream[i] & 31) {
              case 1:
                result.push("slice_layer_without_partitioning_rbsp");
                break;
              case 5:
                result.push("slice_layer_without_partitioning_rbsp_idr");
                break;
              case 6:
                result.push("sei_rbsp");
                break;
              case 7:
                result.push("seq_parameter_set_rbsp");
                break;
              case 8:
                result.push("pic_parameter_set_rbsp");
                break;
              case 9:
                result.push("access_unit_delimiter_rbsp");
                break;
              default:
                result.push("UNKNOWN NAL - " + avcStream[i] & 31);
                break;
            }
          }
          return result;
        }, parse = {
          // codingname, not a first-class box type. stsd entries share the
          // same format as real boxes so the parsing infrastructure can be
          // shared
          avc1: function avc1(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength);
            return {
              dataReferenceIndex: view.getUint16(6),
              width: view.getUint16(24),
              height: view.getUint16(26),
              horizresolution: view.getUint16(28) + view.getUint16(30) / 16,
              vertresolution: view.getUint16(32) + view.getUint16(34) / 16,
              frameCount: view.getUint16(40),
              depth: view.getUint16(74),
              config: inspectMp4(data.subarray(78, data.byteLength))
            };
          },
          avcC: function avcC(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              configurationVersion: data[0],
              avcProfileIndication: data[1],
              profileCompatibility: data[2],
              avcLevelIndication: data[3],
              lengthSizeMinusOne: data[4] & 3,
              sps: [],
              pps: []
            }, numOfSequenceParameterSets = data[5] & 31, numOfPictureParameterSets, nalSize, offset, i;
            offset = 6;
            for (i = 0; i < numOfSequenceParameterSets; i++) {
              nalSize = view.getUint16(offset);
              offset += 2;
              result.sps.push(new Uint8Array(data.subarray(offset, offset + nalSize)));
              offset += nalSize;
            }
            numOfPictureParameterSets = data[offset];
            offset++;
            for (i = 0; i < numOfPictureParameterSets; i++) {
              nalSize = view.getUint16(offset);
              offset += 2;
              result.pps.push(new Uint8Array(data.subarray(offset, offset + nalSize)));
              offset += nalSize;
            }
            return result;
          },
          btrt: function btrt(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength);
            return {
              bufferSizeDB: view.getUint32(0),
              maxBitrate: view.getUint32(4),
              avgBitrate: view.getUint32(8)
            };
          },
          edts: function edts(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          elst: function elst(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4)),
              edits: []
            }, entryCount = view.getUint32(4), i;
            for (i = 8; entryCount; entryCount--) {
              if (result.version === 0) {
                result.edits.push({
                  segmentDuration: view.getUint32(i),
                  mediaTime: view.getInt32(i + 4),
                  mediaRate: view.getUint16(i + 8) + view.getUint16(i + 10) / (256 * 256)
                });
                i += 12;
              } else {
                result.edits.push({
                  segmentDuration: getUint64(data.subarray(i)),
                  mediaTime: getUint64(data.subarray(i + 8)),
                  mediaRate: view.getUint16(i + 16) + view.getUint16(i + 18) / (256 * 256)
                });
                i += 20;
              }
            }
            return result;
          },
          esds: function esds2(data) {
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              esId: data[6] << 8 | data[7],
              streamPriority: data[8] & 31,
              decoderConfig: {
                objectProfileIndication: data[11],
                streamType: data[12] >>> 2 & 63,
                bufferSize: data[13] << 16 | data[14] << 8 | data[15],
                maxBitrate: data[16] << 24 | data[17] << 16 | data[18] << 8 | data[19],
                avgBitrate: data[20] << 24 | data[21] << 16 | data[22] << 8 | data[23],
                decoderConfigDescriptor: {
                  tag: data[24],
                  length: data[25],
                  audioObjectType: data[26] >>> 3 & 31,
                  samplingFrequencyIndex: (data[26] & 7) << 1 | data[27] >>> 7 & 1,
                  channelConfiguration: data[27] >>> 3 & 15
                }
              }
            };
          },
          ftyp: function ftyp2(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              majorBrand: parseType$1(data.subarray(0, 4)),
              minorVersion: view.getUint32(4),
              compatibleBrands: []
            }, i = 8;
            while (i < data.byteLength) {
              result.compatibleBrands.push(parseType$1(data.subarray(i, i + 4)));
              i += 4;
            }
            return result;
          },
          dinf: function dinf2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          dref: function dref(data) {
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              dataReferences: inspectMp4(data.subarray(8))
            };
          },
          hdlr: function hdlr2(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4)),
              handlerType: parseType$1(data.subarray(8, 12)),
              name: ""
            }, i = 8;
            for (i = 24; i < data.byteLength; i++) {
              if (data[i] === 0) {
                i++;
                break;
              }
              result.name += String.fromCharCode(data[i]);
            }
            result.name = decodeURIComponent(escape(result.name));
            return result;
          },
          mdat: function mdat2(data) {
            return {
              byteLength: data.byteLength,
              nals: nalParse(data)
            };
          },
          mdhd: function mdhd2(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), i = 4, language, result = {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4)),
              language: ""
            };
            if (result.version === 1) {
              i += 4;
              result.creationTime = parseMp4Date(view.getUint32(i));
              i += 8;
              result.modificationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.timescale = view.getUint32(i);
              i += 8;
              result.duration = view.getUint32(i);
            } else {
              result.creationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.modificationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.timescale = view.getUint32(i);
              i += 4;
              result.duration = view.getUint32(i);
            }
            i += 4;
            language = view.getUint16(i);
            result.language += String.fromCharCode((language >> 10) + 96);
            result.language += String.fromCharCode(((language & 992) >> 5) + 96);
            result.language += String.fromCharCode((language & 31) + 96);
            return result;
          },
          mdia: function mdia2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          mfhd: function mfhd2(data) {
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              sequenceNumber: data[4] << 24 | data[5] << 16 | data[6] << 8 | data[7]
            };
          },
          minf: function minf2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          // codingname, not a first-class box type. stsd entries share the
          // same format as real boxes so the parsing infrastructure can be
          // shared
          mp4a: function mp4a(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              // 6 bytes reserved
              dataReferenceIndex: view.getUint16(6),
              // 4 + 4 bytes reserved
              channelcount: view.getUint16(16),
              samplesize: view.getUint16(18),
              // 2 bytes pre_defined
              // 2 bytes reserved
              samplerate: view.getUint16(24) + view.getUint16(26) / 65536
            };
            if (data.byteLength > 28) {
              result.streamDescriptor = inspectMp4(data.subarray(28))[0];
            }
            return result;
          },
          moof: function moof2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          moov: function moov2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          mvex: function mvex2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          mvhd: function mvhd2(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), i = 4, result = {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4))
            };
            if (result.version === 1) {
              i += 4;
              result.creationTime = parseMp4Date(view.getUint32(i));
              i += 8;
              result.modificationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.timescale = view.getUint32(i);
              i += 8;
              result.duration = view.getUint32(i);
            } else {
              result.creationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.modificationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.timescale = view.getUint32(i);
              i += 4;
              result.duration = view.getUint32(i);
            }
            i += 4;
            result.rate = view.getUint16(i) + view.getUint16(i + 2) / 16;
            i += 4;
            result.volume = view.getUint8(i) + view.getUint8(i + 1) / 8;
            i += 2;
            i += 2;
            i += 2 * 4;
            result.matrix = new Uint32Array(data.subarray(i, i + 9 * 4));
            i += 9 * 4;
            i += 6 * 4;
            result.nextTrackId = view.getUint32(i);
            return result;
          },
          pdin: function pdin(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength);
            return {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4)),
              rate: view.getUint32(4),
              initialDelay: view.getUint32(8)
            };
          },
          sdtp: function sdtp2(data) {
            var result = {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              samples: []
            }, i;
            for (i = 4; i < data.byteLength; i++) {
              result.samples.push({
                dependsOn: (data[i] & 48) >> 4,
                isDependedOn: (data[i] & 12) >> 2,
                hasRedundancy: data[i] & 3
              });
            }
            return result;
          },
          sidx: parseSidx_1,
          smhd: function smhd(data) {
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              balance: data[4] + data[5] / 256
            };
          },
          stbl: function stbl2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          ctts: function ctts(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4)),
              compositionOffsets: []
            }, entryCount = view.getUint32(4), i;
            for (i = 8; entryCount; i += 8, entryCount--) {
              result.compositionOffsets.push({
                sampleCount: view.getUint32(i),
                sampleOffset: view[result.version === 0 ? "getUint32" : "getInt32"](i + 4)
              });
            }
            return result;
          },
          stss: function stss(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4)),
              syncSamples: []
            }, entryCount = view.getUint32(4), i;
            for (i = 8; entryCount; i += 4, entryCount--) {
              result.syncSamples.push(view.getUint32(i));
            }
            return result;
          },
          stco: function stco(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              chunkOffsets: []
            }, entryCount = view.getUint32(4), i;
            for (i = 8; entryCount; i += 4, entryCount--) {
              result.chunkOffsets.push(view.getUint32(i));
            }
            return result;
          },
          stsc: function stsc(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), entryCount = view.getUint32(4), result = {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              sampleToChunks: []
            }, i;
            for (i = 8; entryCount; i += 12, entryCount--) {
              result.sampleToChunks.push({
                firstChunk: view.getUint32(i),
                samplesPerChunk: view.getUint32(i + 4),
                sampleDescriptionIndex: view.getUint32(i + 8)
              });
            }
            return result;
          },
          stsd: function stsd2(data) {
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              sampleDescriptions: inspectMp4(data.subarray(8))
            };
          },
          stsz: function stsz(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              sampleSize: view.getUint32(4),
              entries: []
            }, i;
            for (i = 12; i < data.byteLength; i += 4) {
              result.entries.push(view.getUint32(i));
            }
            return result;
          },
          stts: function stts(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), result = {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              timeToSamples: []
            }, entryCount = view.getUint32(4), i;
            for (i = 8; entryCount; i += 8, entryCount--) {
              result.timeToSamples.push({
                sampleCount: view.getUint32(i),
                sampleDelta: view.getUint32(i + 4)
              });
            }
            return result;
          },
          styp: function styp(data) {
            return parse.ftyp(data);
          },
          tfdt: parseTfdt$3,
          tfhd: parseTfhd$2,
          tkhd: function tkhd2(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength), i = 4, result = {
              version: view.getUint8(0),
              flags: new Uint8Array(data.subarray(1, 4))
            };
            if (result.version === 1) {
              i += 4;
              result.creationTime = parseMp4Date(view.getUint32(i));
              i += 8;
              result.modificationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.trackId = view.getUint32(i);
              i += 4;
              i += 8;
              result.duration = view.getUint32(i);
            } else {
              result.creationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.modificationTime = parseMp4Date(view.getUint32(i));
              i += 4;
              result.trackId = view.getUint32(i);
              i += 4;
              i += 4;
              result.duration = view.getUint32(i);
            }
            i += 4;
            i += 2 * 4;
            result.layer = view.getUint16(i);
            i += 2;
            result.alternateGroup = view.getUint16(i);
            i += 2;
            result.volume = view.getUint8(i) + view.getUint8(i + 1) / 8;
            i += 2;
            i += 2;
            result.matrix = new Uint32Array(data.subarray(i, i + 9 * 4));
            i += 9 * 4;
            result.width = view.getUint16(i) + view.getUint16(i + 2) / 65536;
            i += 4;
            result.height = view.getUint16(i) + view.getUint16(i + 2) / 65536;
            return result;
          },
          traf: function traf2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          trak: function trak2(data) {
            return {
              boxes: inspectMp4(data)
            };
          },
          trex: function trex2(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength);
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              trackId: view.getUint32(4),
              defaultSampleDescriptionIndex: view.getUint32(8),
              defaultSampleDuration: view.getUint32(12),
              defaultSampleSize: view.getUint32(16),
              sampleDependsOn: data[20] & 3,
              sampleIsDependedOn: (data[21] & 192) >> 6,
              sampleHasRedundancy: (data[21] & 48) >> 4,
              samplePaddingValue: (data[21] & 14) >> 1,
              sampleIsDifferenceSample: !!(data[21] & 1),
              sampleDegradationPriority: view.getUint16(22)
            };
          },
          trun: parseTrun$2,
          "url ": function url(data) {
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4))
            };
          },
          vmhd: function vmhd(data) {
            var view = new DataView(data.buffer, data.byteOffset, data.byteLength);
            return {
              version: data[0],
              flags: new Uint8Array(data.subarray(1, 4)),
              graphicsmode: view.getUint16(4),
              opcolor: new Uint16Array([view.getUint16(6), view.getUint16(8), view.getUint16(10)])
            };
          }
        };
        inspectMp4 = function inspectMp42(data) {
          var i = 0, result = [], view, size, type2, end, box3;
          var ab = new ArrayBuffer(data.length);
          var v = new Uint8Array(ab);
          for (var z = 0; z < data.length; ++z) {
            v[z] = data[z];
          }
          view = new DataView(ab);
          while (i < data.byteLength) {
            size = view.getUint32(i);
            type2 = parseType$1(data.subarray(i + 4, i + 8));
            end = size > 1 ? i + size : data.byteLength;
            box3 = (parse[type2] || function(data2) {
              return {
                data: data2
              };
            })(data.subarray(i + 8, end));
            box3.size = size;
            box3.type = type2;
            result.push(box3);
            i = end;
          }
          return result;
        };
        _textifyMp = function textifyMp4(inspectedMp4, depth) {
          var indent;
          depth = depth || 0;
          indent = new Array(depth * 2 + 1).join(" ");
          return inspectedMp4.map(function(box3, index) {
            return indent + box3.type + "\n" + // the type is already included and handle child boxes separately
            Object.keys(box3).filter(function(key) {
              return key !== "type" && key !== "boxes";
            }).map(function(key) {
              var prefix = indent + "  " + key + ": ", value = box3[key];
              if (value instanceof Uint8Array || value instanceof Uint32Array) {
                var bytes = Array.prototype.slice.call(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)).map(function(byte) {
                  return " " + ("00" + byte.toString(16)).slice(-2);
                }).join("").match(/.{1,24}/g);
                if (!bytes) {
                  return prefix + "<>";
                }
                if (bytes.length === 1) {
                  return prefix + "<" + bytes.join("").slice(1) + ">";
                }
                return prefix + "<\n" + bytes.map(function(line) {
                  return indent + "  " + line;
                }).join("\n") + "\n" + indent + "  >";
              }
              return prefix + JSON.stringify(value, null, 2).split("\n").map(function(line, index2) {
                if (index2 === 0) {
                  return line;
                }
                return indent + "  " + line;
              }).join("\n");
            }).join("\n") + // recursively textify the child boxes
            (box3.boxes ? "\n" + _textifyMp(box3.boxes, depth + 1) : "");
          }).join("\n");
        };
        var mp4Inspector = {
          inspect: inspectMp4,
          textify: _textifyMp,
          parseType: parseType$1,
          findBox: findBox$3,
          parseTraf: parse.traf,
          parseTfdt: parse.tfdt,
          parseHdlr: parse.hdlr,
          parseTfhd: parse.tfhd,
          parseTrun: parse.trun,
          parseSidx: parse.sidx
        };
        var parseTrun = mp4Inspector.parseTrun;
        var findBox$2 = probe$2.findBox;
        var window2 = require$$8__default["default"];
        var getMdatTrafPairs$2 = function getMdatTrafPairs2(segment) {
          var trafs = findBox$2(segment, ["moof", "traf"]);
          var mdats = findBox$2(segment, ["mdat"]);
          var mdatTrafPairs = [];
          mdats.forEach(function(mdat2, index) {
            var matchingTraf = trafs[index];
            mdatTrafPairs.push({
              mdat: mdat2,
              traf: matchingTraf
            });
          });
          return mdatTrafPairs;
        };
        var parseSamples$2 = function parseSamples2(truns, baseMediaDecodeTime, tfhd2) {
          var currentDts = baseMediaDecodeTime;
          var defaultSampleDuration = tfhd2.defaultSampleDuration || 0;
          var defaultSampleSize = tfhd2.defaultSampleSize || 0;
          var trackId = tfhd2.trackId;
          var allSamples = [];
          truns.forEach(function(trun2) {
            var trackRun = parseTrun(trun2);
            var samples2 = trackRun.samples;
            samples2.forEach(function(sample) {
              if (sample.duration === void 0) {
                sample.duration = defaultSampleDuration;
              }
              if (sample.size === void 0) {
                sample.size = defaultSampleSize;
              }
              sample.trackId = trackId;
              sample.dts = currentDts;
              if (sample.compositionTimeOffset === void 0) {
                sample.compositionTimeOffset = 0;
              }
              if (typeof currentDts === "bigint") {
                sample.pts = currentDts + window2.BigInt(sample.compositionTimeOffset);
                currentDts += window2.BigInt(sample.duration);
              } else {
                sample.pts = currentDts + sample.compositionTimeOffset;
                currentDts += sample.duration;
              }
            });
            allSamples = allSamples.concat(samples2);
          });
          return allSamples;
        };
        var samples = {
          getMdatTrafPairs: getMdatTrafPairs$2,
          parseSamples: parseSamples$2
        };
        var discardEmulationPreventionBytes = captionPacketParser.discardEmulationPreventionBytes;
        var CaptionStream = captionStream.CaptionStream;
        var findBox$1 = findBox_1;
        var parseTfdt$1 = parseTfdt$3;
        var parseTfhd = parseTfhd$2;
        var getMdatTrafPairs$1 = samples.getMdatTrafPairs, parseSamples$1 = samples.parseSamples;
        var mapToSample = function mapToSample2(offset, samples2) {
          var approximateOffset = offset;
          for (var i = 0; i < samples2.length; i++) {
            var sample = samples2[i];
            if (approximateOffset < sample.size) {
              return sample;
            }
            approximateOffset -= sample.size;
          }
          return null;
        };
        var findSeiNals = function findSeiNals2(avcStream, samples2, trackId) {
          var avcView = new DataView(avcStream.buffer, avcStream.byteOffset, avcStream.byteLength), result = {
            logs: [],
            seiNals: []
          }, seiNal, i, length, lastMatchedSample;
          for (i = 0; i + 4 < avcStream.length; i += length) {
            length = avcView.getUint32(i);
            i += 4;
            if (length <= 0) {
              continue;
            }
            switch (avcStream[i] & 31) {
              case 6:
                var data = avcStream.subarray(i + 1, i + 1 + length);
                var matchingSample = mapToSample(i, samples2);
                seiNal = {
                  nalUnitType: "sei_rbsp",
                  size: length,
                  data,
                  escapedRBSP: discardEmulationPreventionBytes(data),
                  trackId
                };
                if (matchingSample) {
                  seiNal.pts = matchingSample.pts;
                  seiNal.dts = matchingSample.dts;
                  lastMatchedSample = matchingSample;
                } else if (lastMatchedSample) {
                  seiNal.pts = lastMatchedSample.pts;
                  seiNal.dts = lastMatchedSample.dts;
                } else {
                  result.logs.push({
                    level: "warn",
                    message: "We've encountered a nal unit without data at " + i + " for trackId " + trackId + ". See mux.js#223."
                  });
                  break;
                }
                result.seiNals.push(seiNal);
                break;
            }
          }
          return result;
        };
        var parseCaptionNals = function parseCaptionNals2(segment, videoTrackId) {
          var captionNals = {};
          var mdatTrafPairs = getMdatTrafPairs$1(segment);
          mdatTrafPairs.forEach(function(pair) {
            var mdat2 = pair.mdat;
            var traf2 = pair.traf;
            var tfhd2 = findBox$1(traf2, ["tfhd"]);
            var headerInfo = parseTfhd(tfhd2[0]);
            var trackId = headerInfo.trackId;
            var tfdt2 = findBox$1(traf2, ["tfdt"]);
            var baseMediaDecodeTime = tfdt2.length > 0 ? parseTfdt$1(tfdt2[0]).baseMediaDecodeTime : 0;
            var truns = findBox$1(traf2, ["trun"]);
            var samples2;
            var result;
            if (videoTrackId === trackId && truns.length > 0) {
              samples2 = parseSamples$1(truns, baseMediaDecodeTime, headerInfo);
              result = findSeiNals(mdat2, samples2, trackId);
              if (!captionNals[trackId]) {
                captionNals[trackId] = {
                  seiNals: [],
                  logs: []
                };
              }
              captionNals[trackId].seiNals = captionNals[trackId].seiNals.concat(result.seiNals);
              captionNals[trackId].logs = captionNals[trackId].logs.concat(result.logs);
            }
          });
          return captionNals;
        };
        var parseEmbeddedCaptions = function parseEmbeddedCaptions2(segment, trackId, timescale2) {
          var captionNals;
          if (trackId === null) {
            return null;
          }
          captionNals = parseCaptionNals(segment, trackId);
          var trackNals = captionNals[trackId] || {};
          return {
            seiNals: trackNals.seiNals,
            logs: trackNals.logs,
            timescale: timescale2
          };
        };
        var CaptionParser = function CaptionParser2() {
          var isInitialized = false;
          var captionStream2;
          var segmentCache;
          var trackId;
          var timescale2;
          var parsedCaptions;
          var parsingPartial;
          this.isInitialized = function() {
            return isInitialized;
          };
          this.init = function(options) {
            captionStream2 = new CaptionStream();
            isInitialized = true;
            parsingPartial = options ? options.isPartial : false;
            captionStream2.on("data", function(event) {
              event.startTime = event.startPts / timescale2;
              event.endTime = event.endPts / timescale2;
              parsedCaptions.captions.push(event);
              parsedCaptions.captionStreams[event.stream] = true;
            });
            captionStream2.on("log", function(log) {
              parsedCaptions.logs.push(log);
            });
          };
          this.isNewInit = function(videoTrackIds, timescales) {
            if (videoTrackIds && videoTrackIds.length === 0 || timescales && typeof timescales === "object" && Object.keys(timescales).length === 0) {
              return false;
            }
            return trackId !== videoTrackIds[0] || timescale2 !== timescales[trackId];
          };
          this.parse = function(segment, videoTrackIds, timescales) {
            var parsedData;
            if (!this.isInitialized()) {
              return null;
            } else if (!videoTrackIds || !timescales) {
              return null;
            } else if (this.isNewInit(videoTrackIds, timescales)) {
              trackId = videoTrackIds[0];
              timescale2 = timescales[trackId];
            } else if (trackId === null || !timescale2) {
              segmentCache.push(segment);
              return null;
            }
            while (segmentCache.length > 0) {
              var cachedSegment = segmentCache.shift();
              this.parse(cachedSegment, videoTrackIds, timescales);
            }
            parsedData = parseEmbeddedCaptions(segment, trackId, timescale2);
            if (parsedData && parsedData.logs) {
              parsedCaptions.logs = parsedCaptions.logs.concat(parsedData.logs);
            }
            if (parsedData === null || !parsedData.seiNals) {
              if (parsedCaptions.logs.length) {
                return {
                  logs: parsedCaptions.logs,
                  captions: [],
                  captionStreams: []
                };
              }
              return null;
            }
            this.pushNals(parsedData.seiNals);
            this.flushStream();
            return parsedCaptions;
          };
          this.pushNals = function(nals) {
            if (!this.isInitialized() || !nals || nals.length === 0) {
              return null;
            }
            nals.forEach(function(nal) {
              captionStream2.push(nal);
            });
          };
          this.flushStream = function() {
            if (!this.isInitialized()) {
              return null;
            }
            if (!parsingPartial) {
              captionStream2.flush();
            } else {
              captionStream2.partialFlush();
            }
          };
          this.clearParsedCaptions = function() {
            parsedCaptions.captions = [];
            parsedCaptions.captionStreams = {};
            parsedCaptions.logs = [];
          };
          this.resetCaptionStream = function() {
            if (!this.isInitialized()) {
              return null;
            }
            captionStream2.reset();
          };
          this.clearAllCaptions = function() {
            this.clearParsedCaptions();
            this.resetCaptionStream();
          };
          this.reset = function() {
            segmentCache = [];
            trackId = null;
            timescale2 = null;
            if (!parsedCaptions) {
              parsedCaptions = {
                captions: [],
                // CC1, CC2, CC3, CC4
                captionStreams: {},
                logs: []
              };
            } else {
              this.clearParsedCaptions();
            }
            this.resetCaptionStream();
          };
          this.reset();
        };
        var captionParser = CaptionParser;
        var parseTfdt = mp4Inspector.parseTfdt;
        var findBox = findBox_1;
        var getTimescaleFromMediaHeader = probe$2.getTimescaleFromMediaHeader;
        var parseSamples = samples.parseSamples, getMdatTrafPairs = samples.getMdatTrafPairs;
        var WebVttParser = function WebVttParser2() {
          var timescale2 = 9e4;
          this.init = function(segment) {
            var mdhd2 = findBox(segment, ["moov", "trak", "mdia", "mdhd"])[0];
            if (mdhd2) {
              timescale2 = getTimescaleFromMediaHeader(mdhd2);
            }
          };
          this.parseSegment = function(segment) {
            var vttCues = [];
            var mdatTrafPairs = getMdatTrafPairs(segment);
            var baseMediaDecodeTime = 0;
            mdatTrafPairs.forEach(function(pair) {
              var mdatBox = pair.mdat;
              var trafBox = pair.traf;
              var tfdtBox = findBox(trafBox, ["tfdt"])[0];
              var tfhdBox = findBox(trafBox, ["tfhd"])[0];
              var trunBoxes = findBox(trafBox, ["trun"]);
              if (tfdtBox) {
                var tfdt2 = parseTfdt(tfdtBox);
                baseMediaDecodeTime = tfdt2.baseMediaDecodeTime;
              }
              if (trunBoxes.length && tfhdBox) {
                var samples2 = parseSamples(trunBoxes, baseMediaDecodeTime, tfhdBox);
                var mdatOffset = 0;
                samples2.forEach(function(sample) {
                  var UTF_8 = "utf-8";
                  var textDecoder = new TextDecoder(UTF_8);
                  var sampleData = mdatBox.slice(mdatOffset, mdatOffset + sample.size);
                  var vtteBox = findBox(sampleData, ["vtte"])[0];
                  if (vtteBox) {
                    mdatOffset += sample.size;
                    return;
                  }
                  var vttcBoxes = findBox(sampleData, ["vttc"]);
                  vttcBoxes.forEach(function(vttcBox) {
                    var paylBox = findBox(vttcBox, ["payl"])[0];
                    var sttgBox = findBox(vttcBox, ["sttg"])[0];
                    var start = sample.pts / timescale2;
                    var end = (sample.pts + sample.duration) / timescale2;
                    var cueText, settings2;
                    if (paylBox) {
                      try {
                        cueText = textDecoder.decode(paylBox);
                      } catch (e) {
                        console.error(e);
                      }
                    }
                    if (sttgBox) {
                      try {
                        settings2 = textDecoder.decode(sttgBox);
                      } catch (e) {
                        console.error(e);
                      }
                    }
                    if (sample.duration && cueText) {
                      vttCues.push({
                        cueText,
                        start,
                        end,
                        settings: settings2
                      });
                    }
                  });
                  mdatOffset += sample.size;
                });
              }
            });
            return vttCues;
          };
        };
        var webvttParser = WebVttParser;
        var mp4$2 = {
          generator: mp4Generator,
          probe: probe$2,
          Transmuxer: transmuxer$2.Transmuxer,
          AudioSegmentStream: transmuxer$2.AudioSegmentStream,
          VideoSegmentStream: transmuxer$2.VideoSegmentStream,
          CaptionParser: captionParser,
          WebVttParser: webvttParser
        };
        var _FlvTag;
        _FlvTag = function FlvTag2(type2, extraData) {
          var adHoc = 0, bufferStartSize = 16384, prepareWrite = function prepareWrite2(flv2, count) {
            var bytes, minLength = flv2.position + count;
            if (minLength < flv2.bytes.byteLength) {
              return;
            }
            bytes = new Uint8Array(minLength * 2);
            bytes.set(flv2.bytes.subarray(0, flv2.position), 0);
            flv2.bytes = bytes;
            flv2.view = new DataView(flv2.bytes.buffer);
          }, widthBytes = _FlvTag.widthBytes || new Uint8Array("width".length), heightBytes = _FlvTag.heightBytes || new Uint8Array("height".length), videocodecidBytes = _FlvTag.videocodecidBytes || new Uint8Array("videocodecid".length), i;
          if (!_FlvTag.widthBytes) {
            for (i = 0; i < "width".length; i++) {
              widthBytes[i] = "width".charCodeAt(i);
            }
            for (i = 0; i < "height".length; i++) {
              heightBytes[i] = "height".charCodeAt(i);
            }
            for (i = 0; i < "videocodecid".length; i++) {
              videocodecidBytes[i] = "videocodecid".charCodeAt(i);
            }
            _FlvTag.widthBytes = widthBytes;
            _FlvTag.heightBytes = heightBytes;
            _FlvTag.videocodecidBytes = videocodecidBytes;
          }
          this.keyFrame = false;
          switch (type2) {
            case _FlvTag.VIDEO_TAG:
              this.length = 16;
              bufferStartSize *= 6;
              break;
            case _FlvTag.AUDIO_TAG:
              this.length = 13;
              this.keyFrame = true;
              break;
            case _FlvTag.METADATA_TAG:
              this.length = 29;
              this.keyFrame = true;
              break;
            default:
              throw new Error("Unknown FLV tag type");
          }
          this.bytes = new Uint8Array(bufferStartSize);
          this.view = new DataView(this.bytes.buffer);
          this.bytes[0] = type2;
          this.position = this.length;
          this.keyFrame = extraData;
          this.pts = 0;
          this.dts = 0;
          this.writeBytes = function(bytes, offset, length) {
            var start = offset || 0, end;
            length = length || bytes.byteLength;
            end = start + length;
            prepareWrite(this, length);
            this.bytes.set(bytes.subarray(start, end), this.position);
            this.position += length;
            this.length = Math.max(this.length, this.position);
          };
          this.writeByte = function(byte) {
            prepareWrite(this, 1);
            this.bytes[this.position] = byte;
            this.position++;
            this.length = Math.max(this.length, this.position);
          };
          this.writeShort = function(short) {
            prepareWrite(this, 2);
            this.view.setUint16(this.position, short);
            this.position += 2;
            this.length = Math.max(this.length, this.position);
          };
          this.negIndex = function(pos) {
            return this.bytes[this.length - pos];
          };
          this.nalUnitSize = function() {
            if (adHoc === 0) {
              return 0;
            }
            return this.length - (adHoc + 4);
          };
          this.startNalUnit = function() {
            if (adHoc > 0) {
              throw new Error("Attempted to create new NAL wihout closing the old one");
            }
            adHoc = this.length;
            this.length += 4;
            this.position = this.length;
          };
          this.endNalUnit = function(nalContainer) {
            var nalStart, nalLength;
            if (this.length === adHoc + 4) {
              this.length -= 4;
            } else if (adHoc > 0) {
              nalStart = adHoc + 4;
              nalLength = this.length - nalStart;
              this.position = adHoc;
              this.view.setUint32(this.position, nalLength);
              this.position = this.length;
              if (nalContainer) {
                nalContainer.push(this.bytes.subarray(nalStart, nalStart + nalLength));
              }
            }
            adHoc = 0;
          };
          this.writeMetaDataDouble = function(key, val) {
            var i2;
            prepareWrite(this, 2 + key.length + 9);
            this.view.setUint16(this.position, key.length);
            this.position += 2;
            if (key === "width") {
              this.bytes.set(widthBytes, this.position);
              this.position += 5;
            } else if (key === "height") {
              this.bytes.set(heightBytes, this.position);
              this.position += 6;
            } else if (key === "videocodecid") {
              this.bytes.set(videocodecidBytes, this.position);
              this.position += 12;
            } else {
              for (i2 = 0; i2 < key.length; i2++) {
                this.bytes[this.position] = key.charCodeAt(i2);
                this.position++;
              }
            }
            this.position++;
            this.view.setFloat64(this.position, val);
            this.position += 8;
            this.length = Math.max(this.length, this.position);
            ++adHoc;
          };
          this.writeMetaDataBoolean = function(key, val) {
            var i2;
            prepareWrite(this, 2);
            this.view.setUint16(this.position, key.length);
            this.position += 2;
            for (i2 = 0; i2 < key.length; i2++) {
              prepareWrite(this, 1);
              this.bytes[this.position] = key.charCodeAt(i2);
              this.position++;
            }
            prepareWrite(this, 2);
            this.view.setUint8(this.position, 1);
            this.position++;
            this.view.setUint8(this.position, val ? 1 : 0);
            this.position++;
            this.length = Math.max(this.length, this.position);
            ++adHoc;
          };
          this.finalize = function() {
            var dtsDelta, len;
            switch (this.bytes[0]) {
              // Video Data
              case _FlvTag.VIDEO_TAG:
                this.bytes[11] = (this.keyFrame || extraData ? 16 : 32) | 7;
                this.bytes[12] = extraData ? 0 : 1;
                dtsDelta = this.pts - this.dts;
                this.bytes[13] = (dtsDelta & 16711680) >>> 16;
                this.bytes[14] = (dtsDelta & 65280) >>> 8;
                this.bytes[15] = (dtsDelta & 255) >>> 0;
                break;
              case _FlvTag.AUDIO_TAG:
                this.bytes[11] = 175;
                this.bytes[12] = extraData ? 0 : 1;
                break;
              case _FlvTag.METADATA_TAG:
                this.position = 11;
                this.view.setUint8(this.position, 2);
                this.position++;
                this.view.setUint16(this.position, 10);
                this.position += 2;
                this.bytes.set([111, 110, 77, 101, 116, 97, 68, 97, 116, 97], this.position);
                this.position += 10;
                this.bytes[this.position] = 8;
                this.position++;
                this.view.setUint32(this.position, adHoc);
                this.position = this.length;
                this.bytes.set([0, 0, 9], this.position);
                this.position += 3;
                this.length = this.position;
                break;
            }
            len = this.length - 11;
            this.bytes[1] = (len & 16711680) >>> 16;
            this.bytes[2] = (len & 65280) >>> 8;
            this.bytes[3] = (len & 255) >>> 0;
            this.bytes[4] = (this.dts & 16711680) >>> 16;
            this.bytes[5] = (this.dts & 65280) >>> 8;
            this.bytes[6] = (this.dts & 255) >>> 0;
            this.bytes[7] = (this.dts & 4278190080) >>> 24;
            this.bytes[8] = 0;
            this.bytes[9] = 0;
            this.bytes[10] = 0;
            prepareWrite(this, 4);
            this.view.setUint32(this.length, this.length);
            this.length += 4;
            this.position += 4;
            this.bytes = this.bytes.subarray(0, this.length);
            this.frameTime = _FlvTag.frameTime(this.bytes);
            return this;
          };
        };
        _FlvTag.AUDIO_TAG = 8;
        _FlvTag.VIDEO_TAG = 9;
        _FlvTag.METADATA_TAG = 18;
        _FlvTag.isAudioFrame = function(tag) {
          return _FlvTag.AUDIO_TAG === tag[0];
        };
        _FlvTag.isVideoFrame = function(tag) {
          return _FlvTag.VIDEO_TAG === tag[0];
        };
        _FlvTag.isMetaData = function(tag) {
          return _FlvTag.METADATA_TAG === tag[0];
        };
        _FlvTag.isKeyFrame = function(tag) {
          if (_FlvTag.isVideoFrame(tag)) {
            return tag[11] === 23;
          }
          if (_FlvTag.isAudioFrame(tag)) {
            return true;
          }
          if (_FlvTag.isMetaData(tag)) {
            return true;
          }
          return false;
        };
        _FlvTag.frameTime = function(tag) {
          var pts = tag[4] << 16;
          pts |= tag[5] << 8;
          pts |= tag[6] << 0;
          pts |= tag[7] << 24;
          return pts;
        };
        var flvTag = _FlvTag;
        var Stream$4 = stream;
        var CoalesceStream$1 = function CoalesceStream2(options) {
          this.numberOfTracks = 0;
          this.metadataStream = options.metadataStream;
          this.videoTags = [];
          this.audioTags = [];
          this.videoTrack = null;
          this.audioTrack = null;
          this.pendingCaptions = [];
          this.pendingMetadata = [];
          this.pendingTracks = 0;
          this.processedTracks = 0;
          CoalesceStream2.prototype.init.call(this);
          this.push = function(output) {
            if (output.content || output.text) {
              return this.pendingCaptions.push(output);
            }
            if (output.frames) {
              return this.pendingMetadata.push(output);
            }
            if (output.track.type === "video") {
              this.videoTrack = output.track;
              this.videoTags = output.tags;
              this.pendingTracks++;
            }
            if (output.track.type === "audio") {
              this.audioTrack = output.track;
              this.audioTags = output.tags;
              this.pendingTracks++;
            }
          };
        };
        CoalesceStream$1.prototype = new Stream$4();
        CoalesceStream$1.prototype.flush = function(flushSource) {
          var id32, caption, i, timelineStartPts, event = {
            tags: {},
            captions: [],
            captionStreams: {},
            metadata: []
          };
          if (this.pendingTracks < this.numberOfTracks) {
            if (flushSource !== "VideoSegmentStream" && flushSource !== "AudioSegmentStream") {
              return;
            } else if (this.pendingTracks === 0) {
              this.processedTracks++;
              if (this.processedTracks < this.numberOfTracks) {
                return;
              }
            }
          }
          this.processedTracks += this.pendingTracks;
          this.pendingTracks = 0;
          if (this.processedTracks < this.numberOfTracks) {
            return;
          }
          if (this.videoTrack) {
            timelineStartPts = this.videoTrack.timelineStartInfo.pts;
          } else if (this.audioTrack) {
            timelineStartPts = this.audioTrack.timelineStartInfo.pts;
          }
          event.tags.videoTags = this.videoTags;
          event.tags.audioTags = this.audioTags;
          for (i = 0; i < this.pendingCaptions.length; i++) {
            caption = this.pendingCaptions[i];
            caption.startTime = caption.startPts - timelineStartPts;
            caption.startTime /= 9e4;
            caption.endTime = caption.endPts - timelineStartPts;
            caption.endTime /= 9e4;
            event.captionStreams[caption.stream] = true;
            event.captions.push(caption);
          }
          for (i = 0; i < this.pendingMetadata.length; i++) {
            id32 = this.pendingMetadata[i];
            id32.cueTime = id32.pts - timelineStartPts;
            id32.cueTime /= 9e4;
            event.metadata.push(id32);
          }
          event.metadata.dispatchType = this.metadataStream.dispatchType;
          this.videoTrack = null;
          this.audioTrack = null;
          this.videoTags = [];
          this.audioTags = [];
          this.pendingCaptions.length = 0;
          this.pendingMetadata.length = 0;
          this.pendingTracks = 0;
          this.processedTracks = 0;
          this.trigger("data", event);
          this.trigger("done");
        };
        var coalesceStream = CoalesceStream$1;
        var TagList$1 = function TagList2() {
          var self2 = this;
          this.list = [];
          this.push = function(tag) {
            this.list.push({
              bytes: tag.bytes,
              dts: tag.dts,
              pts: tag.pts,
              keyFrame: tag.keyFrame,
              metaDataTag: tag.metaDataTag
            });
          };
          Object.defineProperty(this, "length", {
            get: function get() {
              return self2.list.length;
            }
          });
        };
        var tagList = TagList$1;
        var Stream$3 = stream;
        var FlvTag$1 = flvTag;
        var m2ts$2 = m2ts_1;
        var AdtsStream$1 = adts;
        var H264Stream = h264.H264Stream;
        var CoalesceStream = coalesceStream;
        var TagList = tagList;
        var _Transmuxer, _VideoSegmentStream, _AudioSegmentStream, collectTimelineInfo, metaDataTag, extraDataTag;
        collectTimelineInfo = function collectTimelineInfo2(track, data) {
          if (typeof data.pts === "number") {
            if (track.timelineStartInfo.pts === void 0) {
              track.timelineStartInfo.pts = data.pts;
            } else {
              track.timelineStartInfo.pts = Math.min(track.timelineStartInfo.pts, data.pts);
            }
          }
          if (typeof data.dts === "number") {
            if (track.timelineStartInfo.dts === void 0) {
              track.timelineStartInfo.dts = data.dts;
            } else {
              track.timelineStartInfo.dts = Math.min(track.timelineStartInfo.dts, data.dts);
            }
          }
        };
        metaDataTag = function metaDataTag2(track, pts) {
          var tag = new FlvTag$1(FlvTag$1.METADATA_TAG);
          tag.dts = pts;
          tag.pts = pts;
          tag.writeMetaDataDouble("videocodecid", 7);
          tag.writeMetaDataDouble("width", track.width);
          tag.writeMetaDataDouble("height", track.height);
          return tag;
        };
        extraDataTag = function extraDataTag2(track, pts) {
          var i, tag = new FlvTag$1(FlvTag$1.VIDEO_TAG, true);
          tag.dts = pts;
          tag.pts = pts;
          tag.writeByte(1);
          tag.writeByte(track.profileIdc);
          tag.writeByte(track.profileCompatibility);
          tag.writeByte(track.levelIdc);
          tag.writeByte(252 | 3);
          tag.writeByte(224 | 1);
          tag.writeShort(track.sps[0].length);
          tag.writeBytes(track.sps[0]);
          tag.writeByte(track.pps.length);
          for (i = 0; i < track.pps.length; ++i) {
            tag.writeShort(track.pps[i].length);
            tag.writeBytes(track.pps[i]);
          }
          return tag;
        };
        _AudioSegmentStream = function AudioSegmentStream2(track) {
          var adtsFrames = [], videoKeyFrames = [], oldExtraData;
          _AudioSegmentStream.prototype.init.call(this);
          this.push = function(data) {
            collectTimelineInfo(track, data);
            if (track) {
              track.audioobjecttype = data.audioobjecttype;
              track.channelcount = data.channelcount;
              track.samplerate = data.samplerate;
              track.samplingfrequencyindex = data.samplingfrequencyindex;
              track.samplesize = data.samplesize;
              track.extraData = track.audioobjecttype << 11 | track.samplingfrequencyindex << 7 | track.channelcount << 3;
            }
            data.pts = Math.round(data.pts / 90);
            data.dts = Math.round(data.dts / 90);
            adtsFrames.push(data);
          };
          this.flush = function() {
            var currentFrame, adtsFrame, lastMetaPts, tags = new TagList();
            if (adtsFrames.length === 0) {
              this.trigger("done", "AudioSegmentStream");
              return;
            }
            lastMetaPts = -Infinity;
            while (adtsFrames.length) {
              currentFrame = adtsFrames.shift();
              if (videoKeyFrames.length && currentFrame.pts >= videoKeyFrames[0]) {
                lastMetaPts = videoKeyFrames.shift();
                this.writeMetaDataTags(tags, lastMetaPts);
              }
              if (track.extraData !== oldExtraData || currentFrame.pts - lastMetaPts >= 1e3) {
                this.writeMetaDataTags(tags, currentFrame.pts);
                oldExtraData = track.extraData;
                lastMetaPts = currentFrame.pts;
              }
              adtsFrame = new FlvTag$1(FlvTag$1.AUDIO_TAG);
              adtsFrame.pts = currentFrame.pts;
              adtsFrame.dts = currentFrame.dts;
              adtsFrame.writeBytes(currentFrame.data);
              tags.push(adtsFrame.finalize());
            }
            videoKeyFrames.length = 0;
            oldExtraData = null;
            this.trigger("data", {
              track,
              tags: tags.list
            });
            this.trigger("done", "AudioSegmentStream");
          };
          this.writeMetaDataTags = function(tags, pts) {
            var adtsFrame;
            adtsFrame = new FlvTag$1(FlvTag$1.METADATA_TAG);
            adtsFrame.pts = pts;
            adtsFrame.dts = pts;
            adtsFrame.writeMetaDataDouble("audiocodecid", 10);
            adtsFrame.writeMetaDataBoolean("stereo", track.channelcount === 2);
            adtsFrame.writeMetaDataDouble("audiosamplerate", track.samplerate);
            adtsFrame.writeMetaDataDouble("audiosamplesize", 16);
            tags.push(adtsFrame.finalize());
            adtsFrame = new FlvTag$1(FlvTag$1.AUDIO_TAG, true);
            adtsFrame.pts = pts;
            adtsFrame.dts = pts;
            adtsFrame.view.setUint16(adtsFrame.position, track.extraData);
            adtsFrame.position += 2;
            adtsFrame.length = Math.max(adtsFrame.length, adtsFrame.position);
            tags.push(adtsFrame.finalize());
          };
          this.onVideoKeyFrame = function(pts) {
            videoKeyFrames.push(pts);
          };
        };
        _AudioSegmentStream.prototype = new Stream$3();
        _VideoSegmentStream = function VideoSegmentStream2(track) {
          var nalUnits = [], config, h264Frame;
          _VideoSegmentStream.prototype.init.call(this);
          this.finishFrame = function(tags, frame) {
            if (!frame) {
              return;
            }
            if (config && track && track.newMetadata && (frame.keyFrame || tags.length === 0)) {
              var metaTag = metaDataTag(config, frame.dts).finalize();
              var extraTag = extraDataTag(track, frame.dts).finalize();
              metaTag.metaDataTag = extraTag.metaDataTag = true;
              tags.push(metaTag);
              tags.push(extraTag);
              track.newMetadata = false;
              this.trigger("keyframe", frame.dts);
            }
            frame.endNalUnit();
            tags.push(frame.finalize());
            h264Frame = null;
          };
          this.push = function(data) {
            collectTimelineInfo(track, data);
            data.pts = Math.round(data.pts / 90);
            data.dts = Math.round(data.dts / 90);
            nalUnits.push(data);
          };
          this.flush = function() {
            var currentNal, tags = new TagList();
            while (nalUnits.length) {
              if (nalUnits[0].nalUnitType === "access_unit_delimiter_rbsp") {
                break;
              }
              nalUnits.shift();
            }
            if (nalUnits.length === 0) {
              this.trigger("done", "VideoSegmentStream");
              return;
            }
            while (nalUnits.length) {
              currentNal = nalUnits.shift();
              if (currentNal.nalUnitType === "seq_parameter_set_rbsp") {
                track.newMetadata = true;
                config = currentNal.config;
                track.width = config.width;
                track.height = config.height;
                track.sps = [currentNal.data];
                track.profileIdc = config.profileIdc;
                track.levelIdc = config.levelIdc;
                track.profileCompatibility = config.profileCompatibility;
                h264Frame.endNalUnit();
              } else if (currentNal.nalUnitType === "pic_parameter_set_rbsp") {
                track.newMetadata = true;
                track.pps = [currentNal.data];
                h264Frame.endNalUnit();
              } else if (currentNal.nalUnitType === "access_unit_delimiter_rbsp") {
                if (h264Frame) {
                  this.finishFrame(tags, h264Frame);
                }
                h264Frame = new FlvTag$1(FlvTag$1.VIDEO_TAG);
                h264Frame.pts = currentNal.pts;
                h264Frame.dts = currentNal.dts;
              } else {
                if (currentNal.nalUnitType === "slice_layer_without_partitioning_rbsp_idr") {
                  h264Frame.keyFrame = true;
                }
                h264Frame.endNalUnit();
              }
              h264Frame.startNalUnit();
              h264Frame.writeBytes(currentNal.data);
            }
            if (h264Frame) {
              this.finishFrame(tags, h264Frame);
            }
            this.trigger("data", {
              track,
              tags: tags.list
            });
            this.trigger("done", "VideoSegmentStream");
          };
        };
        _VideoSegmentStream.prototype = new Stream$3();
        _Transmuxer = function Transmuxer2(options) {
          var self2 = this, packetStream, parseStream, elementaryStream, videoTimestampRolloverStream, audioTimestampRolloverStream, timedMetadataTimestampRolloverStream, adtsStream, h264Stream, videoSegmentStream2, audioSegmentStream2, captionStream2, coalesceStream2;
          _Transmuxer.prototype.init.call(this);
          options = options || {};
          this.metadataStream = new m2ts$2.MetadataStream();
          options.metadataStream = this.metadataStream;
          packetStream = new m2ts$2.TransportPacketStream();
          parseStream = new m2ts$2.TransportParseStream();
          elementaryStream = new m2ts$2.ElementaryStream();
          videoTimestampRolloverStream = new m2ts$2.TimestampRolloverStream("video");
          audioTimestampRolloverStream = new m2ts$2.TimestampRolloverStream("audio");
          timedMetadataTimestampRolloverStream = new m2ts$2.TimestampRolloverStream("timed-metadata");
          adtsStream = new AdtsStream$1();
          h264Stream = new H264Stream();
          coalesceStream2 = new CoalesceStream(options);
          packetStream.pipe(parseStream).pipe(elementaryStream);
          elementaryStream.pipe(videoTimestampRolloverStream).pipe(h264Stream);
          elementaryStream.pipe(audioTimestampRolloverStream).pipe(adtsStream);
          elementaryStream.pipe(timedMetadataTimestampRolloverStream).pipe(this.metadataStream).pipe(coalesceStream2);
          captionStream2 = new m2ts$2.CaptionStream(options);
          h264Stream.pipe(captionStream2).pipe(coalesceStream2);
          elementaryStream.on("data", function(data) {
            var i, videoTrack, audioTrack;
            if (data.type === "metadata") {
              i = data.tracks.length;
              while (i--) {
                if (data.tracks[i].type === "video") {
                  videoTrack = data.tracks[i];
                } else if (data.tracks[i].type === "audio") {
                  audioTrack = data.tracks[i];
                }
              }
              if (videoTrack && !videoSegmentStream2) {
                coalesceStream2.numberOfTracks++;
                videoSegmentStream2 = new _VideoSegmentStream(videoTrack);
                h264Stream.pipe(videoSegmentStream2).pipe(coalesceStream2);
              }
              if (audioTrack && !audioSegmentStream2) {
                coalesceStream2.numberOfTracks++;
                audioSegmentStream2 = new _AudioSegmentStream(audioTrack);
                adtsStream.pipe(audioSegmentStream2).pipe(coalesceStream2);
                if (videoSegmentStream2) {
                  videoSegmentStream2.on("keyframe", audioSegmentStream2.onVideoKeyFrame);
                }
              }
            }
          });
          this.push = function(data) {
            packetStream.push(data);
          };
          this.flush = function() {
            packetStream.flush();
          };
          this.resetCaptions = function() {
            captionStream2.reset();
          };
          coalesceStream2.on("data", function(event) {
            self2.trigger("data", event);
          });
          coalesceStream2.on("done", function() {
            self2.trigger("done");
          });
        };
        _Transmuxer.prototype = new Stream$3();
        var transmuxer$1 = _Transmuxer;
        var FlvTag = flvTag;
        var getFlvHeader = function getFlvHeader2(duration, audio, video) {
          var headBytes = new Uint8Array(3 + 1 + 1 + 4), head = new DataView(headBytes.buffer), metadata, result, metadataLength;
          duration = duration || 0;
          audio = audio === void 0 ? true : audio;
          video = video === void 0 ? true : video;
          head.setUint8(0, 70);
          head.setUint8(1, 76);
          head.setUint8(2, 86);
          head.setUint8(3, 1);
          head.setUint8(4, (audio ? 4 : 0) | (video ? 1 : 0));
          head.setUint32(5, headBytes.byteLength);
          if (duration <= 0) {
            result = new Uint8Array(headBytes.byteLength + 4);
            result.set(headBytes);
            result.set([0, 0, 0, 0], headBytes.byteLength);
            return result;
          }
          metadata = new FlvTag(FlvTag.METADATA_TAG);
          metadata.pts = metadata.dts = 0;
          metadata.writeMetaDataDouble("duration", duration);
          metadataLength = metadata.finalize().length;
          result = new Uint8Array(headBytes.byteLength + metadataLength);
          result.set(headBytes);
          result.set(head.byteLength, metadataLength);
          return result;
        };
        var flvHeader = getFlvHeader;
        var flv = {
          tag: flvTag,
          Transmuxer: transmuxer$1,
          getFlvHeader: flvHeader
        };
        var m2ts$1 = m2ts_1;
        var Stream$2 = stream;
        var mp4$1 = mp4Generator;
        var audioFrameUtils = audioFrameUtils$2;
        var trackInfo$2 = trackDecodeInfo$1;
        var ONE_SECOND_IN_TS$1 = clock$3.ONE_SECOND_IN_TS;
        var AUDIO_PROPERTIES = audioProperties;
        var AudioSegmentStream$1 = function AudioSegmentStream2(track, options) {
          var adtsFrames = [], sequenceNumber = 0, earliestAllowedDts = 0, audioAppendStartTs = 0, videoBaseMediaDecodeTime = Infinity, segmentStartPts = null, segmentEndPts = null;
          options = options || {};
          AudioSegmentStream2.prototype.init.call(this);
          this.push = function(data) {
            trackInfo$2.collectDtsInfo(track, data);
            if (track) {
              AUDIO_PROPERTIES.forEach(function(prop) {
                track[prop] = data[prop];
              });
            }
            adtsFrames.push(data);
          };
          this.setEarliestDts = function(earliestDts) {
            earliestAllowedDts = earliestDts;
          };
          this.setVideoBaseMediaDecodeTime = function(baseMediaDecodeTime) {
            videoBaseMediaDecodeTime = baseMediaDecodeTime;
          };
          this.setAudioAppendStart = function(timestamp) {
            audioAppendStartTs = timestamp;
          };
          this.processFrames_ = function() {
            var frames, moof2, mdat2, boxes2, timingInfo;
            if (adtsFrames.length === 0) {
              return;
            }
            frames = audioFrameUtils.trimAdtsFramesByEarliestDts(adtsFrames, track, earliestAllowedDts);
            if (frames.length === 0) {
              return;
            }
            track.baseMediaDecodeTime = trackInfo$2.calculateTrackBaseMediaDecodeTime(track, options.keepOriginalTimestamps);
            audioFrameUtils.prefixWithSilence(track, frames, audioAppendStartTs, videoBaseMediaDecodeTime);
            track.samples = audioFrameUtils.generateSampleTable(frames);
            mdat2 = mp4$1.mdat(audioFrameUtils.concatenateFrameData(frames));
            adtsFrames = [];
            moof2 = mp4$1.moof(sequenceNumber, [track]);
            sequenceNumber++;
            track.initSegment = mp4$1.initSegment([track]);
            boxes2 = new Uint8Array(moof2.byteLength + mdat2.byteLength);
            boxes2.set(moof2);
            boxes2.set(mdat2, moof2.byteLength);
            trackInfo$2.clearDtsInfo(track);
            if (segmentStartPts === null) {
              segmentEndPts = segmentStartPts = frames[0].pts;
            }
            segmentEndPts += frames.length * (ONE_SECOND_IN_TS$1 * 1024 / track.samplerate);
            timingInfo = {
              start: segmentStartPts
            };
            this.trigger("timingInfo", timingInfo);
            this.trigger("data", {
              track,
              boxes: boxes2
            });
          };
          this.flush = function() {
            this.processFrames_();
            this.trigger("timingInfo", {
              start: segmentStartPts,
              end: segmentEndPts
            });
            this.resetTiming_();
            this.trigger("done", "AudioSegmentStream");
          };
          this.partialFlush = function() {
            this.processFrames_();
            this.trigger("partialdone", "AudioSegmentStream");
          };
          this.endTimeline = function() {
            this.flush();
            this.trigger("endedtimeline", "AudioSegmentStream");
          };
          this.resetTiming_ = function() {
            trackInfo$2.clearDtsInfo(track);
            segmentStartPts = null;
            segmentEndPts = null;
          };
          this.reset = function() {
            this.resetTiming_();
            adtsFrames = [];
            this.trigger("reset");
          };
        };
        AudioSegmentStream$1.prototype = new Stream$2();
        var audioSegmentStream = AudioSegmentStream$1;
        var Stream$1 = stream;
        var mp4 = mp4Generator;
        var trackInfo$1 = trackDecodeInfo$1;
        var frameUtils = frameUtils$2;
        var VIDEO_PROPERTIES = videoProperties;
        var VideoSegmentStream$1 = function VideoSegmentStream2(track, options) {
          var sequenceNumber = 0, nalUnits = [], frameCache = [], config, pps, segmentStartPts = null, segmentEndPts = null, gops, ensureNextFrameIsKeyFrame = true;
          options = options || {};
          VideoSegmentStream2.prototype.init.call(this);
          this.push = function(nalUnit) {
            trackInfo$1.collectDtsInfo(track, nalUnit);
            if (typeof track.timelineStartInfo.dts === "undefined") {
              track.timelineStartInfo.dts = nalUnit.dts;
            }
            if (nalUnit.nalUnitType === "seq_parameter_set_rbsp" && !config) {
              config = nalUnit.config;
              track.sps = [nalUnit.data];
              VIDEO_PROPERTIES.forEach(function(prop) {
                track[prop] = config[prop];
              }, this);
            }
            if (nalUnit.nalUnitType === "pic_parameter_set_rbsp" && !pps) {
              pps = nalUnit.data;
              track.pps = [nalUnit.data];
            }
            nalUnits.push(nalUnit);
          };
          this.processNals_ = function(cacheLastFrame) {
            var i;
            nalUnits = frameCache.concat(nalUnits);
            while (nalUnits.length) {
              if (nalUnits[0].nalUnitType === "access_unit_delimiter_rbsp") {
                break;
              }
              nalUnits.shift();
            }
            if (nalUnits.length === 0) {
              return;
            }
            var frames = frameUtils.groupNalsIntoFrames(nalUnits);
            if (!frames.length) {
              return;
            }
            frameCache = frames[frames.length - 1];
            if (cacheLastFrame) {
              frames.pop();
              frames.duration -= frameCache.duration;
              frames.nalCount -= frameCache.length;
              frames.byteLength -= frameCache.byteLength;
            }
            if (!frames.length) {
              nalUnits = [];
              return;
            }
            this.trigger("timelineStartInfo", track.timelineStartInfo);
            if (ensureNextFrameIsKeyFrame) {
              gops = frameUtils.groupFramesIntoGops(frames);
              if (!gops[0][0].keyFrame) {
                gops = frameUtils.extendFirstKeyFrame(gops);
                if (!gops[0][0].keyFrame) {
                  nalUnits = [].concat.apply([], frames).concat(frameCache);
                  frameCache = [];
                  return;
                }
                frames = [].concat.apply([], gops);
                frames.duration = gops.duration;
              }
              ensureNextFrameIsKeyFrame = false;
            }
            if (segmentStartPts === null) {
              segmentStartPts = frames[0].pts;
              segmentEndPts = segmentStartPts;
            }
            segmentEndPts += frames.duration;
            this.trigger("timingInfo", {
              start: segmentStartPts,
              end: segmentEndPts
            });
            for (i = 0; i < frames.length; i++) {
              var frame = frames[i];
              track.samples = frameUtils.generateSampleTableForFrame(frame);
              var mdat2 = mp4.mdat(frameUtils.concatenateNalDataForFrame(frame));
              trackInfo$1.clearDtsInfo(track);
              trackInfo$1.collectDtsInfo(track, frame);
              track.baseMediaDecodeTime = trackInfo$1.calculateTrackBaseMediaDecodeTime(track, options.keepOriginalTimestamps);
              var moof2 = mp4.moof(sequenceNumber, [track]);
              sequenceNumber++;
              track.initSegment = mp4.initSegment([track]);
              var boxes2 = new Uint8Array(moof2.byteLength + mdat2.byteLength);
              boxes2.set(moof2);
              boxes2.set(mdat2, moof2.byteLength);
              this.trigger("data", {
                track,
                boxes: boxes2,
                sequence: sequenceNumber,
                videoFrameDts: frame.dts,
                videoFramePts: frame.pts
              });
            }
            nalUnits = [];
          };
          this.resetTimingAndConfig_ = function() {
            config = void 0;
            pps = void 0;
            segmentStartPts = null;
            segmentEndPts = null;
          };
          this.partialFlush = function() {
            this.processNals_(true);
            this.trigger("partialdone", "VideoSegmentStream");
          };
          this.flush = function() {
            this.processNals_(false);
            this.resetTimingAndConfig_();
            this.trigger("done", "VideoSegmentStream");
          };
          this.endTimeline = function() {
            this.flush();
            this.trigger("endedtimeline", "VideoSegmentStream");
          };
          this.reset = function() {
            this.resetTimingAndConfig_();
            frameCache = [];
            nalUnits = [];
            ensureNextFrameIsKeyFrame = true;
            this.trigger("reset");
          };
        };
        VideoSegmentStream$1.prototype = new Stream$1();
        var videoSegmentStream = VideoSegmentStream$1;
        var Stream = stream;
        var m2ts = m2ts_1;
        var codecs = codecs$1;
        var AudioSegmentStream = audioSegmentStream;
        var VideoSegmentStream = videoSegmentStream;
        var trackInfo = trackDecodeInfo$1;
        var isLikelyAacData = utils.isLikelyAacData;
        var AdtsStream = adts;
        var AacStream = aac;
        var clock = clock$3;
        var createPipeline = function createPipeline2(object) {
          object.prototype = new Stream();
          object.prototype.init.call(object);
          return object;
        };
        var tsPipeline = function tsPipeline2(options) {
          var pipeline = {
            type: "ts",
            tracks: {
              audio: null,
              video: null
            },
            packet: new m2ts.TransportPacketStream(),
            parse: new m2ts.TransportParseStream(),
            elementary: new m2ts.ElementaryStream(),
            timestampRollover: new m2ts.TimestampRolloverStream(),
            adts: new codecs.Adts(),
            h264: new codecs.h264.H264Stream(),
            captionStream: new m2ts.CaptionStream(options),
            metadataStream: new m2ts.MetadataStream()
          };
          pipeline.headOfPipeline = pipeline.packet;
          pipeline.packet.pipe(pipeline.parse).pipe(pipeline.elementary).pipe(pipeline.timestampRollover);
          pipeline.timestampRollover.pipe(pipeline.h264);
          pipeline.h264.pipe(pipeline.captionStream);
          pipeline.timestampRollover.pipe(pipeline.metadataStream);
          pipeline.timestampRollover.pipe(pipeline.adts);
          pipeline.elementary.on("data", function(data) {
            if (data.type !== "metadata") {
              return;
            }
            for (var i = 0; i < data.tracks.length; i++) {
              if (!pipeline.tracks[data.tracks[i].type]) {
                pipeline.tracks[data.tracks[i].type] = data.tracks[i];
                pipeline.tracks[data.tracks[i].type].timelineStartInfo.baseMediaDecodeTime = options.baseMediaDecodeTime;
              }
            }
            if (pipeline.tracks.video && !pipeline.videoSegmentStream) {
              pipeline.videoSegmentStream = new VideoSegmentStream(pipeline.tracks.video, options);
              pipeline.videoSegmentStream.on("timelineStartInfo", function(timelineStartInfo) {
                if (pipeline.tracks.audio && !options.keepOriginalTimestamps) {
                  pipeline.audioSegmentStream.setEarliestDts(timelineStartInfo.dts - options.baseMediaDecodeTime);
                }
              });
              pipeline.videoSegmentStream.on("timingInfo", pipeline.trigger.bind(pipeline, "videoTimingInfo"));
              pipeline.videoSegmentStream.on("data", function(data2) {
                pipeline.trigger("data", {
                  type: "video",
                  data: data2
                });
              });
              pipeline.videoSegmentStream.on("done", pipeline.trigger.bind(pipeline, "done"));
              pipeline.videoSegmentStream.on("partialdone", pipeline.trigger.bind(pipeline, "partialdone"));
              pipeline.videoSegmentStream.on("endedtimeline", pipeline.trigger.bind(pipeline, "endedtimeline"));
              pipeline.h264.pipe(pipeline.videoSegmentStream);
            }
            if (pipeline.tracks.audio && !pipeline.audioSegmentStream) {
              pipeline.audioSegmentStream = new AudioSegmentStream(pipeline.tracks.audio, options);
              pipeline.audioSegmentStream.on("data", function(data2) {
                pipeline.trigger("data", {
                  type: "audio",
                  data: data2
                });
              });
              pipeline.audioSegmentStream.on("done", pipeline.trigger.bind(pipeline, "done"));
              pipeline.audioSegmentStream.on("partialdone", pipeline.trigger.bind(pipeline, "partialdone"));
              pipeline.audioSegmentStream.on("endedtimeline", pipeline.trigger.bind(pipeline, "endedtimeline"));
              pipeline.audioSegmentStream.on("timingInfo", pipeline.trigger.bind(pipeline, "audioTimingInfo"));
              pipeline.adts.pipe(pipeline.audioSegmentStream);
            }
            pipeline.trigger("trackinfo", {
              hasAudio: !!pipeline.tracks.audio,
              hasVideo: !!pipeline.tracks.video
            });
          });
          pipeline.captionStream.on("data", function(caption) {
            var timelineStartPts;
            if (pipeline.tracks.video) {
              timelineStartPts = pipeline.tracks.video.timelineStartInfo.pts || 0;
            } else {
              timelineStartPts = 0;
            }
            caption.startTime = clock.metadataTsToSeconds(caption.startPts, timelineStartPts, options.keepOriginalTimestamps);
            caption.endTime = clock.metadataTsToSeconds(caption.endPts, timelineStartPts, options.keepOriginalTimestamps);
            pipeline.trigger("caption", caption);
          });
          pipeline = createPipeline(pipeline);
          pipeline.metadataStream.on("data", pipeline.trigger.bind(pipeline, "id3Frame"));
          return pipeline;
        };
        var aacPipeline = function aacPipeline2(options) {
          var pipeline = {
            type: "aac",
            tracks: {
              audio: null
            },
            metadataStream: new m2ts.MetadataStream(),
            aacStream: new AacStream(),
            audioRollover: new m2ts.TimestampRolloverStream("audio"),
            timedMetadataRollover: new m2ts.TimestampRolloverStream("timed-metadata"),
            adtsStream: new AdtsStream(true)
          };
          pipeline.headOfPipeline = pipeline.aacStream;
          pipeline.aacStream.pipe(pipeline.audioRollover).pipe(pipeline.adtsStream);
          pipeline.aacStream.pipe(pipeline.timedMetadataRollover).pipe(pipeline.metadataStream);
          pipeline.metadataStream.on("timestamp", function(frame) {
            pipeline.aacStream.setTimestamp(frame.timeStamp);
          });
          pipeline.aacStream.on("data", function(data) {
            if (data.type !== "timed-metadata" && data.type !== "audio" || pipeline.audioSegmentStream) {
              return;
            }
            pipeline.tracks.audio = pipeline.tracks.audio || {
              timelineStartInfo: {
                baseMediaDecodeTime: options.baseMediaDecodeTime
              },
              codec: "adts",
              type: "audio"
            };
            pipeline.audioSegmentStream = new AudioSegmentStream(pipeline.tracks.audio, options);
            pipeline.audioSegmentStream.on("data", function(data2) {
              pipeline.trigger("data", {
                type: "audio",
                data: data2
              });
            });
            pipeline.audioSegmentStream.on("partialdone", pipeline.trigger.bind(pipeline, "partialdone"));
            pipeline.audioSegmentStream.on("done", pipeline.trigger.bind(pipeline, "done"));
            pipeline.audioSegmentStream.on("endedtimeline", pipeline.trigger.bind(pipeline, "endedtimeline"));
            pipeline.audioSegmentStream.on("timingInfo", pipeline.trigger.bind(pipeline, "audioTimingInfo"));
            pipeline.adtsStream.pipe(pipeline.audioSegmentStream);
            pipeline.trigger("trackinfo", {
              hasAudio: !!pipeline.tracks.audio,
              hasVideo: !!pipeline.tracks.video
            });
          });
          pipeline = createPipeline(pipeline);
          pipeline.metadataStream.on("data", pipeline.trigger.bind(pipeline, "id3Frame"));
          return pipeline;
        };
        var setupPipelineListeners = function setupPipelineListeners2(pipeline, transmuxer2) {
          pipeline.on("data", transmuxer2.trigger.bind(transmuxer2, "data"));
          pipeline.on("done", transmuxer2.trigger.bind(transmuxer2, "done"));
          pipeline.on("partialdone", transmuxer2.trigger.bind(transmuxer2, "partialdone"));
          pipeline.on("endedtimeline", transmuxer2.trigger.bind(transmuxer2, "endedtimeline"));
          pipeline.on("audioTimingInfo", transmuxer2.trigger.bind(transmuxer2, "audioTimingInfo"));
          pipeline.on("videoTimingInfo", transmuxer2.trigger.bind(transmuxer2, "videoTimingInfo"));
          pipeline.on("trackinfo", transmuxer2.trigger.bind(transmuxer2, "trackinfo"));
          pipeline.on("id3Frame", function(event) {
            event.dispatchType = pipeline.metadataStream.dispatchType;
            event.cueTime = clock.videoTsToSeconds(event.pts);
            transmuxer2.trigger("id3Frame", event);
          });
          pipeline.on("caption", function(event) {
            transmuxer2.trigger("caption", event);
          });
        };
        var Transmuxer = function Transmuxer2(options) {
          var pipeline = null, hasFlushed = true;
          options = options || {};
          Transmuxer2.prototype.init.call(this);
          options.baseMediaDecodeTime = options.baseMediaDecodeTime || 0;
          this.push = function(bytes) {
            if (hasFlushed) {
              var isAac = isLikelyAacData(bytes);
              if (isAac && (!pipeline || pipeline.type !== "aac")) {
                pipeline = aacPipeline(options);
                setupPipelineListeners(pipeline, this);
              } else if (!isAac && (!pipeline || pipeline.type !== "ts")) {
                pipeline = tsPipeline(options);
                setupPipelineListeners(pipeline, this);
              }
              hasFlushed = false;
            }
            pipeline.headOfPipeline.push(bytes);
          };
          this.flush = function() {
            if (!pipeline) {
              return;
            }
            hasFlushed = true;
            pipeline.headOfPipeline.flush();
          };
          this.partialFlush = function() {
            if (!pipeline) {
              return;
            }
            pipeline.headOfPipeline.partialFlush();
          };
          this.endTimeline = function() {
            if (!pipeline) {
              return;
            }
            pipeline.headOfPipeline.endTimeline();
          };
          this.reset = function() {
            if (!pipeline) {
              return;
            }
            pipeline.headOfPipeline.reset();
          };
          this.setBaseMediaDecodeTime = function(baseMediaDecodeTime) {
            if (!options.keepOriginalTimestamps) {
              options.baseMediaDecodeTime = baseMediaDecodeTime;
            }
            if (!pipeline) {
              return;
            }
            if (pipeline.tracks.audio) {
              pipeline.tracks.audio.timelineStartInfo.dts = void 0;
              pipeline.tracks.audio.timelineStartInfo.pts = void 0;
              trackInfo.clearDtsInfo(pipeline.tracks.audio);
              if (pipeline.audioRollover) {
                pipeline.audioRollover.discontinuity();
              }
            }
            if (pipeline.tracks.video) {
              if (pipeline.videoSegmentStream) {
                pipeline.videoSegmentStream.gopCache_ = [];
              }
              pipeline.tracks.video.timelineStartInfo.dts = void 0;
              pipeline.tracks.video.timelineStartInfo.pts = void 0;
              trackInfo.clearDtsInfo(pipeline.tracks.video);
            }
            if (pipeline.timestampRollover) {
              pipeline.timestampRollover.discontinuity();
            }
          };
          this.setRemux = function(val) {
            options.remux = val;
            if (pipeline && pipeline.coalesceStream) {
              pipeline.coalesceStream.setRemux(val);
            }
          };
          this.setAudioAppendStart = function(audioAppendStart) {
            if (!pipeline || !pipeline.tracks.audio || !pipeline.audioSegmentStream) {
              return;
            }
            pipeline.audioSegmentStream.setAudioAppendStart(audioAppendStart);
          };
          this.alignGopsWith = function(gopsToAlignWith) {
            return;
          };
        };
        Transmuxer.prototype = new Stream();
        var transmuxer = Transmuxer;
        var partial = {
          Transmuxer: transmuxer
        };
        var tagTypes = {
          8: "audio",
          9: "video",
          18: "metadata"
        }, hex = function hex2(val) {
          return "0x" + ("00" + val.toString(16)).slice(-2).toUpperCase();
        }, hexStringList = function hexStringList2(data) {
          var arr = [], i;
          while (data.byteLength > 0) {
            i = 0;
            arr.push(hex(data[i++]));
            data = data.subarray(i);
          }
          return arr.join(" ");
        }, parseAVCTag = function parseAVCTag2(tag, obj) {
          var avcPacketTypes = ["AVC Sequence Header", "AVC NALU", "AVC End-of-Sequence"], compositionTime = tag[1] & parseInt("01111111", 2) << 16 | tag[2] << 8 | tag[3];
          obj = obj || {};
          obj.avcPacketType = avcPacketTypes[tag[0]];
          obj.CompositionTime = tag[1] & parseInt("10000000", 2) ? -compositionTime : compositionTime;
          if (tag[0] === 1) {
            obj.nalUnitTypeRaw = hexStringList(tag.subarray(4, 100));
          } else {
            obj.data = hexStringList(tag.subarray(4));
          }
          return obj;
        }, parseVideoTag = function parseVideoTag2(tag, obj) {
          var frameTypes = ["Unknown", "Keyframe (for AVC, a seekable frame)", "Inter frame (for AVC, a nonseekable frame)", "Disposable inter frame (H.263 only)", "Generated keyframe (reserved for server use only)", "Video info/command frame"], codecID = tag[0] & parseInt("00001111", 2);
          obj = obj || {};
          obj.frameType = frameTypes[(tag[0] & parseInt("11110000", 2)) >>> 4];
          obj.codecID = codecID;
          if (codecID === 7) {
            return parseAVCTag(tag.subarray(1), obj);
          }
          return obj;
        }, parseAACTag = function parseAACTag2(tag, obj) {
          var packetTypes = ["AAC Sequence Header", "AAC Raw"];
          obj = obj || {};
          obj.aacPacketType = packetTypes[tag[0]];
          obj.data = hexStringList(tag.subarray(1));
          return obj;
        }, parseAudioTag = function parseAudioTag2(tag, obj) {
          var formatTable = ["Linear PCM, platform endian", "ADPCM", "MP3", "Linear PCM, little endian", "Nellymoser 16-kHz mono", "Nellymoser 8-kHz mono", "Nellymoser", "G.711 A-law logarithmic PCM", "G.711 mu-law logarithmic PCM", "reserved", "AAC", "Speex", "MP3 8-Khz", "Device-specific sound"], samplingRateTable = ["5.5-kHz", "11-kHz", "22-kHz", "44-kHz"], soundFormat = (tag[0] & parseInt("11110000", 2)) >>> 4;
          obj = obj || {};
          obj.soundFormat = formatTable[soundFormat];
          obj.soundRate = samplingRateTable[(tag[0] & parseInt("00001100", 2)) >>> 2];
          obj.soundSize = (tag[0] & parseInt("00000010", 2)) >>> 1 ? "16-bit" : "8-bit";
          obj.soundType = tag[0] & parseInt("00000001", 2) ? "Stereo" : "Mono";
          if (soundFormat === 10) {
            return parseAACTag(tag.subarray(1), obj);
          }
          return obj;
        }, parseGenericTag = function parseGenericTag2(tag) {
          return {
            tagType: tagTypes[tag[0]],
            dataSize: tag[1] << 16 | tag[2] << 8 | tag[3],
            timestamp: tag[7] << 24 | tag[4] << 16 | tag[5] << 8 | tag[6],
            streamID: tag[8] << 16 | tag[9] << 8 | tag[10]
          };
        }, inspectFlvTag = function inspectFlvTag2(tag) {
          var header = parseGenericTag(tag);
          switch (tag[0]) {
            case 8:
              parseAudioTag(tag.subarray(11), header);
              break;
            case 9:
              parseVideoTag(tag.subarray(11), header);
              break;
          }
          return header;
        }, inspectFlv = function inspectFlv2(bytes) {
          var i = 9, dataSize, parsedResults = [], tag;
          i += 4;
          while (i < bytes.byteLength) {
            dataSize = bytes[i + 1] << 16;
            dataSize |= bytes[i + 2] << 8;
            dataSize |= bytes[i + 3];
            dataSize += 11;
            tag = bytes.subarray(i, i + dataSize);
            parsedResults.push(inspectFlvTag(tag));
            i += dataSize + 4;
          }
          return parsedResults;
        }, textifyFlv = function textifyFlv2(flvTagArray) {
          return JSON.stringify(flvTagArray, null, 2);
        };
        var flvInspector = {
          inspectTag: inspectFlvTag,
          inspect: inspectFlv,
          textify: textifyFlv
        };
        var StreamTypes$1 = streamTypes;
        var parsePid = function parsePid2(packet) {
          var pid = packet[1] & 31;
          pid <<= 8;
          pid |= packet[2];
          return pid;
        };
        var parsePayloadUnitStartIndicator = function parsePayloadUnitStartIndicator2(packet) {
          return !!(packet[1] & 64);
        };
        var parseAdaptionField = function parseAdaptionField2(packet) {
          var offset = 0;
          if ((packet[3] & 48) >>> 4 > 1) {
            offset += packet[4] + 1;
          }
          return offset;
        };
        var parseType = function parseType2(packet, pmtPid) {
          var pid = parsePid(packet);
          if (pid === 0) {
            return "pat";
          } else if (pid === pmtPid) {
            return "pmt";
          } else if (pmtPid) {
            return "pes";
          }
          return null;
        };
        var parsePat = function parsePat2(packet) {
          var pusi = parsePayloadUnitStartIndicator(packet);
          var offset = 4 + parseAdaptionField(packet);
          if (pusi) {
            offset += packet[offset] + 1;
          }
          return (packet[offset + 10] & 31) << 8 | packet[offset + 11];
        };
        var parsePmt = function parsePmt2(packet) {
          var programMapTable = {};
          var pusi = parsePayloadUnitStartIndicator(packet);
          var payloadOffset = 4 + parseAdaptionField(packet);
          if (pusi) {
            payloadOffset += packet[payloadOffset] + 1;
          }
          if (!(packet[payloadOffset + 5] & 1)) {
            return;
          }
          var sectionLength, tableEnd, programInfoLength;
          sectionLength = (packet[payloadOffset + 1] & 15) << 8 | packet[payloadOffset + 2];
          tableEnd = 3 + sectionLength - 4;
          programInfoLength = (packet[payloadOffset + 10] & 15) << 8 | packet[payloadOffset + 11];
          var offset = 12 + programInfoLength;
          while (offset < tableEnd) {
            var i = payloadOffset + offset;
            programMapTable[(packet[i + 1] & 31) << 8 | packet[i + 2]] = packet[i];
            offset += ((packet[i + 3] & 15) << 8 | packet[i + 4]) + 5;
          }
          return programMapTable;
        };
        var parsePesType = function parsePesType2(packet, programMapTable) {
          var pid = parsePid(packet);
          var type2 = programMapTable[pid];
          switch (type2) {
            case StreamTypes$1.H264_STREAM_TYPE:
              return "video";
            case StreamTypes$1.ADTS_STREAM_TYPE:
              return "audio";
            case StreamTypes$1.METADATA_STREAM_TYPE:
              return "timed-metadata";
            default:
              return null;
          }
        };
        var parsePesTime = function parsePesTime2(packet) {
          var pusi = parsePayloadUnitStartIndicator(packet);
          if (!pusi) {
            return null;
          }
          var offset = 4 + parseAdaptionField(packet);
          if (offset >= packet.byteLength) {
            return null;
          }
          var pes = null;
          var ptsDtsFlags;
          ptsDtsFlags = packet[offset + 7];
          if (ptsDtsFlags & 192) {
            pes = {};
            pes.pts = (packet[offset + 9] & 14) << 27 | (packet[offset + 10] & 255) << 20 | (packet[offset + 11] & 254) << 12 | (packet[offset + 12] & 255) << 5 | (packet[offset + 13] & 254) >>> 3;
            pes.pts *= 4;
            pes.pts += (packet[offset + 13] & 6) >>> 1;
            pes.dts = pes.pts;
            if (ptsDtsFlags & 64) {
              pes.dts = (packet[offset + 14] & 14) << 27 | (packet[offset + 15] & 255) << 20 | (packet[offset + 16] & 254) << 12 | (packet[offset + 17] & 255) << 5 | (packet[offset + 18] & 254) >>> 3;
              pes.dts *= 4;
              pes.dts += (packet[offset + 18] & 6) >>> 1;
            }
          }
          return pes;
        };
        var parseNalUnitType = function parseNalUnitType2(type2) {
          switch (type2) {
            case 5:
              return "slice_layer_without_partitioning_rbsp_idr";
            case 6:
              return "sei_rbsp";
            case 7:
              return "seq_parameter_set_rbsp";
            case 8:
              return "pic_parameter_set_rbsp";
            case 9:
              return "access_unit_delimiter_rbsp";
            default:
              return null;
          }
        };
        var videoPacketContainsKeyFrame = function videoPacketContainsKeyFrame2(packet) {
          var offset = 4 + parseAdaptionField(packet);
          var frameBuffer = packet.subarray(offset);
          var frameI = 0;
          var frameSyncPoint = 0;
          var foundKeyFrame = false;
          var nalType;
          for (; frameSyncPoint < frameBuffer.byteLength - 3; frameSyncPoint++) {
            if (frameBuffer[frameSyncPoint + 2] === 1) {
              frameI = frameSyncPoint + 5;
              break;
            }
          }
          while (frameI < frameBuffer.byteLength) {
            switch (frameBuffer[frameI]) {
              case 0:
                if (frameBuffer[frameI - 1] !== 0) {
                  frameI += 2;
                  break;
                } else if (frameBuffer[frameI - 2] !== 0) {
                  frameI++;
                  break;
                }
                if (frameSyncPoint + 3 !== frameI - 2) {
                  nalType = parseNalUnitType(frameBuffer[frameSyncPoint + 3] & 31);
                  if (nalType === "slice_layer_without_partitioning_rbsp_idr") {
                    foundKeyFrame = true;
                  }
                }
                do {
                  frameI++;
                } while (frameBuffer[frameI] !== 1 && frameI < frameBuffer.length);
                frameSyncPoint = frameI - 2;
                frameI += 3;
                break;
              case 1:
                if (frameBuffer[frameI - 1] !== 0 || frameBuffer[frameI - 2] !== 0) {
                  frameI += 3;
                  break;
                }
                nalType = parseNalUnitType(frameBuffer[frameSyncPoint + 3] & 31);
                if (nalType === "slice_layer_without_partitioning_rbsp_idr") {
                  foundKeyFrame = true;
                }
                frameSyncPoint = frameI - 2;
                frameI += 3;
                break;
              default:
                frameI += 3;
                break;
            }
          }
          frameBuffer = frameBuffer.subarray(frameSyncPoint);
          frameI -= frameSyncPoint;
          frameSyncPoint = 0;
          if (frameBuffer && frameBuffer.byteLength > 3) {
            nalType = parseNalUnitType(frameBuffer[frameSyncPoint + 3] & 31);
            if (nalType === "slice_layer_without_partitioning_rbsp_idr") {
              foundKeyFrame = true;
            }
          }
          return foundKeyFrame;
        };
        var probe$1 = {
          parseType,
          parsePat,
          parsePmt,
          parsePayloadUnitStartIndicator,
          parsePesType,
          parsePesTime,
          videoPacketContainsKeyFrame
        };
        var StreamTypes = streamTypes;
        var handleRollover = timestampRolloverStream.handleRollover;
        var probe = {};
        probe.ts = probe$1;
        probe.aac = utils;
        var ONE_SECOND_IN_TS = clock$3.ONE_SECOND_IN_TS;
        var MP2T_PACKET_LENGTH = 188, SYNC_BYTE = 71;
        var parsePsi_ = function parsePsi_2(bytes, pmt) {
          var startIndex = 0, endIndex = MP2T_PACKET_LENGTH, packet, type2;
          while (endIndex < bytes.byteLength) {
            if (bytes[startIndex] === SYNC_BYTE && bytes[endIndex] === SYNC_BYTE) {
              packet = bytes.subarray(startIndex, endIndex);
              type2 = probe.ts.parseType(packet, pmt.pid);
              switch (type2) {
                case "pat":
                  pmt.pid = probe.ts.parsePat(packet);
                  break;
                case "pmt":
                  var table = probe.ts.parsePmt(packet);
                  pmt.table = pmt.table || {};
                  Object.keys(table).forEach(function(key) {
                    pmt.table[key] = table[key];
                  });
                  break;
              }
              startIndex += MP2T_PACKET_LENGTH;
              endIndex += MP2T_PACKET_LENGTH;
              continue;
            }
            startIndex++;
            endIndex++;
          }
        };
        var parseAudioPes_ = function parseAudioPes_2(bytes, pmt, result) {
          var startIndex = 0, endIndex = MP2T_PACKET_LENGTH, packet, type2, pesType, pusi, parsed;
          var endLoop = false;
          while (endIndex <= bytes.byteLength) {
            if (bytes[startIndex] === SYNC_BYTE && (bytes[endIndex] === SYNC_BYTE || endIndex === bytes.byteLength)) {
              packet = bytes.subarray(startIndex, endIndex);
              type2 = probe.ts.parseType(packet, pmt.pid);
              switch (type2) {
                case "pes":
                  pesType = probe.ts.parsePesType(packet, pmt.table);
                  pusi = probe.ts.parsePayloadUnitStartIndicator(packet);
                  if (pesType === "audio" && pusi) {
                    parsed = probe.ts.parsePesTime(packet);
                    if (parsed) {
                      parsed.type = "audio";
                      result.audio.push(parsed);
                      endLoop = true;
                    }
                  }
                  break;
              }
              if (endLoop) {
                break;
              }
              startIndex += MP2T_PACKET_LENGTH;
              endIndex += MP2T_PACKET_LENGTH;
              continue;
            }
            startIndex++;
            endIndex++;
          }
          endIndex = bytes.byteLength;
          startIndex = endIndex - MP2T_PACKET_LENGTH;
          endLoop = false;
          while (startIndex >= 0) {
            if (bytes[startIndex] === SYNC_BYTE && (bytes[endIndex] === SYNC_BYTE || endIndex === bytes.byteLength)) {
              packet = bytes.subarray(startIndex, endIndex);
              type2 = probe.ts.parseType(packet, pmt.pid);
              switch (type2) {
                case "pes":
                  pesType = probe.ts.parsePesType(packet, pmt.table);
                  pusi = probe.ts.parsePayloadUnitStartIndicator(packet);
                  if (pesType === "audio" && pusi) {
                    parsed = probe.ts.parsePesTime(packet);
                    if (parsed) {
                      parsed.type = "audio";
                      result.audio.push(parsed);
                      endLoop = true;
                    }
                  }
                  break;
              }
              if (endLoop) {
                break;
              }
              startIndex -= MP2T_PACKET_LENGTH;
              endIndex -= MP2T_PACKET_LENGTH;
              continue;
            }
            startIndex--;
            endIndex--;
          }
        };
        var parseVideoPes_ = function parseVideoPes_2(bytes, pmt, result) {
          var startIndex = 0, endIndex = MP2T_PACKET_LENGTH, packet, type2, pesType, pusi, parsed, frame, i, pes;
          var endLoop = false;
          var currentFrame = {
            data: [],
            size: 0
          };
          while (endIndex < bytes.byteLength) {
            if (bytes[startIndex] === SYNC_BYTE && bytes[endIndex] === SYNC_BYTE) {
              packet = bytes.subarray(startIndex, endIndex);
              type2 = probe.ts.parseType(packet, pmt.pid);
              switch (type2) {
                case "pes":
                  pesType = probe.ts.parsePesType(packet, pmt.table);
                  pusi = probe.ts.parsePayloadUnitStartIndicator(packet);
                  if (pesType === "video") {
                    if (pusi && !endLoop) {
                      parsed = probe.ts.parsePesTime(packet);
                      if (parsed) {
                        parsed.type = "video";
                        result.video.push(parsed);
                        endLoop = true;
                      }
                    }
                    if (!result.firstKeyFrame) {
                      if (pusi) {
                        if (currentFrame.size !== 0) {
                          frame = new Uint8Array(currentFrame.size);
                          i = 0;
                          while (currentFrame.data.length) {
                            pes = currentFrame.data.shift();
                            frame.set(pes, i);
                            i += pes.byteLength;
                          }
                          if (probe.ts.videoPacketContainsKeyFrame(frame)) {
                            var firstKeyFrame = probe.ts.parsePesTime(frame);
                            if (firstKeyFrame) {
                              result.firstKeyFrame = firstKeyFrame;
                              result.firstKeyFrame.type = "video";
                            } else {
                              console.warn("Failed to extract PTS/DTS from PES at first keyframe. This could be an unusual TS segment, or else mux.js did not parse your TS segment correctly. If you know your TS segments do contain PTS/DTS on keyframes please file a bug report! You can try ffprobe to double check for yourself.");
                            }
                          }
                          currentFrame.size = 0;
                        }
                      }
                      currentFrame.data.push(packet);
                      currentFrame.size += packet.byteLength;
                    }
                  }
                  break;
              }
              if (endLoop && result.firstKeyFrame) {
                break;
              }
              startIndex += MP2T_PACKET_LENGTH;
              endIndex += MP2T_PACKET_LENGTH;
              continue;
            }
            startIndex++;
            endIndex++;
          }
          endIndex = bytes.byteLength;
          startIndex = endIndex - MP2T_PACKET_LENGTH;
          endLoop = false;
          while (startIndex >= 0) {
            if (bytes[startIndex] === SYNC_BYTE && bytes[endIndex] === SYNC_BYTE) {
              packet = bytes.subarray(startIndex, endIndex);
              type2 = probe.ts.parseType(packet, pmt.pid);
              switch (type2) {
                case "pes":
                  pesType = probe.ts.parsePesType(packet, pmt.table);
                  pusi = probe.ts.parsePayloadUnitStartIndicator(packet);
                  if (pesType === "video" && pusi) {
                    parsed = probe.ts.parsePesTime(packet);
                    if (parsed) {
                      parsed.type = "video";
                      result.video.push(parsed);
                      endLoop = true;
                    }
                  }
                  break;
              }
              if (endLoop) {
                break;
              }
              startIndex -= MP2T_PACKET_LENGTH;
              endIndex -= MP2T_PACKET_LENGTH;
              continue;
            }
            startIndex--;
            endIndex--;
          }
        };
        var adjustTimestamp_ = function adjustTimestamp_2(segmentInfo, baseTimestamp) {
          if (segmentInfo.audio && segmentInfo.audio.length) {
            var audioBaseTimestamp = baseTimestamp;
            if (typeof audioBaseTimestamp === "undefined" || isNaN(audioBaseTimestamp)) {
              audioBaseTimestamp = segmentInfo.audio[0].dts;
            }
            segmentInfo.audio.forEach(function(info) {
              info.dts = handleRollover(info.dts, audioBaseTimestamp);
              info.pts = handleRollover(info.pts, audioBaseTimestamp);
              info.dtsTime = info.dts / ONE_SECOND_IN_TS;
              info.ptsTime = info.pts / ONE_SECOND_IN_TS;
            });
          }
          if (segmentInfo.video && segmentInfo.video.length) {
            var videoBaseTimestamp = baseTimestamp;
            if (typeof videoBaseTimestamp === "undefined" || isNaN(videoBaseTimestamp)) {
              videoBaseTimestamp = segmentInfo.video[0].dts;
            }
            segmentInfo.video.forEach(function(info) {
              info.dts = handleRollover(info.dts, videoBaseTimestamp);
              info.pts = handleRollover(info.pts, videoBaseTimestamp);
              info.dtsTime = info.dts / ONE_SECOND_IN_TS;
              info.ptsTime = info.pts / ONE_SECOND_IN_TS;
            });
            if (segmentInfo.firstKeyFrame) {
              var frame = segmentInfo.firstKeyFrame;
              frame.dts = handleRollover(frame.dts, videoBaseTimestamp);
              frame.pts = handleRollover(frame.pts, videoBaseTimestamp);
              frame.dtsTime = frame.dts / ONE_SECOND_IN_TS;
              frame.ptsTime = frame.pts / ONE_SECOND_IN_TS;
            }
          }
        };
        var inspectAac_ = function inspectAac_2(bytes) {
          var endLoop = false, audioCount = 0, sampleRate = null, timestamp = null, frameSize = 0, byteIndex = 0, packet;
          while (bytes.length - byteIndex >= 3) {
            var type2 = probe.aac.parseType(bytes, byteIndex);
            switch (type2) {
              case "timed-metadata":
                if (bytes.length - byteIndex < 10) {
                  endLoop = true;
                  break;
                }
                frameSize = probe.aac.parseId3TagSize(bytes, byteIndex);
                if (frameSize > bytes.length) {
                  endLoop = true;
                  break;
                }
                if (timestamp === null) {
                  packet = bytes.subarray(byteIndex, byteIndex + frameSize);
                  timestamp = probe.aac.parseAacTimestamp(packet);
                }
                byteIndex += frameSize;
                break;
              case "audio":
                if (bytes.length - byteIndex < 7) {
                  endLoop = true;
                  break;
                }
                frameSize = probe.aac.parseAdtsSize(bytes, byteIndex);
                if (frameSize > bytes.length) {
                  endLoop = true;
                  break;
                }
                if (sampleRate === null) {
                  packet = bytes.subarray(byteIndex, byteIndex + frameSize);
                  sampleRate = probe.aac.parseSampleRate(packet);
                }
                audioCount++;
                byteIndex += frameSize;
                break;
              default:
                byteIndex++;
                break;
            }
            if (endLoop) {
              return null;
            }
          }
          if (sampleRate === null || timestamp === null) {
            return null;
          }
          var audioTimescale = ONE_SECOND_IN_TS / sampleRate;
          var result = {
            audio: [{
              type: "audio",
              dts: timestamp,
              pts: timestamp
            }, {
              type: "audio",
              dts: timestamp + audioCount * 1024 * audioTimescale,
              pts: timestamp + audioCount * 1024 * audioTimescale
            }]
          };
          return result;
        };
        var inspectTs_ = function inspectTs_2(bytes) {
          var pmt = {
            pid: null,
            table: null
          };
          var result = {};
          parsePsi_(bytes, pmt);
          for (var pid in pmt.table) {
            if (pmt.table.hasOwnProperty(pid)) {
              var type2 = pmt.table[pid];
              switch (type2) {
                case StreamTypes.H264_STREAM_TYPE:
                  result.video = [];
                  parseVideoPes_(bytes, pmt, result);
                  if (result.video.length === 0) {
                    delete result.video;
                  }
                  break;
                case StreamTypes.ADTS_STREAM_TYPE:
                  result.audio = [];
                  parseAudioPes_(bytes, pmt, result);
                  if (result.audio.length === 0) {
                    delete result.audio;
                  }
                  break;
              }
            }
          }
          return result;
        };
        var inspect = function inspect2(bytes, baseTimestamp) {
          var isAacData = probe.aac.isLikelyAacData(bytes);
          var result;
          if (isAacData) {
            result = inspectAac_(bytes);
          } else {
            result = inspectTs_(bytes);
          }
          if (!result || !result.audio && !result.video) {
            return null;
          }
          adjustTimestamp_(result, baseTimestamp);
          return result;
        };
        var tsInspector = {
          inspect,
          parseAudioPes_
        };
        var muxjs = {
          codecs: codecs$1,
          mp4: mp4$2,
          flv,
          mp2t: m2ts$1,
          partial
        };
        muxjs.mp4.tools = mp4Inspector;
        muxjs.flv.tools = flvInspector;
        muxjs.mp2t.tools = tsInspector;
        var lib = muxjs;
        return lib;
      }));
    }
  });

  // src/core/mp4.js
  function* boxes(buf, start = 0, end = buf.length) {
    let p = start;
    while (p + 8 <= end) {
      let size = u32(buf, p), hdr2 = 8;
      const type = fourcc(buf, p + 4);
      if (size === 1) {
        size = u64(buf, p + 8);
        hdr2 = 16;
      } else if (size === 0) size = end - p;
      if (size < hdr2) return;
      yield { type, start: p, hdr: hdr2, size: Math.min(size, end - p), dataStart: p + hdr2, end: Math.min(p + size, end) };
      p += size;
    }
  }
  function cat(parts) {
    const arrs = parts.map((p) => p instanceof Uint8Array ? p : Uint8Array.from(p));
    const out = new Uint8Array(arrs.reduce((s, a) => s + a.length, 0));
    let o = 0;
    for (const a of arrs) {
      out.set(a, o);
      o += a.length;
    }
    return out;
  }
  function u32s(arr) {
    const o = new Uint8Array(arr.length * 4);
    const dv = new DataView(o.buffer);
    for (let i = 0; i < arr.length; i++) dv.setUint32(i * 4, arr[i] >>> 0);
    return o;
  }
  function u64s(arr) {
    const o = new Uint8Array(arr.length * 8);
    const dv = new DataView(o.buffer);
    for (let i = 0; i < arr.length; i++) {
      dv.setUint32(i * 8, Math.floor(arr[i] / 4294967296));
      dv.setUint32(i * 8 + 4, arr[i] >>> 0);
    }
    return o;
  }
  function splitFragmented(bytes) {
    let moovEnd = -1, hasMoof = false;
    for (const b of boxes(bytes)) {
      if (b.type === "moov") moovEnd = b.end;
      if (b.type === "moof") {
        hasMoof = true;
        break;
      }
    }
    if (moovEnd < 0) throw new Error("MP4 without moov box");
    if (!hasMoof) throw new Error("MP4 is not fragmented (no moof) \u2013 unsupported source layout");
    return { init: bytes.subarray(0, moovEnd), media: bytes.subarray(moovEnd), mediaOffset: moovEnd };
  }
  function parseInit(init) {
    const moov = [...boxes(init)].find((b) => b.type === "moov");
    if (!moov) throw new Error("init segment has no moov");
    const trex = /* @__PURE__ */ new Map();
    const mvex = child(init, moov, "mvex");
    if (mvex) for (const t of children(init, mvex, "trex")) {
      const d = t.dataStart;
      trex.set(u32(init, d + 4), { descIdx: u32(init, d + 8), dur: u32(init, d + 12), size: u32(init, d + 16), flags: u32(init, d + 20) });
    }
    const tracks = /* @__PURE__ */ new Map();
    for (const trak of children(init, moov, "trak")) {
      const tkhd = child(init, trak, "tkhd"), mdia = child(init, trak, "mdia");
      if (!tkhd || !mdia) continue;
      const v = init[tkhd.dataStart], base = tkhd.dataStart + 4, sh = v === 1 ? 8 : 0;
      const id = u32(init, base + 8 + sh);
      const mdhd = child(init, mdia, "mdhd"), hdlr = child(init, mdia, "hdlr"), minf = child(init, mdia, "minf");
      if (!mdhd || !hdlr || !minf) continue;
      const mv = init[mdhd.dataStart], mb = mdhd.dataStart + 4;
      const timescale = u32(init, mb + (mv === 1 ? 16 : 8));
      const lang = u16(init, mb + (mv === 1 ? 28 : 16));
      const handler = fourcc(init, hdlr.dataStart + 8);
      if (handler !== "vide" && handler !== "soun") continue;
      const stbl = child(init, minf, "stbl");
      const stsd = stbl && child(init, stbl, "stsd");
      if (!stsd) continue;
      const raw = (b) => b ? init.slice(b.start, b.end) : null;
      tracks.set(id, {
        srcId: id,
        handler,
        timescale,
        lang,
        width: u32(init, base + 72 + sh),
        height: u32(init, base + 76 + sh),
        hdlr: raw(hdlr),
        stsd: raw(stsd),
        dinf: raw(child(init, minf, "dinf")),
        mhd: raw(child(init, minf, "vmhd")) || raw(child(init, minf, "smhd")),
        trex: trex.get(id) || { descIdx: 1, dur: 0, size: 0, flags: 0 },
        samples: [],
        firstDts: null,
        nextDts: 0
      });
    }
    if (!tracks.size) throw new Error("no audio/video track found in init segment");
    return tracks;
  }
  async function parseChunk(chunk, chunkIdx, tracks, absStart) {
    const total = chunkSize(chunk);
    let p = 0;
    while (p + 8 <= total) {
      const head = await chunkRead(chunk, p, Math.min(p + 16, total));
      let size = u32(head, 0);
      const type = fourcc(head, 4);
      if (size === 1) size = u64(head, 8);
      else if (size === 0) size = total - p;
      if (size < 8) break;
      if (type === "moof") parseMoof(await chunkRead(chunk, p, Math.min(p + size, total)), p, chunkIdx, tracks, absStart);
      p += size;
    }
  }
  function parseMoof(buf, shift, chunkIdx, tracks, absStart) {
    for (const moof of boxes(buf)) {
      if (moof.type !== "moof") continue;
      for (const traf of children(buf, moof, "traf")) {
        const tfhd = child(buf, traf, "tfhd");
        if (!tfhd) continue;
        const tf = buf[tfhd.dataStart + 1] << 16 | buf[tfhd.dataStart + 2] << 8 | buf[tfhd.dataStart + 3];
        let p = tfhd.dataStart + 4;
        const trackId = u32(buf, p);
        p += 4;
        const track = tracks.get(trackId);
        if (!track) continue;
        let baseOff = shift;
        if (tf & 1) {
          baseOff = u64(buf, p) - absStart;
          p += 8;
        }
        if (tf & 2) p += 4;
        let defDur = track.trex.dur, defSize = track.trex.size, defFlags = track.trex.flags;
        if (tf & 8) {
          defDur = u32(buf, p);
          p += 4;
        }
        if (tf & 16) {
          defSize = u32(buf, p);
          p += 4;
        }
        if (tf & 32) {
          defFlags = u32(buf, p);
          p += 4;
        }
        const tfdt = child(buf, traf, "tfdt");
        if (tfdt) {
          const v = buf[tfdt.dataStart];
          const t = v === 1 ? u64(buf, tfdt.dataStart + 4) : u32(buf, tfdt.dataStart + 4);
          if (track.firstDts === null) track.firstDts = t;
        } else if (track.firstDts === null) track.firstDts = 0;
        let cursor = baseOff;
        for (const trun of children(buf, traf, "trun")) {
          const ver = buf[trun.dataStart];
          const fl = buf[trun.dataStart + 1] << 16 | buf[trun.dataStart + 2] << 8 | buf[trun.dataStart + 3];
          let q = trun.dataStart + 4;
          const count = u32(buf, q);
          q += 4;
          if (fl & 1) {
            cursor = baseOff + i32(buf, q);
            q += 4;
          }
          let firstFlags = null;
          if (fl & 4) {
            firstFlags = u32(buf, q);
            q += 4;
          }
          for (let i = 0; i < count; i++) {
            let dur = defDur, size = defSize, flags = defFlags, cto = 0;
            if (fl & 256) {
              dur = u32(buf, q);
              q += 4;
            }
            if (fl & 512) {
              size = u32(buf, q);
              q += 4;
            }
            if (fl & 1024) {
              flags = u32(buf, q);
              q += 4;
            } else if (i === 0 && firstFlags !== null) flags = firstFlags;
            if (fl & 2048) {
              cto = ver === 1 ? i32(buf, q) : u32(buf, q);
              q += 4;
            }
            track.samples.push({ c: chunkIdx, o: cursor, s: size, d: dur, f: flags, t: cto });
            cursor += size;
          }
        }
      }
    }
  }
  async function buildMp4(sources, { force64 = false } = {}) {
    const all = [];
    const chunkStore = [];
    for (const src of sources) {
      const tracks = parseInit(src.init);
      for (const c of src.chunks) {
        const idx = chunkStore.push(c) - 1;
        await parseChunk(c, idx, tracks, src.absStart || 0);
      }
      for (const t of tracks.values()) if (t.samples.length) all.push(t);
    }
    if (!all.length) throw new Error("No media samples found");
    all.sort((a, b) => (a.handler === "vide" ? 0 : 1) - (b.handler === "vide" ? 0 : 1));
    const MT = 1e3;
    for (const t of all) {
      t.firstCto = t.samples[0].t;
      t.ptsStart = ((t.firstDts || 0) + t.firstCto) / t.timescale;
      let dts = 0, maxEnd = 0;
      for (const x of t.samples) {
        maxEnd = Math.max(maxEnd, dts + x.t + x.d);
        dts += x.d;
      }
      t.mediaDur = dts;
      t.presEnd = maxEnd;
    }
    const origin2 = Math.min(...all.map((t) => t.ptsStart));
    all.forEach((t, i) => {
      t.id = i + 1;
      t.delay = t.ptsStart - origin2;
      t.editDur = Math.round((t.presEnd - t.firstCto) / t.timescale * MT);
      t.movieDur = Math.round(t.delay * MT) + t.editDur;
      t.chunks = [];
      let cur = null;
      t.samples.forEach((s, i2) => {
        if (!cur || cur.dur >= t.timescale) {
          cur = { track: t, first: i2, n: 0, dur: 0, startSec: 0 };
          t.chunks.push(cur);
        }
        cur.n++;
        cur.dur += s.d;
      });
      let acc = 0;
      for (const c of t.chunks) {
        c.startSec = acc / t.timescale + t.delay;
        for (let k = c.first; k < c.first + c.n; k++) acc += t.samples[k].d;
      }
    });
    const order = all.flatMap((t) => t.chunks).sort((a, b) => a.startSec - b.startSec || a.track.id - b.track.id);
    const ftyp = box("ftyp", [..."isom"].map((c) => c.charCodeAt(0)), be32(512), [..."isomiso2avc1mp41"].map((c) => c.charCodeAt(0)));
    const movieDur = Math.max(...all.map((t) => t.movieDur));
    const totalBytes = all.reduce((a, t) => a + t.samples.reduce((x, y) => x + y.s, 0), 0);
    const use64 = force64 || totalBytes > 4294967295 - 256 * 1024 * 1024;
    const mdatHdr = use64 ? 16 : 8;
    const buildMoov = (mdatStart2) => {
      let off = mdatStart2;
      for (const c of order) {
        c.offset = off;
        for (let k = c.first; k < c.first + c.n; k++) off += c.track.samples[k].s;
      }
      const traks = all.map((t) => {
        const sm = t.samples, isV = t.handler === "vide";
        const sttsRuns = rle(sm.map((s) => s.d));
        const sttsB = full("stts", 0, 0, be32(sttsRuns.length), u32s(sttsRuns.flat()));
        const hasCto = sm.some((s) => s.t !== 0);
        const signed = sm.some((s) => s.t < 0 || s.t > 2147483647);
        const cttsRuns = rle(sm.map((s) => s.t));
        const cttsB = hasCto ? full("ctts", signed ? 1 : 0, 0, be32(cttsRuns.length), u32s(cttsRuns.flat())) : null;
        const syncIdx = [];
        sm.forEach((s, i) => {
          if (!(s.f & 65536)) syncIdx.push(i + 1);
        });
        const stssB = isV && syncIdx.length < sm.length ? full("stss", 0, 0, be32(syncIdx.length), u32s(syncIdx)) : null;
        const stszB = full("stsz", 0, 0, be32(0), be32(sm.length), u32s(sm.map((x) => x.s)));
        const scRuns = rle(t.chunks.map((c) => c.n));
        let fc = 1;
        const scEntries = [];
        for (const [n, spc] of scRuns) {
          scEntries.push([fc, spc]);
          fc += n;
        }
        const stscB = full("stsc", 0, 0, be32(scEntries.length), u32s(scEntries.flatMap(([f, n]) => [f, n, 1])));
        const stcoB = use64 ? full("co64", 0, 0, be32(t.chunks.length), u64s(t.chunks.map((c) => c.offset))) : full("stco", 0, 0, be32(t.chunks.length), u32s(t.chunks.map((c) => c.offset)));
        const stbl = box("stbl", t.stsd, sttsB, ...cttsB ? [cttsB] : [], ...stssB ? [stssB] : [], stscB, stszB, stcoB);
        const dinf = t.dinf || box("dinf", full("dref", 0, 0, be32(1), full("url ", 0, 1)));
        const mhd = t.mhd || (isV ? full("vmhd", 0, 1, [0, 0, 0, 0, 0, 0, 0, 0]) : full("smhd", 0, 0, [0, 0, 0, 0]));
        const mdhd = full("mdhd", 0, 0, be32(0), be32(0), be32(t.timescale), be32(t.mediaDur), be16(t.lang), be16(0));
        const mdia = box("mdia", mdhd, t.hdlr, box("minf", mhd, dinf, stbl));
        const tkhd = full(
          "tkhd",
          0,
          3,
          be32(0),
          be32(0),
          be32(t.id),
          be32(0),
          be32(t.movieDur),
          [0, 0, 0, 0, 0, 0, 0, 0],
          be16(0),
          be16(0),
          be16(isV ? 0 : 256),
          be16(0),
          MATRIX,
          be32(isV ? t.width : 0),
          be32(isV ? t.height : 0)
        );
        const elstEntries = [];
        if (t.delay * MT >= 1) elstEntries.push([be32(Math.round(t.delay * MT)), be32(4294967295), be32(65536)]);
        elstEntries.push([be32(t.editDur), be32(t.firstCto), be32(65536)]);
        const edts = box("edts", full("elst", 0, 0, be32(elstEntries.length), ...elstEntries.flat()));
        return box("trak", tkhd, edts, mdia);
      });
      const mvhd = full(
        "mvhd",
        0,
        0,
        be32(0),
        be32(0),
        be32(MT),
        be32(movieDur),
        be32(65536),
        be16(256),
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        MATRIX,
        new Uint8Array(24),
        be32(all.length + 1)
      );
      return { moov: box("moov", mvhd, ...traks), total: off - mdatStart2 };
    };
    let m = buildMoov(0);
    const mdatStart = ftyp.length + m.moov.length + mdatHdr;
    m = buildMoov(mdatStart);
    const mdatBox = use64 ? cat([be32(1), [..."mdat"].map((c) => c.charCodeAt(0)), be32(Math.floor((16 + m.total) / 4294967296)), be32(16 + m.total >>> 0)]) : cat([be32(8 + m.total), [..."mdat"].map((c) => c.charCodeAt(0))]);
    const parts = [ftyp, m.moov, mdatBox];
    for (const c of order) {
      const sm = c.track.samples;
      let k = c.first;
      const end = c.first + c.n;
      while (k < end) {
        const s0 = sm[k];
        let len = s0.s, j = k + 1;
        while (j < end && sm[j].c === s0.c && sm[j].o === sm[j - 1].o + sm[j - 1].s) {
          len += sm[j].s;
          j++;
        }
        parts.push(chunkSlice(chunkStore[s0.c], s0.o, s0.o + len));
        k = j;
      }
    }
    return { parts, size: mdatStart + m.total, duration: movieDur / MT, tracks: all.map((t) => ({ type: t.handler, samples: t.samples.length })) };
  }
  var u32, i32, u16, u64, fourcc, child, children, be32, be16, box, full, MATRIX, chunkSize, chunkRead, chunkSlice, rle;
  var init_mp4 = __esm({
    "src/core/mp4.js"() {
      u32 = (b, o) => (b[o] << 24 | b[o + 1] << 16 | b[o + 2] << 8 | b[o + 3]) >>> 0;
      i32 = (b, o) => b[o] << 24 | b[o + 1] << 16 | b[o + 2] << 8 | b[o + 3];
      u16 = (b, o) => b[o] << 8 | b[o + 1];
      u64 = (b, o) => u32(b, o) * 4294967296 + u32(b, o + 4);
      fourcc = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);
      child = (buf, b, type) => {
        for (const c of boxes(buf, b.dataStart, b.end)) if (c.type === type) return c;
        return null;
      };
      children = (buf, b, type) => [...boxes(buf, b.dataStart, b.end)].filter((c) => c.type === type);
      be32 = (n) => [n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, n & 255];
      be16 = (n) => [n >>> 8 & 255, n & 255];
      box = (type, ...parts) => {
        const body = cat(parts);
        return cat([be32(8 + body.length), [...type].map((c) => c.charCodeAt(0)), body]);
      };
      full = (type, ver, flags, ...parts) => box(type, [ver, flags >> 16 & 255, flags >> 8 & 255, flags & 255], ...parts);
      MATRIX = [...be32(65536), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ...be32(65536), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ...be32(1073741824)];
      chunkSize = (c) => c instanceof Uint8Array ? c.length : c.size;
      chunkRead = async (c, a, b) => c instanceof Uint8Array ? c.subarray(a, b) : new Uint8Array(await c.slice(a, b).arrayBuffer());
      chunkSlice = (c, a, b) => c instanceof Uint8Array ? c.subarray(a, b) : c.slice(a, b);
      rle = (arr) => {
        const out = [];
        for (const v of arr) {
          const l = out[out.length - 1];
          if (l && l[1] === v) l[0]++;
          else out.push([1, v]);
        }
        return out;
      };
    }
  });

  // src/core/download.js
  async function aesDecrypt(data, keyBytes, iv) {
    const key = await crypto.subtle.importKey("raw", keyBytes, "AES-CBC", false, ["decrypt"]);
    return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-CBC", iv }, key, data));
  }
  function transmuxTs(segBytesIter) {
    return (async () => {
      const tm = new import_mux.default.mp4.Transmuxer({ keepOriginalTimestamps: true });
      let init = null;
      const chunks = [];
      tm.on("data", (s) => {
        if (!init) init = s.initSegment;
        chunks.push(new Blob([s.data]));
      });
      for await (const bytes of segBytesIter) {
        tm.push(bytes);
        tm.flush();
      }
      if (!init) throw new Error("Could not transmux TS (unsupported codec? only H.264/AAC are supported in MPEG-TS)");
      return { init: new Uint8Array(init), chunks };
    })();
  }
  async function hlsMediaToSource(playlistUrl, o, progress) {
    const pl = parseHls(await fetchText(playlistUrl, o), playlistUrl);
    if (pl.type !== "media") throw new Error("Expected a media playlist");
    const segs = pl.segments;
    if (!segs.length) throw new Error("Playlist has no segments");
    const keyCache = /* @__PURE__ */ new Map();
    const getKey = (k) => {
      if (!keyCache.has(k.url)) keyCache.set(k.url, fetchBytes(k.url, o));
      return keyCache.get(k.url);
    };
    const mapUrl = segs[0].map;
    progress.add(segs.length + (mapUrl ? 1 : 0));
    const fetchSeg = (s) => async () => {
      let data = await fetchBytes(s.url, { ...o, range: s.range });
      if (s.key) {
        if (s.key.method !== "AES-128") throw new Error(`Unsupported HLS encryption ${s.key.method} (DRM)`);
        if (s.key.format !== "identity") throw new Error("DRM-protected stream (non-identity key format)");
        data = await aesDecrypt(data, await getKey(s.key), s.key.iv || seqIv(s.seq));
      }
      progress.tick(data.length);
      return data;
    };
    let initBytes = null;
    if (mapUrl) {
      initBytes = await fetchBytes(mapUrl.url, { ...o, range: mapUrl.range });
      progress.tick(initBytes.length);
    }
    const iter = orderedPool(segs.map(fetchSeg), o.concurrency || 6, o.signal);
    const first = await iter.next();
    const fmt = sniff(first.value);
    async function* all() {
      yield first.value;
      for await (const v of iter) yield v;
    }
    if (fmt === "ts") return transmuxTs(all());
    if (fmt === "fmp4") {
      const chunks = [];
      let firstSeg = true;
      let init = initBytes;
      for await (const c of all()) {
        if (firstSeg && !init) {
          const sp = splitFragmented(c);
          init = sp.init;
          chunks.push(new Blob([sp.media]));
        } else chunks.push(new Blob([c]));
        firstSeg = false;
      }
      return { init, chunks };
    }
    if (fmt === "aac") throw new Error("Packed-AAC (ADTS) HLS audio is not supported yet");
    throw new Error("Unknown HLS segment container");
  }
  async function downloadHls(url, optionId, o, progress) {
    const pl = parseHls(await fetchText(url, o), url);
    const sources = [];
    if (pl.type === "master") {
      const v = pl.variants[+optionId || 0];
      if (!v) throw new Error("Quality not found");
      const audio = v.audioGroup ? pl.audio.filter((a) => a.group === v.audioGroup).sort((a, b) => b.default - a.default)[0] : null;
      sources.push(await hlsMediaToSource(v.url, o, progress));
      if (audio) sources.push(await hlsMediaToSource(audio.url, o, progress));
    } else sources.push(await hlsMediaToSource(url, o, progress));
    return sources;
  }
  async function repToSource(rep, o, progress) {
    progress.add(rep.segments.length + (rep.init ? 1 : 0));
    if (/webm|vp8|vp9|opus/i.test(rep.mimeType + rep.codecs)) throw new Error("WebM/VP9 DASH is not supported (only MP4/H.264/AAC)");
    if (rep.single) {
      const bytes = await fetchBytes(rep.segments[0].url, o);
      progress.tick(bytes.length);
      const sp = splitFragmented(bytes);
      return { init: sp.init, chunks: [new Blob([sp.media])], absStart: sp.mediaOffset };
    }
    let init = null;
    if (rep.init) {
      init = await fetchBytes(rep.init.url, { ...o, range: rep.init.range });
      progress.tick(init.length);
    }
    const chunks = [];
    const tasks = rep.segments.map((s) => async () => {
      const b = await fetchBytes(s.url, { ...o, range: s.range });
      progress.tick(b.length);
      return b;
    });
    for await (const b of orderedPool(tasks, o.concurrency || 6, o.signal)) chunks.push(chunks.length || init ? new Blob([b]) : b);
    if (!init) {
      const sp = splitFragmented(chunks[0]);
      init = sp.init;
      chunks[0] = new Blob([sp.media]);
    }
    return { init, chunks };
  }
  async function downloadDash(url, optionId, o, progress) {
    const d = parseDash(await fetchText(url, o), url);
    if (d.encrypted) throw new Error("This stream is DRM-protected and cannot be downloaded");
    const list = d.video.length ? d.video : d.audio;
    const rep = list[+optionId || 0];
    if (!rep) throw new Error("Quality not found");
    const sources = [await repToSource(rep, o, progress)];
    if (d.video.length && d.audio.length) sources.push(await repToSource(d.audio[0], o, progress));
    return sources;
  }
  async function downloadStream(url, { optionId = "0", kind, maxBytes = 0, ...o } = {}) {
    const progress = new Progress(o.onProgress, maxBytes);
    const text = kind ? null : (await fetchText(url, o)).slice(0, 2e3);
    const isHls = kind ? kind === "hls" : text.includes("#EXTM3U");
    const sources = isHls ? await downloadHls(url, optionId, o, progress) : await downloadDash(url, optionId, o, progress);
    if (o.signal?.aborted) throw new AbortError();
    o.onProgress?.({ phase: "mux", done: progress.done, total: progress.total, bytes: progress.bytes });
    const out = await buildMp4(sources, { force64: o.force64 });
    return { blob: new Blob(out.parts, { type: "video/mp4" }), duration: out.duration, tracks: out.tracks, size: out.size };
  }
  var import_mux, sniff, seqIv, Progress;
  var init_download = __esm({
    "src/core/download.js"() {
      import_mux = __toESM(require_mux(), 1);
      init_hls();
      init_dash();
      init_mp4();
      init_util();
      sniff = (b) => {
        if (b.length > 376 && b[0] === 71 && b[188] === 71) return "ts";
        const t = String.fromCharCode(b[4], b[5], b[6], b[7]);
        if (["ftyp", "styp", "moof", "sidx", "moov"].includes(t)) return "fmp4";
        if (b[0] === 73 && b[1] === 68 && b[2] === 51 || b[0] === 255 && (b[1] & 240) === 240) return "aac";
        return "unknown";
      };
      seqIv = (seq) => {
        const iv = new Uint8Array(16);
        new DataView(iv.buffer).setUint32(12, seq >>> 0);
        return iv;
      };
      Progress = class {
        constructor(cb, maxBytes = 0) {
          this.cb = cb;
          this.maxBytes = maxBytes;
          this.total = 0;
          this.done = 0;
          this.bytes = 0;
        }
        add(n) {
          this.total += n;
        }
        tick(bytes) {
          this.done++;
          this.bytes += bytes;
          if (this.maxBytes && this.bytes > this.maxBytes) throw new Error(`SIZE_LIMIT:${this.maxBytes}`);
          this.cb?.({ phase: "download", done: this.done, total: this.total, bytes: this.bytes });
        }
      };
    }
  });

  // src/engine-host.js
  var engine_host_exports = {};
  __export(engine_host_exports, {
    cancelJob: () => cancelJob,
    revoke: () => revoke,
    startJob: () => startJob
  });
  async function startJob({ jobId, url, kind, optionId, concurrency, maxBytes }, emit) {
    const ac = new AbortController();
    jobs.set(jobId, ac);
    let last = 0;
    try {
      const r = await downloadStream(url, {
        kind,
        optionId,
        concurrency,
        maxBytes,
        signal: ac.signal,
        onProgress: (p) => {
          const n = Date.now();
          if (n - last > 250 || p.phase === "mux") {
            last = n;
            emit({ type: "progress", jobId, ...p });
          }
        }
      });
      emit({ type: "done", jobId, blobUrl: URL.createObjectURL(r.blob), size: r.size, duration: r.duration });
    } catch (e) {
      emit(e?.name === "AbortError" ? { type: "cancelled", jobId } : { type: "error", jobId, message: String(e?.message || e) });
    } finally {
      jobs.delete(jobId);
    }
  }
  var jobs, cancelJob, revoke;
  var init_engine_host = __esm({
    "src/engine-host.js"() {
      init_download();
      jobs = /* @__PURE__ */ new Map();
      cancelJob = (jobId) => jobs.get(jobId)?.abort();
      revoke = (url) => {
        try {
          URL.revokeObjectURL(url);
        } catch {
        }
      };
    }
  });

  // src/core/analyze.js
  init_hls();
  init_dash();
  init_util();
  var fmtRate = (bps) => bps ? bps >= 1e6 ? `${(bps / 1e6).toFixed(1)} Mbps` : `${Math.round(bps / 1e3)} kbps` : "";
  var optionLabel = (o) => [o.height ? `${o.height}p` : o.audioOnly ? "Audio" : "", o.frameRate && +o.frameRate > 30 ? `${Math.round(o.frameRate)}fps` : "", fmtRate(o.bandwidth)].filter(Boolean).join(" \xB7 ") || "Default";
  async function analyzeManifest(url, opts = {}) {
    const text = await fetchText(url, opts);
    const head = text.slice(0, 2e3);
    if (head.includes("#EXTM3U")) {
      const pl = parseHls(text, url);
      if (pl.type === "master") {
        return { kind: "hls", url, isMaster: true, options: pl.variants.map((v, i) => ({ id: String(i), width: v.width, height: v.height, bandwidth: v.bandwidth, codecs: v.codecs, frameRate: v.frameRate, label: optionLabel(v), url: v.url })), childUrls: pl.variants.map((v) => v.url).concat(pl.audio.map((a) => a.url)), problem: pl.variants.length ? null : "empty" };
      }
      const enc = pl.segments.find((s) => s.key)?.key;
      let problem = null;
      if (enc && enc.method !== "AES-128") problem = "drm";
      else if (enc && enc.format !== "identity") problem = "drm";
      else if (!pl.segments.length) problem = "empty";
      return { kind: "hls", url, isMaster: false, duration: pl.duration, live: !pl.endlist, options: [{ id: "0", label: "Default", bandwidth: 0 }], problem };
    }
    if (head.includes("<MPD")) {
      const d = parseDash(text, url);
      const list = d.video.length ? d.video : d.audio;
      const problem = d.encrypted ? "drm" : !list.length ? "empty" : list.every((r) => /webm|vp9|vp8|opus/i.test(r.mimeType + r.codecs)) ? "webm" : null;
      return {
        kind: "dash",
        url,
        isMaster: true,
        duration: d.duration,
        live: d.dynamic,
        problem,
        options: list.map((r, i) => ({ id: String(i), width: r.width, height: r.height, bandwidth: r.bandwidth, codecs: r.codecs, frameRate: r.frameRate, audioOnly: !d.video.length, label: optionLabel({ ...r, audioOnly: !d.video.length }) }))
      };
    }
    throw new Error("Not a recognised manifest");
  }

  // src/background.js
  init_util();
  var api = globalThis.browser ?? globalThis.chrome;
  var S = { media: {}, jobs: {}, seq: 0, dl: {} };
  var settings = { auto: false, concurrency: 6, saveAs: false, maxGB: 0 };
  var history = [];
  var persistTimer;
  var histPersistTimer;
  var ready = (async () => {
    try {
      const s = await api.storage.session.get("state");
      if (s.state) S = { ...S, ...s.state };
    } catch {
    }
    try {
      const l = await api.storage.local.get(["settings", "history"]);
      Object.assign(settings, l.settings || {});
      if (Array.isArray(l.history)) history = l.history;
    } catch {
    }
  })();
  var persist = () => {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => api.storage.session.set({ state: S }).catch(() => {
    }), 150);
  };
  var HIST_MAX = 200;
  var persistHistory = () => {
    clearTimeout(histPersistTimer);
    histPersistTimer = setTimeout(() => api.storage.local.set({ history }).catch(() => {
    }), 300);
  };
  var histUnshift = (e) => {
    history.unshift(e);
    if (history.length > HIST_MAX) history = history.slice(0, HIST_MAX);
    persistHistory();
  };
  var histFind = (id) => history.find((h) => h.id === id);
  var SEGMENT_EXT = /\.(ts|m4s|m4f|cmfv|cmfa|aac|vtt|webvtt|key|jpg|jpeg|png|gif|webp|svg|ico|js|css|json|html?)$/i;
  var FILE_EXT = /\.(mp4|webm|m4v|mov|mkv|ogv|mp3|m4a|ogg|opus|flac|wav)$/i;
  var hdr = (headers, name) => headers?.find((h) => h.name.toLowerCase() === name)?.value || "";
  function classify(d) {
    const ct = hdr(d.responseHeaders, "content-type").split(";")[0].trim().toLowerCase();
    let path = "";
    try {
      path = new URL(d.url).pathname;
    } catch {
      return null;
    }
    if (/\.m3u8$/i.test(path) || /mpegurl/.test(ct)) return { kind: "hls", ct };
    if (/\.mpd$/i.test(path) || ct === "application/dash+xml") return { kind: "dash", ct };
    if (SEGMENT_EXT.test(path) || ct === "video/mp2t" || ct === "video/iso.segment" || ct === "video/vnd.dlna.mpeg-tts") return null;
    const cr = /\/(\d+)$/.exec(hdr(d.responseHeaders, "content-range"));
    const size = cr ? +cr[1] : +hdr(d.responseHeaders, "content-length") || 0;
    if ((ct.startsWith("video/") || ct.startsWith("audio/") || FILE_EXT.test(path) && !/html|json|text/.test(ct) || ct === "application/mp4") && size >= 300 * 1024 && d.statusCode < 400) return { kind: "file", ct, size };
    return null;
  }
  var origin = (u) => {
    try {
      return new URL(u).origin;
    } catch {
      return "";
    }
  };
  var tabEntry = (tabId) => S.media[tabId] ||= { items: [], blob: false };
  var ruleSeq = 1e3 + Math.floor(Math.random() * 1e6);
  async function addHeaderRule(pageUrl) {
    if (!pageUrl || !/^https?:/.test(pageUrl) || !api.declarativeNetRequest) return 0;
    const id = ++ruleSeq;
    const rule = { id, priority: id, action: { type: "modifyHeaders", requestHeaders: [{ header: "referer", operation: "set", value: pageUrl }, { header: "origin", operation: "set", value: origin(pageUrl) }] }, condition: { tabIds: [-1], resourceTypes: ["xmlhttprequest", "other", "media"] } };
    try {
      await api.declarativeNetRequest.updateSessionRules({ addRules: [rule] });
      return id;
    } catch {
      return 0;
    }
  }
  var removeHeaderRule = (id) => id && api.declarativeNetRequest?.updateSessionRules({ removeRuleIds: [id] }).catch(() => {
  });
  async function addCandidate({ tabId, url, kind, size, ct, pageUrl }) {
    await ready;
    if (!/^https?:/i.test(url) || tabId < 0) return;
    const te = tabEntry(tabId);
    if (te.items.some((i) => i.url === url)) return;
    let title = "", tabUrl = "";
    try {
      const tab = await api.tabs.get(tabId);
      title = tab.title || "";
      tabUrl = tab.url || "";
    } catch {
    }
    if (!pageUrl || /^https?:\/\/[^/]+$/.test(pageUrl)) pageUrl = tabUrl && origin(tabUrl) === origin(pageUrl || tabUrl) ? tabUrl : pageUrl ? `${pageUrl}/` : tabUrl;
    const item = { id: `m${++S.seq}`, url, kind, size: size || 0, ct: ct || "", pageUrl: pageUrl || "", title, t: Date.now(), state: kind === "file" ? "ready" : "analyzing", options: [], hidden: false };
    te.items.push(item);
    persist();
    updateBadge(tabId);
    if (item.kind === "file") {
      maybeAuto(tabId, item);
      return;
    }
    const rid = await addHeaderRule(item.pageUrl);
    try {
      const a = await analyzeManifest(url);
      item.kind = a.kind;
      item.options = a.options;
      item.problem = a.problem;
      item.duration = a.duration;
      item.live = a.live;
      item.isMaster = a.isMaster;
      item.state = "ready";
      if (a.childUrls) {
        for (const other of te.items) if (a.childUrls.includes(other.url)) other.hidden = true;
      }
      if (te.items.some((o) => o !== item && o.childUrls?.includes(url))) item.hidden = true;
      item.childUrls = a.childUrls;
    } catch (e) {
      te.items = te.items.filter((i) => i !== item);
      if (kind !== "sniffed") console.debug("[streamgrab] analysis failed", url, e.message);
    } finally {
      await removeHeaderRule(rid);
      persist();
      updateBadge(tabId);
    }
    if (item.state === "ready") maybeAuto(tabId, item);
  }
  function maybeAuto(tabId, item) {
    if (!settings.auto || item.kind === "file") return;
    setTimeout(async () => {
      await ready;
      if (item.hidden || item.problem || item.live || item.jobId) return;
      startDownload({ tabId, itemId: item.id, optionId: "0" });
    }, 2500);
  }
  function updateBadge(tabId) {
    const n = (S.media[tabId]?.items || []).filter((i) => !i.hidden && !i.problem).length;
    try {
      api.action.setBadgeText({ tabId, text: n ? String(n) : "" });
      api.action.setBadgeBackgroundColor({ tabId, color: "#2563eb" });
    } catch {
    }
  }
  api.webRequest.onHeadersReceived.addListener((d) => {
    if (d.tabId < 0) return;
    const c = classify(d);
    if (!c) return;
    addCandidate({ tabId: d.tabId, url: d.url, pageUrl: d.documentUrl || d.originUrl || d.initiator || "", ...c });
  }, { urls: ["<all_urls>"], types: ["xmlhttprequest", "media", "other", "object", "main_frame", "sub_frame"] }, ["responseHeaders"]);
  api.tabs.onUpdated.addListener(async (tabId, info) => {
    if (info.status === "loading" && info.url) {
      await ready;
      delete S.media[tabId];
      persist();
      updateBadge(tabId);
    }
  });
  api.tabs.onRemoved.addListener(async (tabId) => {
    await ready;
    delete S.media[tabId];
    persist();
  });
  var asciiName = (n) => n.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7e]+/g, "_");
  async function saveFile(opts) {
    try {
      return await api.downloads.download(opts);
    } catch (e) {
      if (!/filename/i.test(e.message)) throw e;
      return api.downloads.download({ ...opts, filename: asciiName(opts.filename) });
    }
  }
  var findItem = (itemId) => {
    for (const [tabId, te] of Object.entries(S.media)) {
      const it = te.items.find((i) => i.id === itemId);
      if (it) return { tabId: +tabId, item: it };
    }
    return null;
  };
  var setJob = (job, patch) => {
    Object.assign(job, patch);
    persist();
  };
  function makeJob(base, extra = {}) {
    const job = { id: `j${++S.seq}`, status: "running", phase: "download", pct: 0, bytes: 0, error: "", t: Date.now(), ...base, ...extra };
    S.jobs[job.id] = job;
    persist();
    return job;
  }
  async function ensureOffscreen() {
    const ctx = await api.runtime.getContexts?.({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    if (ctx?.length) return;
    await api.offscreen.createDocument({ url: "engine.html", reasons: ["BLOBS"], justification: "Assemble downloaded video segments into one MP4 file" });
  }
  async function engineSend(msg) {
    if (true) {
      const h = await Promise.resolve().then(() => (init_engine_host(), engine_host_exports));
      if (msg.type === "start") h.startJob(msg.job, onEngineMsg);
      else if (msg.type === "cancel") h.cancelJob(msg.jobId);
      else if (msg.type === "revoke") h.revoke(msg.url);
      return;
    }
    await ensureOffscreen();
    await api.runtime.sendMessage({ target: "engine", ...msg });
  }
  async function startDownload({ tabId, itemId, optionId = "0" }) {
    await ready;
    const f = findItem(itemId);
    if (!f) return { error: "not-found" };
    const { item } = f;
    let title = item.title;
    try {
      title = (await api.tabs.get(tabId ?? f.tabId)).title || title;
    } catch {
    }
    const opt = item.options.find((o) => o.id === String(optionId));
    const base = sanitizeFilename(title || new URL(item.url).hostname);
    const meta = { itemKind: item.kind, srcUrl: item.url, pageUrl: item.pageUrl, options: item.options, page: item.title };
    if (item.kind === "file") {
      const ext = /\.([a-z0-9]{2,4})(?:$|\?)/i.exec(new URL(item.url).pathname)?.[1] || "mp4";
      const job2 = makeJob({ tabId: f.tabId, itemId, title: base, quality: "", filename: `${base}.${ext}` }, meta);
      item.jobId = job2.id;
      persist();
      job2.rule = await addHeaderRule(item.pageUrl);
      try {
        const id = await saveFile({ url: item.url, filename: `${base}.${ext}`, saveAs: settings.saveAs, conflictAction: "uniquify" });
        S.dl[id] = job2.id;
        setJob(job2, { status: "saving", phase: "save" });
      } catch (e) {
        setJob(job2, { status: "error", error: e.message });
        removeHeaderRule(job2.rule);
      }
      return { jobId: job2.id };
    }
    const job = makeJob({ tabId: f.tabId, itemId, title: base, quality: opt?.label || "", filename: `${base}${opt?.height ? ` [${opt.height}p]` : ""}.mp4` }, { ...meta, optionId: String(optionId) });
    item.jobId = job.id;
    persist();
    job.rule = await addHeaderRule(item.pageUrl);
    engineSend({ type: "start", job: { jobId: job.id, url: item.url, kind: item.kind, optionId: String(optionId), concurrency: settings.concurrency, maxBytes: settings.maxGB ? Math.round(settings.maxGB * 1024 ** 3) : 0 } }).catch((e) => onEngineMsg({ type: "error", jobId: job.id, message: e.message }));
    return { jobId: job.id };
  }
  async function startHistDownload({ histId, optionId = "0" }) {
    await ready;
    const e = histFind(histId);
    if (!e) return { error: "not-found" };
    if (e.kind === "file") {
      const base2 = sanitizeFilename(e.title || new URL(e.srcUrl || "x://v").hostname);
      const job2 = makeJob({ histId, title: base2, quality: e.quality || "", filename: e.filename, itemKind: "file", srcUrl: e.srcUrl, pageUrl: e.pageUrl });
      job2.rule = await addHeaderRule(e.pageUrl);
      try {
        const id = await saveFile({ url: e.srcUrl, filename: e.filename, saveAs: settings.saveAs, conflictAction: "uniquify" });
        S.dl[id] = job2.id;
        setJob(job2, { status: "saving", phase: "save" });
      } catch (err) {
        setJob(job2, { status: "error", error: String(err?.message || err) });
        removeHeaderRule(job2.rule);
      }
      return { jobId: job2.id };
    }
    let options = [];
    try {
      const a = await analyzeManifest(e.srcUrl);
      if (a.problem) return { error: a.problem };
      options = a.options;
    } catch {
      return { error: "manifest-unavailable" };
    }
    const want = String(optionId ?? e.optionId ?? "0");
    const optId = options.some((o) => o.id === want) ? want : "0";
    const opt = options.find((o) => o.id === optId);
    const base = sanitizeFilename(e.title || "video");
    const job = makeJob({ histId, title: base, quality: opt?.label || "", filename: `${base}${opt?.height ? ` [${opt.height}p]` : ""}.mp4`, itemKind: e.kind, srcUrl: e.srcUrl, pageUrl: e.pageUrl, options, optionId: optId });
    job.rule = await addHeaderRule(e.pageUrl);
    engineSend({ type: "start", job: { jobId: job.id, url: e.srcUrl, kind: e.kind, optionId: optId, concurrency: settings.concurrency, maxBytes: settings.maxGB ? Math.round(settings.maxGB * 1024 ** 3) : 0 } }).catch((err) => onEngineMsg({ type: "error", jobId: job.id, message: String(err?.message || err) }));
    return { jobId: job.id };
  }
  async function onEngineMsg(m) {
    await ready;
    const job = S.jobs[m.jobId];
    if (!job) return;
    if (m.type === "progress") setJob(job, { phase: m.phase, pct: m.total ? Math.round(m.done / m.total * 100) : 0, bytes: m.bytes, status: m.phase === "mux" ? "muxing" : "running" });
    else if (m.type === "done") {
      setJob(job, { status: "saving", phase: "save", pct: 100, size: m.size });
      try {
        const id = await saveFile({ url: m.blobUrl, filename: job.filename, saveAs: settings.saveAs, conflictAction: "uniquify" });
        S.dl[id] = job.id;
        job.blobUrl = m.blobUrl;
        persist();
      } catch (e) {
        setJob(job, { status: "error", error: e.message });
        engineSend({ type: "revoke", url: m.blobUrl });
        removeHeaderRule(job.rule);
      }
    } else if (m.type === "error") {
      setJob(job, { status: "error", error: m.message });
      removeHeaderRule(job.rule);
    } else if (m.type === "cancelled") {
      setJob(job, { status: "cancelled" });
      removeHeaderRule(job.rule);
    }
  }
  async function recordHistory(job, dlId) {
    if (!job.filename) return;
    try {
      const d = await api.downloads.search({ id: dlId }).catch(() => []);
      if (!d[0]) return;
      histUnshift({
        id: `h${++S.seq}`,
        fin: Date.now(),
        title: job.title,
        filename: String(job.filename).split("/").pop(),
        quality: job.quality || "",
        kind: job.itemKind || "",
        size: d[0].fileSize || job.size || 0,
        srcUrl: job.srcUrl || "",
        pageUrl: job.pageUrl || "",
        page: job.page || "",
        options: job.options || [],
        optionId: job.optionId || "",
        dlId
      });
    } catch {
    }
  }
  api.downloads.onChanged.addListener(async (delta) => {
    await ready;
    const jobId = S.dl[delta.id];
    const job = jobId && S.jobs[jobId];
    if (!job) return;
    const st = delta.state?.current;
    if (!st || st === "in_progress") return;
    if (st === "complete") {
      setJob(job, { status: "done" });
      recordHistory(job, delta.id);
    } else {
      setJob(job, { status: "error", error: delta.error?.current || "download interrupted" });
    }
    if (job.blobUrl) engineSend({ type: "revoke", url: job.blobUrl });
    removeHeaderRule(job.rule);
    delete S.dl[delta.id];
    persist();
  });
  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.target === "engine") return false;
    (async () => {
      await ready;
      switch (msg?.type) {
        case "sniffed": {
          const tabId = sender.tab?.id;
          if (tabId >= 0) addCandidate({ tabId, url: msg.url, kind: "sniffed", pageUrl: msg.frameUrl || sender.url || "" });
          return sendResponse({});
        }
        case "blob": {
          if (sender.tab) {
            tabEntry(sender.tab.id).blob = true;
            persist();
          }
          return sendResponse({});
        }
        case "getState": {
          const te = S.media[msg.tabId] || { items: [], blob: false };
          const items = te.items.filter((i) => !i.hidden).map(({ childUrls, ...i }) => ({ ...i, job: i.jobId ? S.jobs[i.jobId] : null }));
          return sendResponse({ items, blob: te.blob, settings });
        }
        case "download":
          return sendResponse(await startDownload(msg));
        case "cancel": {
          const job = S.jobs[msg.jobId];
          if (job) {
            engineSend({ type: "cancel", jobId: job.id });
          }
          return sendResponse({});
        }
        case "clear": {
          delete S.media[msg.tabId];
          persist();
          updateBadge(msg.tabId);
          return sendResponse({});
        }
        case "setSettings": {
          Object.assign(settings, msg.settings);
          await api.storage.local.set({ settings });
          return sendResponse(settings);
        }
        case "getHistory": {
          const stats = history.reduce((a, e) => {
            a.count++;
            a.bytes += e.size || 0;
            return a;
          }, { count: 0, bytes: 0 });
          const jobs2 = Object.values(S.jobs).filter((j) => j.histId);
          return sendResponse({ items: history, stats, jobs: jobs2 });
        }
        case "histDownload":
          return sendResponse(await startHistDownload(msg));
        case "histRemove": {
          const h = histFind(msg.histId);
          if (h) {
            history = history.filter((x) => x !== h);
            persistHistory();
          }
          return sendResponse({});
        }
        case "histClear": {
          history = [];
          persistHistory();
          return sendResponse({});
        }
        case "openFile": {
          try {
            await api.downloads.open(+msg.dlId);
          } catch {
            try {
              await api.downloads.show(+msg.dlId);
            } catch {
              try {
                await api.downloads.showDefaultFolder();
              } catch {
              }
            }
          }
          return sendResponse({});
        }
        case "showFile": {
          try {
            await api.downloads.show(+msg.dlId);
          } catch {
            try {
              await api.downloads.showDefaultFolder();
            } catch {
            }
          }
          return sendResponse({});
        }
        case "rescan":
          return sendResponse({});
        default:
          if (msg?.target === "bg") {
            await onEngineMsg(msg);
          }
          return sendResponse({});
      }
    })();
    return true;
  });
})();
